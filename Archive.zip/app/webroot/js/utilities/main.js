(function(){
	require(['controllers/application'], function(){ });
}())
(function(){

// In 2014 we retrofitted our propritary code structure with RequireJS
// to enable dependency loading. We are only using components of the AMD
// structure right now.

define('utilities/global',['jquery'], function(){

	window.LSP = window.LSP || {};
	window.LSP.utilities = window.LSP.utilities || {};
	
	$.extend(window.LSP.utilities, (function(){
		
		var _util = {};
		var _app = window.LSP;
		var _requiredScripts = [];
		var _requiredScriptsDeferments = [];

		_util = {

			redirectTo : function(url){
				document.location = url.replace('www.lonestarpercussion', 'lspsandbox.explorewebdev');
			},


			// Adapted from http://jacwright.com/projects/javascript/date_format/
			// For exact syntax - see link above (based on PHP's date formatter
			formatDate : function(date, formatString){
				date = (typeof date === 'string' && date.indexOf(':') < 0 ? date.replace(/-/g, '/') : date);
				date = (typeof date === 'string' ? new Date(date) : date); // replace - with / for safari
				date = date || new Date();
				formatString = formatString || 'l, F jS Y g:ia';
				var returnStr = '';
				var replace = {
					shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					longMonths: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
					shortDays: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
					longDays: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
				
					// Day
					d: function(c) { return (c.getDate() < 10 ? '0' : '') + c.getDate(); },
					D: function(c) { return this.shortDays[c.getDay()]; },
					j: function(c) { return c.getDate(); },
					l: function(c) { return this.longDays[c.getDay()]; },
					N: function(c) { return c.getDay() + 1; },
					S: function(c) { return (c.getDate() % 10 == 1 && c.getDate() != 11 ? 'st' : (c.getDate() % 10 == 2 && c.getDate() != 12 ? 'nd' : (c.getDate() % 10 == 3 && c.getDate() != 13 ? 'rd' : 'th'))); },
					w: function(c) { return c.getDay(); },
					z: function(c) { var d = new Date(c.getFullYear(),0,1); return Math.ceil((c - d) / 86400000); }, // Fixed now
					// Week
					W: function(c) { var d = new Date(c.getFullYear(), 0, 1); return Math.ceil((((c - d) / 86400000) + d.getDay() + 1) / 7); }, // Fixed now
					// Month
					F: function(c) { return this.longMonths[c.getMonth()]; },
					m: function(c) { return (c.getMonth() < 9 ? '0' : '') + (c.getMonth() + 1); },
					M: function(c) { return this.shortMonths[c.getMonth()]; },
					n: function(c) { return c.getMonth() + 1; },
					t: function(c) { var d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 0).getDate(); }, // Fixed now, gets #days of date
					// Year
					L: function(c) { var year = c.getFullYear(); return (year % 400 === 0 || (year % 100 !== 0 && year % 4 === 0)); },   // Fixed now
					o: function(c) { var d  = new Date(c.valueOf());  d.setDate(d.getDate() - ((c.getDay() + 6) % 7) + 3); return d.getFullYear();}, //Fixed now
					Y: function(c) { return c.getFullYear(); },
					y: function(c) { return ('' + c.getFullYear()).substr(2); },
					// Time
					a: function(c) { return c.getHours() < 12 ? 'am' : 'pm'; },
					A: function(c) { return c.getHours() < 12 ? 'AM' : 'PM'; },
					B: function(c) { return Math.floor((((c.getUTCHours() + 1) % 24) + c.getUTCMinutes() / 60 + c.getUTCSeconds() / 3600) * 1000 / 24); }, // Fixed now
					g: function(c) { return c.getHours() % 12 || 12; },
					G: function(c) { return c.getHours(); },
					h: function(c) { return ((c.getHours() % 12 || 12) < 10 ? '0' : '') + (c.getHours() % 12 || 12); },
					H: function(c) { return (c.getHours() < 10 ? '0' : '') + c.getHours(); },
					i: function(c) { return (c.getMinutes() < 10 ? '0' : '') + c.getMinutes(); },
					s: function(c) { return (c.getSeconds() < 10 ? '0' : '') + c.getSeconds(); },
					u: function(c) { var m = c.getMilliseconds(); return (m < 10 ? '00' : (m < 100 ? '0' : '')) + m; },
					// Timezone
					O: function(c) { return (-c.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(c.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(c.getTimezoneOffset() / 60)) + '00'; },
					P: function(c) { return (-c.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(c.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(c.getTimezoneOffset() / 60)) + ':00'; }, // Fixed now
					T: function(c) { var m = c.getMonth(); c.setMonth(0); var result = c.toTimeString().replace(/^.+ \(?([^\)]+)\)?$/, '$1'); c.setMonth(m); return result;},
					Z: function(c) { return -c.getTimezoneOffset() * 60; },
					// Full Date/Time
					c: function(c) { return c.format("Y-m-d\\TH:i:sP"); }, // Fixed now
					r: function(c) { return c.toString(); },
					U: function(c) { return c.getTime() / 1000; }
				};
				
				for (var i = 0; i < formatString.length; i++) {
					var curChar = formatString.charAt(i);
					if (i - 1 >= 0 && formatString.charAt(i - 1) == "\\") {
						returnStr += curChar;
					}else if (replace[curChar]) {
						returnStr += replace[curChar](date);
					}else if (curChar != "\\"){
						returnStr += curChar;
					}
				}
				return returnStr;
			},

			// Simple shallow comparison.
			isEqual : function(a, b){
				
				var isEqual = (!!a && !!b);

				$.each(a, function(key, value){
					if((!b.hasOwnProperty(key) && (a[key]+''.length) > 0) || a[key]+'' !== a[key]+''){
						isEqual = false;
						return false;
					}
				})

				if(isEqual){
					$.each(b, function(key, value){
						if((!a.hasOwnProperty(key) && (b[key]+''.length) > 0) || b[key]+'' !== a[key]+''){
							isEqual = false;
							return false;
						}
					})
				}

				return isEqual;
			},

			scrollTo : function(element){

				element = $(element);

				if(element){
					var viewportHeight = $(window).height();

					// Firefox uses body, webkit uses html (or the other way around) -- one is always zero, so just pick the large of the two
					var scrollTop = Math.max($('body').scrollTop(), $('html').scrollTop())
					var elementPos = (element.offset() || {}).top;

					if(elementPos < scrollTop || elementPos > scrollTop + viewportHeight){
						// Firefox/webkit discrepency
						if(LSP.controllers.application.getContext() === 'phone'){
							$('body, html').scrollTop(element.offset().top - 20);
							return $.Deferred().resolve();
						}else{
							return $('body, html').animate({ scrollTop: element.offset().top - 20}, 500);
						}
						
					}
				}else{
					return $.Deferred().resolve()
				}
			},

			getURLParameters : (function(){

				var vars = {}, hash;
				var href = window.location.href + '#'; // Add the hash so indexOf will have something
				var hashes = href.slice(href.indexOf('?') + 1, href.indexOf('#')).split('&');
				
				for(var i = 0; i < hashes.length; i++)
				{
					hash = hashes[i].split('=');
					//vars.push(hash[0]);
					vars[hash[0]] = decodeURIComponent(hash[1]).replace(/\+/g, ' ');
				}

				return function(){
					return vars;
				}
			}()),

			// formToObject : window.form2js,
			// Because form2js is being included as part of the postLoad group
			// it dosen't exist, so we need to attach it to _util later.
			// check in the form2js vendor file

			cleanArray : function(array){
				for(var i = 0; i < array.length; i++){
					if(array[i] === undefined || (array[i] || '').length < 1 || array[i] === null || (typeof array[i] === 'object' && $.isEmptyObject(array[i]))){
						array.splice(i, 1);
						i--;
					}
				}
				return array;
			},

			findBetween : function(front, back, string){
				var start = string.indexOf(front) + front.length;
				var end = (string + back).indexOf(back, start); // returns to the end if back not present
				return string.substr(start, end - start);
			},
			
			// Pulled from jQuery as it's not in the public API
			// identical to jQuery.camelCase();
			camelCase : function(string){
				var fcamelCase = function( all, letter ) {
					return ( letter + '' ).toUpperCase();
				};
				var fLowerCase = function(all, letter){
					return (letter + '').toLowerCase();
				};
				return string.replace(/[^A-Za-z0-9]+/g, '-').replace(/^-ms-/, 'ms-').replace(/-([\da-z])/gi, fcamelCase ).replace(/^([A-Z]){1}/, fLowerCase);  
			},

			isValid : function(string, type){
				return LSP.controllers.validation.isValid(string, type);
			},

			cleanTrailing : function(string){
				return (string || '').replace(/^[.\s]+|[.\s]+$/g, '');
			},
			
			parseMicroTemplate : (function(){

				/* jshint quotmark:false */
				/* jshint evil:true */

				var cache = {};
				function tmpl(str, data){

					if(str){
						// Figure out if we're getting a template, or if we need to
						// load the template - and be sure to cache the result.
						
						var fn = /^[A-Za-z]{1}[-:A-Za-z0-9_]+$/.test(str) ? // if valid HTML id
								cache[str] = cache[str] || tmpl(document.getElementById(str).innerHTML) :
				
								// Generate a reusable function that will serve as a template
								// generator (and which will be cached).
								new Function("obj",
								"var p=[],print=function(){p.push.apply(p,arguments);};" +
								
								// Introduce the data as local variables using with(){}
								"with(obj){var _util=window.LSP.utilities,_controllers=window.LSP.controllers;p.push('" +
								
								// Convert the template into pure JavaScript
								str.replace(/[\r\t\n]/g, " ")
									.replace(/'(?=[^#]*#>)/g, "\t")
									.split("'").join("\\'")
									.split("\t").join("'")
									.replace(/<#=(.+?)#>/g, "',$1,'")
									.split("<#").join("');")
									.split("#>").join("p.push('") +
									"');}return p.join('');");

						// Provide some basic currying to the user
						return data ? fn.apply(data, [data]) : fn;
					}
					
					return null;
				}

				return tmpl;
				
			}()),

			parseCurrency : function(number) {
				var places = !isNaN(places = Math.abs(places)) ? places : 2;
				var symbol = symbol !== undefined ? symbol : "$";
				var thousand = thousand || ",";
				var decimal = decimal || ".";
				var negative = number < 0 ? "-" : "",
					i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + "",
					j = (j = i.length) > 3 ? j % 3 : 0;
				return symbol + negative + (j ? i.substr(0, j) + thousand : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousand) + (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : "");
			},

			// Registers a controller/model/asset, and releases the initialization
			// deferrment
			register : function(type, name, object){

				switch(type){
					
				case 'model' :
					window.LSP.models = window.LSP.models || {};
					
					// Add duplication validation if nessesary
					object.name = name;
					window.LSP.models[name] = object;
					
					break;
					
				case 'controller' :
					window.LSP.controllers = window.LSP.controllers || {};
					
					object.name = name;
					
					// Add duplication validation if nessesary
					window.LSP.controllers[name] = object;
					
					// Assumes application is the first loaded.
					window.LSP.controllers.application.init(object);
					
					break;
					
				case 'asset' :
					window.LSP.assets = window.LSP.assets || {};
					
					// Add duplication validation if nessesary
					object.name = name;
					window.LSP.assets[name] = object;
					
					break;
				}
			
			}
		};
		
		return _util;
	
	}()));

});
	
}());
(function(){

	window.LSP = window.LSP || {};
	window.LSP.utilities = window.LSP.utilities || {};

	// require.config({
	//     baseUrl: '//d2bghjaa5qmp6f.cloudfront.net/min/js',
	// });

	var loadMap = {
		home : {
			element : '.page-home',
			js : ['controllers/home', 'plugins/flyout'],
			//css : ['pages/home.css'],
			priority : 'critical'},
		netsuite : {
			element : '#handle_loginMainPortlet, #handle_cartMainPortlet',
			js : ['controllers/netsuite', 'controllers/checkout', 'vendors/netsuite/interface'],
			css : ['ns-checkout.css'],
			priority : 'critical'
		},
		// netsuiteSecondary : {
		// 	element : '#handle_loginMainPortlet, #handle_cartMainPortlet',
		// 	js : ['vendors/netsuite/interface'],
		// 	css : ['ns-checkout.css'],
		// 	priority : 'critical'
		// },
		product : {
			element : '.page-productDetail, .productScope, *[data-controller="product"]',
			js : ['controllers/product'],
			css : ['pages/product.css'],
			priority : 'critical'},
		search : {
			element : 'input[name="search"], a[href*="search"], *[data-action="destoryAndLoadCategory"]',
			//minjs : ['combined/search'],
			js : ['plugins/search', 'models/api', 'models/easyask'],
			css : ['pages/search.css'],
			priority : (document.location.href.indexOf('search') > 0 ? 'critical' : 'secondary')},
		wishlist : {
			element : '.page-wishlist, .wishlist-messages',
			js : ['controllers/wishlist'],
			css : ['pages/wishlist.css'],
			priority : (document.location.href.indexOf('Wishlist') > 0 ? 'critical' : 'secondary')
		},
		categoryBlocks : {
			element : '.categories',
			css : ['components/categoryBlocks.css'],
			priority : 'critical'},
		cart : {
			element : '#handle_cartMainPortlet',
			css : ['ns-checkout.css'],
			priority : 'critical'},
		reviews : {
			element : '.aggregateReviews, .page-generic .reviews',
			js : ['controllers/reviews'],
			css : ['components/reviews.css'],
			priority : 'secondary'
		},
		trackOrder : {
			element : '.page-trackOrder',
			js : ['controllers/shipping'],
			css : ['pages/shipping.css'],
			priority : 'critical'
		},
		badges : {
			element : '*[data-badge]', 
			js : ['plugins/badges'],
			css : ['components/badges.css'],
			priority : 'secondary'
		},
		clearable : {
			element : '.clearable',
			js : ['plugins/clearable'],
			css : ['components/clearable.css'],
			priority : 'secondary'},
		definitions : {
			element : '*[data-def]',
			js : ['plugins/definitions'],
			css : ['components/definitions.css'],
			priority : 'secondary'},
		flyout : {
			element : '.flyout',
			js : ['plugins/flyout'],
			priority : 'secondary'},
		reveal : {
			element : '*[data-reveal-children]',
			js : ['plugins/reveal'],
			css : ['components/reveal.css'],
			priority : 'secondary'},
		suggestions : {
			element : '.dynamicItemSuggestions',
			js : ['plugins/suggestions'],
			css : ['components/dynamicSuggestions.css'],
			priority : 'secondary'},
		validation : {
			element : '*[class*="validation-"]',
			js : ['plugins/validation'],
			priority : 'secondary'},
		zoom : {
			element : '#zoom-mainImage',
			js : ['vendors/jqzoom/jqzoom'],
			css : ['vendors/jqzoom/jqzoom.css'],
			priority : 'secondary'},
		ads : {
			element : '*[class*="bsa-"], .productAd',
			js : ['plugins/ads'],
			css : ['components/ads.css'],
			priority : 'secondary'},
		category : {
			element : '.page-category',
			js : ['controllers/category'],
			css : ['pages/category.css'],
			priority : 'critical'},
		schoolCategory : {
			element : '.page-school-category',
			js : ['controllers/category'],
			css : ['pages/school-category.css'],
			priority : 'critical'},
		checkout : {
			element : '.header.small',
			js : ['controllers/checkout', 'controllers/netsuite'],
			css : ['ns-checkout.css'],
			priority : 'critical'},
		touchcarousel : {
			element : '.touchcarousel',
			js : ['vendors/touchcarousel/touchcarousel'],
			css : ['vendors/touch_carousel/touchcarousel.css'],
			priority : 'critical'
		},
		byline : {
			element : '.byline',
			css : ['components/byline.css']
		}
	};

	var IS_MINIFIED_SOURCE = require.toUrl('').indexOf('min') > 0;

	window.LSP.utilities.loader = {
		
		loadedCSS : [],

		load : function(element){

			var jsDependencies = {};
			var cssDependencies = [];

			for (var component in loadMap) {
				if(loadMap.hasOwnProperty(component)){
					var e = loadMap[component];

					if($(e.element, element).length > 0 || e.always){
						if(e.js && e.minjs)
							e.js = (IS_MINIFIED_SOURCE ? e.minjs : e.js);

						if(e.js){
							jsDependencies[e.priority] = jsDependencies[e.priority] || [];
							jsDependencies[e.priority] = jsDependencies[e.priority].concat(e.js);
						}

						if(e.css)
							cssDependencies = cssDependencies.concat(e.css);
					}
				}
			}

			this.loadJS(jsDependencies);			

			if(cssDependencies.length > 0){
				//console.log('Attempting to load:', cssDependencies);
				//this.loadCSS($(cssDependencies).not(this.loadedCSS).get()); // Load the difference between loadedCSS and cssDependencies
			}
		},
		loadJS : function(priorityObject, callback){
			require(priorityObject.critical || [], function a(priorityObject){
				
				return function(){
					console.log('Primary loaded', priorityObject);

					$(function loadSecondaryJS(){
							
						console.log('Loaded Secondary:', priorityObject.secondary);
						
						require(priorityObject.secondary || [], function b(){
							(callback || function(){})();
						});
					});
				}
			}(priorityObject));	
		},
		getStylesheetUrls : function(){
			var existingLinks = document.getElementsByTagName('link');
			var existingStylesheets = [];

			for(var i = 0; i < existingLinks.length; i++){
				existingStylesheets.push(existingLinks[i].href.replace(/https?\:/, ''));
			}

			return existingStylesheets;
		},
		loadCSS : function(stylesheetArray){
			
			var existingStylesheets = this.getStylesheetUrls();
			var https = '';

			for(var i = 0; i < stylesheetArray.length; i++){

				if(stylesheetArray[i].substr(0,1) == '!'){
					stylesheetArray[i] = stylesheetArray[i].replace('!', '');
					https = 'https:';
				}

				var url = https + CDN + '/min/css/' + stylesheetArray[i] + '?v=' + VERSION;
				var found = false;

				for(var j = 0; j < existingStylesheets.length; j++){
					if(existingStylesheets[j].replace(/https?:/, '') == url.replace(/https?:/, '')){
						found = true;
						break;
					}
				}

				if(!found){
					googleAsyncCSSLoader(url);
				}
			}
		}
	};
	
	window.LSP.utilities.loader.loadJS({critical: ["jquery", "combined/core"]});
	
	// These files take a few seconds to download when loaded this way, so if they contain 
	// above-the-fold assets they are included directly in the template, but every page should load them all
	// This speeds up subsequent pages, as well as ensures that any rouge assets still render properly
	window.LSP.utilities.loader.loadCSS(['combined/category.css', 'combined/home.css', 'combined/product.css', 'combined/search.css', '!ns-checkout.css']);


}());
define("utilities/loader", function(){});

/**
 * jQuery Unveil
 * A very lightweight jQuery plugin to lazy load images
 * http://luis-almeida.github.com/unveil
 *
 * Licensed under the MIT license.
 * Copyright 2013 Luís Almeida
 * https://github.com/luis-almeida
 */
define('vendors/unveil/unveil-min',[], function(){

;(function($) {

	$.fn.unveil = function(threshold, callback) {

		var $w = $(window),
				th = threshold || 0,
				retina = window.devicePixelRatio > 1,
				attrib = retina ? "data-src-retina" : "data-src",
				images = this,
				loaded;

		this.attr("src", "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7");

		this.one("unveil", function() {

			var source = this.getAttribute(attrib);
			source = source || this.getAttribute("data-src");
			
			if (source) {
				if(this.nodeName === 'IMG'){
					this.setAttribute("src", source);
				}else{
					$(this).css('background-image', 'url(' + source + ')');
				}

				if (typeof callback === "function") callback.call(this);

				this.removeAttribute('data-src');
				this.removeAttribute('data-src-retina');
			}

		});

		function unveil() {
			var inview = images.filter(function() {
				var $e = $(this);
				if ($e.is(":hidden")) return;

				var wt = $w.scrollTop(),
						wb = wt + $w.height(),
						et = $e.offset().top,
						eb = et + $e.height();

				return eb >= wt - th && et <= wb + th;
			});

			loaded = inview.trigger("unveil");
			images = images.not(loaded);
		}

		$w.scroll(unveil);
		$w.resize(unveil);

		unveil();

		return this;

	};

})(window.jQuery || window.Zepto);

});
(function(){

define('controllers/application',['jquery', 'utilities/loader', 'utilities/global'], function applicationController(){

	var _util = window.LSP.utilities;
	
	var application = (function(){
		var _this = {};
		var _app = window.LSP;
		var _assets = _app.assets;
		var _context;
		var _isReadyFired = false;
		var _hasPushState = !!(window.history && history.pushState);

		var _state = {};

		var _isPushingState;
		var _defferedScriptCount = 0;

		_this = {
			events : {

				application : {

					onStateChange : function(e, data){
						$('html').attr('data-path', document.href + '-END');
					},

					onResize : function(e, data){
						var targetController = $(data.controller ? data.controller : _this);
						var oldContext = _context;
						var newContext = _this.getContext();

						if(newContext !== oldContext){
							console.log('Leaving ' + oldContext + ' entering ' + newContext);
							
							targetController.triggerHandler('onContextChange', {context : newContext, previousContext : oldContext});
							targetController.triggerHandler(_util.camelCase('onContextChangeLeave-' + oldContext), {context : newContext, previousContext : oldContext});
							targetController.triggerHandler(_util.camelCase('onContextChangeEnter-' + newContext), {context : newContext, previousContext : oldContext});
						}
					},
					onAttachEvents : function(e, data){

						console.time('attachEvent : Application');

						// Ask the loader to load any new plugins or controllers if required
						_util.loader.load(data.selector);

						// This is a helper event attacher, it looks for all
						// buttons, and if they have data-controller, and data-action
						// attributes, will call the appropriate event.
						var elements = [];

						
							elements = $('*[data-action]', data.selector);
						
						
						for(var i = 0; i < elements.length; i++){

							element = $(elements[i]);

							var action = element[0].getAttribute('data-action');
							//var asset = element[0].getAttribute('data-asset');
							var controller = element[0].getAttribute('data-controller');
							var preventDefault = false;
							var eventType;

							// if(asset)
							// 	console.log('Warning :: Assets are unused');

							if(!controller){
								// find the first parent with data-controller
								// this allows a type of inheritance
								console.log('Warning :: Loading Parentals - This element needs a data-controller attribute', element);
								controller = element.parents('*[data-controller]:first').data('controller');
							}
							
							switch(element[0].nodeName.toUpperCase()){
								case "FORM":
									eventType = 'submit';
									preventDefault = true;
									break;
								
								case "INPUT":
								case "SELECT":
									eventType = 'change';
								break;

								case "BUTTON":
									preventDefault = true;
									eventType = 'click';
									break;
								
								default:
									eventType = 'click'
									break;
							}

							if(controller && action /*&& !asset*/){
								

								element.on(eventType, {preventDefault : preventDefault, controller : controller, action : action, element : element}, function(e){

									console.log('Event : ' + e.data.controller + '.events.' + _util.camelCase('on-' + e.data.action) + ' fired.');

									$(_app.controllers[e.data.controller]).
										triggerHandler(_util.camelCase('on-' + e.data.action),
											{selector : e.data.element, originalEvent : e});
									if(e.data.preventDefault){
										e.preventDefault();
									}
								});//.attr('data-action-handled', true);
							
							}

							// else if(controller && action && asset){
							// 	element.on(eventType, {preventDefault : preventDefault}, function(e){

							// 		console.log('Event : ' + controller + '.events.' + _util.camelCase('on-' + action) + ' fired.');

							// 		$(_app.controllers[controller].assets[asset]).
							// 			triggerHandler(_util.camelCase('on-' + action),
							// 				{selector : element, originalEvent : e});
							// 		if(e.data.preventDefault){
							// 			e.preventDefault();
							// 		}
							// 	});//.attr('data-action-handled', true);
							// }

						}					
							
						require(['vendors/unveil/unveil-min'], function(data){
							return function(){ 
								$('*[data-src]:not([data-lazy-handled])', data.selector).attr('data-lazy-handled', true).unveil(200);
							};
						}(data));

						console.timeEnd('attachEvent : Application');
							
					},

					onReady : function(e, data){
						
						_isReadyFired = true;
						
						_this.attachEvents($('html'));

						if(_this.hasPushState()){
							history.replaceState(true, 'page', document.URL);
						}


						var requestNextScript = function(){
							var script = $('script[type="text/javascript/defer"]')[0];
							if(script){
								script = $(script);
								if(script.attr('src')){
									$.ajaxSetup({cache: true});
									$.getScript(script.attr('src'), function(){
										requestNextScript();
									});
									script.remove();
									$.ajaxSetup({cache: false});
								}else{
									eval("with(window){ " + script.html() + "}");
									script.remove();
									requestNextScript();
								}
							}
						};

						requestNextScript();

						// Orientation Change Zoom Bug (Bug WR935)
						if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i)) {
						  var viewportmeta = document.querySelector('meta[name="viewport"]');
						  if (viewportmeta) {
							viewportmeta.content = 'width=device-width, minimum-scale=1.0, maximum-scale=1.0';
							document.body.addEventListener('gesturestart', function() {
							  viewportmeta.content = 'width=device-width, minimum-scale=0.25, maximum-scale=1.6';
							}, false);
						  }
						}

					},

					onInit : function(e, data){
						_state = _this.pullState();
					}
				}
			},
			
			assets : {},

			getContext : function(){
				var width = $(window).width();
				var newContext;

				if(width >= 1200){
					newContext = 'largeDesktop'; // could be largeDesktop
				}else if(width > 979){
					newContext = 'desktop';
				}else if(width >= 768){
					newContext = 'tablet';
				}else{
					newContext = 'phone';
				}

				_context = newContext;

				return _context;
			},

			getFilename : function(){
				return document.location.pathname.replace(/^.*(\\|\/|\:)/, '');
			},
			
			// Fire all attach events event
			attachEvents : function(selector){
				$(_this).triggerHandler('onAttachEvents', {selector : selector});
			},

			createHandlerBridge : function(controller, eventName, passthrough){
				return function(e){
					$(controller).triggerHandler(_util.camelCase('on-'+eventName), {selector : this, passthrough : passthrough});
				};
			},

			hasPushState : function(){
				return _hasPushState;
			},

			// Push / Pull state take snapshots sent from controllers, stringify them
			// and then push that to the hash. It would have been possible to use JSON
			// but the slashes look much prettier
			pushState : function(controller, snapshot, useReplaceState){
				
				var statePath = _this.buildStateString(controller, snapshot); // relies on _state to build full string
				
				// If pushState, push the path
				if(_this.hasPushState()){
					// To overcome an implementation problem with chrome/firefox where the popstate event 
					// gets fired for onload - we use a workaround to look at history.state.
					// this means the first argument (state) for history.pushState must ALWAYS be something
					// that evaluates to true, {} would work too.
					// check the event down below in initializeGlobalEvents to see more
					if(!useReplaceState){
						history.pushState(true, '', document.location.origin + ('/' + snapshot.path).replace(/\/$/, '') + '/#' + statePath);
						$('html').attr('data-path', document.location.origin + ('/' + snapshot.path).replace(/\/$/, '') + '/#' + statePath + '-END');
					}else{
						console.log('Replacing State');
						history.replaceState(true, '', ('/' + snapshot.path).replace(/\/$/, '') + '/#' + statePath);
					}

					$('html').attr('data-path', document.location.href);

				}else{

					// Setting window.location.hash to the same path does not cause hashchange to fire
					// which would leave isPushingState true until the next go around, a strange bug
					if(!useReplaceState && window.location.hash !== '#' + statePath){
						_isPushingState = true; // Don't fire the onHashChange event
						window.location.hash = statePath;
					}
				}

				

			},

			buildStateString : function(controller, snapshot){

				var statePath = '';
				
				_state[controller.name] = snapshot; // Add it to the heap of other snapshots
				
				$.each(_state, function(controllerName, snapshot){
					statePath = statePath + '/~' + encodeURIComponent(controllerName);
					$.each(snapshot, function(variable, value){
						
						// If pushState exists, we don't want to save the path in the hash - so skip it
						if(variable !== 'path'){
							// For simple objects use the value, complex objects get JSON-ified
							if(typeof value === 'object' && value.hasOwnProperty('value') && value.hasOwnProperty('uriEncode')){
								value = value.value;
							}else if(typeof value === 'object'){
								value = encodeURIComponent(JSON.stringify(value));
							}else{
								value = encodeURIComponent(value).replace(/%20/g, '+');
							}
							
							if(value.length > 0){
								statePath += '/' + encodeURIComponent(variable) + '/' + value;
							}
						}

					});
				});

				return statePath;
			},

			parseStateFromHash : function(hash){
				var statePath = hash.replace(/\?.*/, '');
				var controllers = statePath.split('/~');
				var state = {};

				$.each(controllers, function(index, controllerPath){

					// Grab the controller name
					var controllerStatePath = controllerPath.split('/');
					var controllerName = controllerStatePath[0];
					
					// Loop through the key/value pairs by 2s
					for(var i = 1; i < controllerStatePath.length; i = i + 2){
						
						state[controllerName] = state[controllerName] || {};

						// Assume the value is a simple object
						state[controllerName][controllerStatePath[i]] = decodeURIComponent(controllerStatePath[i + 1]).replace(/\+/g, ' ');
						
						// Try and decode the JSON - if it's successful, replace the stringified version
						try{
							var object = $.parseJSON(state[controllerName][controllerStatePath[i]]);
							state[controllerName][controllerStatePath[i]] = object;
						}catch(e){ }
					}
				});

				return state;
			},

			pullState : function(controller){
				
				var state = _this.parseStateFromHash(window.location.hash);

				// If they asked for a controller, just send that data, otherwise you get the whole object
				return (controller ? state[controller.name] : state);

			},

			_createGlobalEventObject : function(){
				
				eventData = {
					filename : _this.getFilename(),
					queryParameters : _util.getURLParameters(),
					context : _this.getContext()
				};

				return eventData;
			},

			// requiresNetsuite : function(){
			// 	if(typeof debugAlert === 'undefined'){
			// 		_this.include('/js/vendors/netsuite/interface.js');
			// 		$("head link").last().after("<link rel='stylesheet' href='//d2bghjaa5qmp6f.cloudfront.net/compress/css/css/ns-checkout.scss,/checkout1.0.44.css.css' type='text/css'>");
			// 	}
			// },

			// include : function(filename){
			// 	console.log('Async request for file : ' + filename);
			// 	jQuery.ajaxSetup({ cache:true});
			// 	$('head').append('<script type="text/javascript" src="//d2bghjaa5qmp6f.cloudfront.net/compress/js'+ filename +',/'+ filename + $('#currentScriptVersion').data('version') + '"></script>');
			// },

			initializeGlobalEvents : function(){
				var eventData = _this._createGlobalEventObject();

				console.log('initializeGlobalEvents Fired');

				$(window).resize(
					// We don't want to fire the onResize event every few miliseconds
					// so we use a timer - the function helps keep scope.
					(function(){
						var resizeTimer;
						return function(e, data){

							if(resizeTimer){ clearTimeout(resizeTimer);	}
							
							resizeTimer = setTimeout(function() {
								$(_this).triggerHandler('onResize', eventData);
							}, 100);

						};
					})()
				);


				if(_this.hasPushState()){

					// onPopstate has a wierd implemenation. On firefox it won't fire onPageLoad - but everywhere else
					// it does. We don't want it on page load - and to make it consistant, we check to see if history.state has been
					// set - if it has, then it's NOT a pageLoad. This means any time we call history.pushState, we MUST send some
					// state (generally {} or true, or anything that will evaluate to true)
					$(window).on('popstate', function(e){
						if(history.state){
							$(_this).triggerHandler('onStateChange', eventData);
							$(_this).triggerHandler('onAfterStateChange', eventData);
						}
						//$(_this).triggerHandler(_util.camelCase('on-'+ eventData.filename +'-state-change'), eventData);
					});

				}

				// Our HashChange fallback
				$(window).on('hashchange', function(e){
					if(_isPushingState){
						_isPushingState = false; // Apparently we've pushed, so unset it
						return;
					}
					_isPushingState = false;

					eventData.error = e;

					$(_this).triggerHandler('onStateChange', eventData);
					$(_this).triggerHandler(_util.camelCase('on-'+ eventData.filename +'-state-change'), eventData);
				
				});

				// Fire the onReady and onResize events to initialize anything that relies on them
				$(document).ready(function globalApplicationOnReady(e){

					eventData.error = e;
					
					// $(_this).triggerHandler('onHashChange', eventData);
					// $(_this).triggerHandler(_util.camelCase('on-'+ eventData.filename +'-hash-change'), eventData);
					
					// Defer parsing until the next avaliable moment - this allows the onLoad event to finish firing
					//setTimeout(function(){
						//return function(){
							console.time('Application onRezie, onReady, onAfterReady');
							$(_this).triggerHandler('onResize', eventData);
							$(_this).triggerHandler('onReady', eventData);
							$(_this).triggerHandler('onAfterReady', eventData);
							console.timeEnd('Application onRezie, onReady, onAfterReady');
							
						//};
					//}(eventData), 1);
				});

			},

			init : function(specificController){

				console.log('Initializing Controller', specificController);
				
				console.time('Initializing Events for ' + specificController.name);
				
				var controller, subController, event, asset, controllerObj, subControllerObj;
				
				for (controller in _app.controllers) {
					
					controllerObj = _app.controllers[controller]; // Convience
					
					// Bind Events
					// This binds all of the callbacks (eg. controller.events.onAfterLoginSuccess)
					// to the event controller.onAfterLoginSuccess which is called by the API model object
					for(subController in controllerObj.events){
						
						subControllerObj = _app.controllers[subController]; // Convience
						
						for(event in controllerObj.events[subController]){

							// If we've passed a specific controller - only bind that one, otherwise, in the darkness bind them (all of them)
							if((specificController && (specificController === controllerObj || specificController === subControllerObj)) || !specificController){
								$(subControllerObj)
									.bind(event, function(controllerObj, subController, event){
										// extra closure to give access to controllerObj, subController, and event objects
										return function fireControllerEvent(a, b, c, d){
											console.time("-" + controllerObj.name + ".events." + subController + "." + event);
											controllerObj.events[subController][event](a, b, c, d);
											console.timeEnd("-" + controllerObj.name + ".events." + subController + "." + event);
										};
									}(controllerObj, subController, event));
							}

							// }
						}
					}

					// If the onReady events have already fired, then force this controller along individually
					if(specificController === controllerObj && _isReadyFired){

						//setTimeout(function manuallyInitializeControllerPostReady(){
							if(((controllerObj.events || {}).application || {}).onReady){
								controllerObj.events.application.onReady({}, _this._createGlobalEventObject());
							}
							if(((controllerObj.events || {}).application || {}).onAfterReady){
								controllerObj.events.application.onAfterReady({}, _this._createGlobalEventObject());
							}
							if(((controllerObj.events || {}).application || {}).onAttachEvents){
								controllerObj.events.application.onAttachEvents({}, $.extend({selector : $('html')}, _this._createGlobalEventObject()));
							}
							if(((controllerObj.events || {}).application || {}).onResize){
								_this.events.application.onResize({}, {controller : controllerObj});
							}
						//}, 1);
					}

					// // need to test this, if a controller loads after onready he needs to get onreszie fired too
				}

				$(specificController).triggerHandler('onInit');
				console.timeEnd('Initializing Events for ' + specificController.name);
				
			}

		};
		
		return _this;

	}());
	
	_util.register('controller', 'application', application);
	
	console.time('Application Initialize');
	window.LSP.controllers.application.initializeGlobalEvents();

});

}());
(function(){

define('plugins/reveal',['utilities/global', 'controllers/application'], function(){

	var _util = window.LSP.utilities;

	var reveal = (function(){
		var _this = {};
		var _app = window.LSP;

		var _waitToOpen = false;

		var ANIMATION_TIME = 300;

		_this = {
			name : 'reveal',
			events : {
				reveal : {},
				application : {
					onContextChange : function(e, data){
						$('.reveal-closed-'+ data.previousContext)
							.removeClass('reveal-closed')
							.addClass('reveal-open');

						$('.reveal-closed-'+ data.context)
							.removeClass('reveal-open')
							.addClass('reveal-closed');

						$('.reveal-context-' + data.previousContext)
							.removeClass('reveal-open')
							.removeClass('reveal-closed');
					},
					onAttachEvents : function(e, data){
						_this.bindEvents(data.selector);

					}
				}
			},
			
			assets : {},

			bindEvents : function(parent){
			
				$('*[data-reveal-children]', parent).off('click.reveal').on('click.reveal', function(e){

					// On click - fire the click event
					_this.toggle(_this.buildChildrenSelector(this), !$(this).hasClass('reveal-noAnimation'));

					// We don't want to propagate default browser events
					e.stopPropagation();
					return true;

				});

				// Mouseover reveals
				$('.reveal-showOnMouseover', parent).off('mouseenter.reveal').on('mouseenter.reveal', function(e){
					_this.toggle(_this.buildChildrenSelector(this), !$(e.currentTarget).hasClass('reveal-noAnimation'));
					//return true;
				}).off('mouseleave.reveal').on('mouseleave.reveal', function(e){
					_this.toggle(_this.buildChildrenSelector(this), !$(e.currentTarget).hasClass('reveal-noAnimation'));
					//return true;
				});

				$('.reveal-closed-'+ _app.controllers.application.getContext())
					.removeClass('reveal-open')
					.addClass('reveal-closed');
			},


			unbindEvents : function(parent){
				$('*[data-reveal-children]', parent).off('.reveal');
			},


			buildChildrenSelector : function(element){
				return $('#' + $(element).data('reveal-children').split(' ').join(', #'));
			},

			open : function(children, doAnimations){

				if(!_waitToOpen){

					doAnimations = (typeof doAnimations === 'undefined') ? true : doAnimations;

					// Mark Parents as Open
					children.each(function(index, child){
						// Find it as the only child, and also if it's space seperated
						// Otherwise you'l find partials like id="states" would find "states-main"
						$('*[data-reveal-children="' + child.id + '"], *[data-reveal-children*="' + child.id + ' "] ').addClass('reveal-open').removeClass('reveal-closed');
					})

					if(doAnimations && _app.controllers.application.getContext() !== 'phone'){
						var queue = $({});
						children.each(function(i, child){
							child = $(child);
							queue.queue(function(){
								var control = $(this);
								child
									.css('display', 'none')
									.addClass('reveal-open')
									.slideDown({
										duration : ANIMATION_TIME,
										easing : 'swing',
										complete : function(){
											child
												.addClass('reveal-open')
												.css('display', '')
												.removeClass('reveal-closed');
											control.dequeue();
										}
									});
							});
						});
						
					}else{
						children.addClass('reveal-open').removeClass('reveal-closed');
					}

					//_gaq.push(['_trackEvent', 'reveal', 'open', children.attr('id')]);
				}

			},
			
			close : function(children, doAnimations){


				// Prevents flickering
				_waitToOpen = true;
				setTimeout(function(){
					_waitToOpen = false;
				}, 50)

				doAnimations = (typeof doAnimations === 'undefined') ? true : doAnimations;

				// Mark Parents as Open
				children.each(function(index, child){
					$('*[data-reveal-children*="' + child.id + '"] ').addClass('reveal-closed').removeClass('reveal-open');
				});

				if(doAnimations && _app.controllers.application.getContext() !== 'phone'){
					var queue = $({});

					var children = children.toArray().reverse();

					$.each(children, function(i, child){
						queue.queue(function(){
							var control = $(this);
							$(child)
								.css('display', 'block')
								.slideUp({
									duration : ANIMATION_TIME,
									easing : 'swing',
									complete : function(){
										$(this)
											.removeClass('reveal-open')
											.addClass('reveal-closed')
											.css('display', '');
										control.dequeue();
									}
								});
						});
					});

				}else{
					children.addClass('reveal-closed').removeClass('reveal-open');
				}
				//_gaq.push(['_trackEvent', 'reveal', 'close', children.attr('id')]);
			},

			toggle : function(children, doAnimations){

				var context = _app.controllers.application.getContext();
				var openChildren = children.filter('.reveal-open:not(*[class*="reveal-context"]), .reveal-open.reveal-context-' + context);
				var closedChildren = children.filter('.reveal-closed:not(*[class*="reveal-context"]), .reveal-closed.reveal-context-' + context +', .reveal-context-' + context + ':not(.reveal-open)');

				_this.open(closedChildren, doAnimations);
				_this.close(openChildren, doAnimations);
				
			}
		};

		return _this;
		
	})();

	_util.register('controller', 'reveal', reveal);

});

})();
/**
 * menu-aim is a jQuery plugin for dropdown menus that can differentiate
 * between a user trying hover over a dropdown item vs trying to navigate into
 * a submenu's contents.
 *
 * menu-aim assumes that you have are using a menu with submenus that expand
 * to the menu's right. It will fire events when the user's mouse enters a new
 * dropdown item *and* when that item is being intentionally hovered over.
 *
 * __________________________
 * | Monkeys  >|   Gorilla  |
 * | Gorillas >|   Content  |
 * | Chimps   >|   Here     |
 * |___________|____________|
 *
 * In the above example, "Gorillas" is selected and its submenu content is
 * being shown on the right. Imagine that the user's cursor is hovering over
 * "Gorillas." When they move their mouse into the "Gorilla Content" area, they
 * may briefly hover over "Chimps." This shouldn't close the "Gorilla Content"
 * area.
 *
 * This problem is normally solved using timeouts and delays. menu-aim tries to
 * solve this by detecting the direction of the user's mouse movement. This can
 * make for quicker transitions when navigating up and down the menu. The
 * experience is hopefully similar to amazon.com/'s "Shop by Department"
 * dropdown.
 *
 * Use like so:
 *
 *      $("#menu").menuAim({
 *          activate: $.noop,  // fired on row activation
 *          deactivate: $.noop  // fired on row deactivation
 *      });
 *
 *  ...to receive events when a menu's row has been purposefully (de)activated.
 *
 * The following options can be passed to menuAim. All functions execute with
 * the relevant row's HTML element as the execution context ('this'):
 *
 *      .menuAim({
 *          // Function to call when a row is purposefully activated. Use this
 *          // to show a submenu's content for the activated row.
 *          activate: function() {},
 *
 *          // Function to call when a row is deactivated.
 *          deactivate: function() {},
 *
 *          // Function to call when mouse enters a menu row. Entering a row
 *          // does not mean the row has been activated, as the user may be
 *          // mousing over to a submenu.
 *          enter: function() {},
 *
 *          // Function to call when mouse exits a menu row.
 *          exit: function() {},
 *
 *          // Selector for identifying which elements in the menu are rows
 *          // that can trigger the above events. Defaults to "> li".
 *          rowSelector: "> li",
 *
 *          // You may have some menu rows that aren't submenus and therefore
 *          // shouldn't ever need to "activate." If so, filter submenu rows w/
 *          // this selector. Defaults to "*" (all elements).
 *          submenuSelector: "*",
 *
 *          // Direction the submenu opens relative to the main menu. Can be
 *          // left, right, above, or below. Defaults to "right".
 *          submenuDirection: "right"
 *      });
 *
 * https://github.com/kamens/jQuery-menu-aim
*/

(function(){

define('vendors/menu-aim/menu-aim',['jquery'], function(){

(function($) {

	$.fn.menuAim = function(opts) {
		// Initialize menu-aim for all elements in jQuery collection
		this.each(function() {
			init.call(this, opts);
		});

		return this;
	};

	function init(opts) {
		var $menu = $(this),
			activeRow = null,
			mouseLocs = [],
			lastDelayLoc = null,
			timeoutId = null,
			exitTimeoutId = null,
			options = $.extend({
				rowSelector: "> li",
				submenuSelector: "*",
				submenuDirection: "right",
				tolerance: 75,  // bigger = more forgivey when entering submenu
				enter: $.noop,
				exit: $.noop,
				activate: $.noop,
				deactivate: $.noop,
				exitMenu: $.noop,
				exitTimeout: 0, // NEW from LSP
				afterExitMenu : $.noop // NEW from LSP
			}, opts);

		var MOUSE_LOCS_TRACKED = 3,  // number of past mouse locations to track
			DELAY = 300;  // ms delay when user appears to be entering submenu

		/**
		 * Keep track of the last few locations of the mouse.
		 */
		var mousemoveDocument = function(e) {
				mouseLocs.push({x: e.pageX, y: e.pageY});

				if (mouseLocs.length > MOUSE_LOCS_TRACKED) {
					mouseLocs.shift();
				}
			};

		/**
		 * Cancel possible row activations when leaving the menu entirely
		 */
		var mouseleaveMenu = function() {
				if (timeoutId) {
					clearTimeout(timeoutId);
				}

				// If exitMenu is supplied and returns true, deactivate the
				// currently active row on menu exit.
				if (options.exitMenu(this)) {
					
					exitTimeoutId = setTimeout(function(){
						if (activeRow) {
							options.deactivate(activeRow);
						}

						activeRow = null;
						options.afterExitMenu();

					}, options.exitTimeout);
					
				}
			};

		/**
		 * Trigger a possible row activation whenever entering a new row.
		 */
		var mouseenterRow = function() {
				if (timeoutId) {
					// Cancel any previous activation delays
					clearTimeout(timeoutId);
				}
				if(exitTimeoutId){
					clearTimeout(exitTimeoutId);
				}

				options.enter(this);
				possiblyActivate(this);
			},
			mouseleaveRow = function() {
				options.exit(this);
			};

		/*
		 * Immediately activate a row if the user clicks on it.
		 */
		var clickRow = function() {
				activate(this);
			};

		/**
		 * Activate a menu row.
		 */
		var activate = function(row) {
				if (row == activeRow) {
					return;
				}

				if (activeRow) {
					options.deactivate(activeRow);
				}

				options.activate(row);
				activeRow = row;
			};

		/**
		 * Possibly activate a menu row. If mouse movement indicates that we
		 * shouldn't activate yet because user may be trying to enter
		 * a submenu's content, then delay and check again later.
		 */
		var possiblyActivate = function(row) {
				var delay = activationDelay();

				if (delay) {
					timeoutId = setTimeout(function() {
						possiblyActivate(row);
					}, delay);
				} else {
					activate(row);
				}
			};

		/**
		 * Return the amount of time that should be used as a delay before the
		 * currently hovered row is activated.
		 *
		 * Returns 0 if the activation should happen immediately. Otherwise,
		 * returns the number of milliseconds that should be delayed before
		 * checking again to see if the row should be activated.
		 */
		var activationDelay = function() {
				if (!activeRow || !$(activeRow).is(options.submenuSelector)) {
					// If there is no other submenu row already active, then
					// go ahead and activate immediately.
					return 0;
				}

				var offset = $menu.offset(),
					upperLeft = {
						x: offset.left,
						y: offset.top - options.tolerance
					},
					upperRight = {
						x: offset.left + $menu.outerWidth(),
						y: upperLeft.y
					},
					lowerLeft = {
						x: offset.left,
						y: offset.top + $menu.outerHeight() + options.tolerance
					},
					lowerRight = {
						x: offset.left + $menu.outerWidth(),
						y: lowerLeft.y
					},
					loc = mouseLocs[mouseLocs.length - 1],
					prevLoc = mouseLocs[0];

				if (!loc) {
					return 0;
				}

				if (!prevLoc) {
					prevLoc = loc;
				}

				if (prevLoc.x < offset.left || prevLoc.x > lowerRight.x ||
					prevLoc.y < offset.top || prevLoc.y > lowerRight.y) {
					// If the previous mouse location was outside of the entire
					// menu's bounds, immediately activate.
					return 0;
				}

				if (lastDelayLoc &&
						loc.x == lastDelayLoc.x && loc.y == lastDelayLoc.y) {
					// If the mouse hasn't moved since the last time we checked
					// for activation status, immediately activate.
					return 0;
				}

				// Detect if the user is moving towards the currently activated
				// submenu.
				//
				// If the mouse is heading relatively clearly towards
				// the submenu's content, we should wait and give the user more
				// time before activating a new row. If the mouse is heading
				// elsewhere, we can immediately activate a new row.
				//
				// We detect this by calculating the slope formed between the
				// current mouse location and the upper/lower right points of
				// the menu. We do the same for the previous mouse location.
				// If the current mouse location's slopes are
				// increasing/decreasing appropriately compared to the
				// previous's, we know the user is moving toward the submenu.
				//
				// Note that since the y-axis increases as the cursor moves
				// down the screen, we are looking for the slope between the
				// cursor and the upper right corner to decrease over time, not
				// increase (somewhat counterintuitively).
				function slope(a, b) {
					return (b.y - a.y) / (b.x - a.x);
				};

				var decreasingCorner = upperRight,
					increasingCorner = lowerRight;

				// Our expectations for decreasing or increasing slope values
				// depends on which direction the submenu opens relative to the
				// main menu. By default, if the menu opens on the right, we
				// expect the slope between the cursor and the upper right
				// corner to decrease over time, as explained above. If the
				// submenu opens in a different direction, we change our slope
				// expectations.
				if (options.submenuDirection == "left") {
					decreasingCorner = lowerLeft;
					increasingCorner = upperLeft;
				} else if (options.submenuDirection == "below") {
					decreasingCorner = lowerRight;
					increasingCorner = lowerLeft;
				} else if (options.submenuDirection == "above") {
					decreasingCorner = upperLeft;
					increasingCorner = upperRight;
				}

				var decreasingSlope = slope(loc, decreasingCorner),
					increasingSlope = slope(loc, increasingCorner),
					prevDecreasingSlope = slope(prevLoc, decreasingCorner),
					prevIncreasingSlope = slope(prevLoc, increasingCorner);

				if (decreasingSlope < prevDecreasingSlope &&
						increasingSlope > prevIncreasingSlope) {
					// Mouse is moving from previous location towards the
					// currently activated submenu. Delay before activating a
					// new menu row, because user may be moving into submenu.
					lastDelayLoc = loc;
					return DELAY;
				}

				lastDelayLoc = null;
				return 0;
			};

		/**
		 * Hook up initial menu events
		 */
		 // Added namespacing
		$menu
			.on("mouseleave.menuaim", mouseleaveMenu)
			.find(options.rowSelector)
				.on("mouseenter.menuaim", mouseenterRow)
				.on("mouseleave.menuaim", mouseleaveRow)
				.on("click.menuaim", clickRow);

		$(document).mousemove(mousemoveDocument);

	};
})(jQuery);

});

}());
(function(){

define('plugins/flyout',['utilities/global', 'controllers/application', 'plugins/reveal', 'vendors/menu-aim/menu-aim'], function(){

	var _util = window.LSP.utilities;

	_util.register('controller', 'flyout', (function(){
		var _this = {};
		var _lsp = window.LSP;
		
		var _flyout;
		var _flyoutControlButton;
		var _flyoutParent;

		var _isOpen = false;
		var _currentFlyoutTween;
		
		var _holdOpen = false;
		var _waitToOpen = false;
		var _isOpen = false;
		var _isOpenFromClick = false;
		var _isClosedFromClick = false;
		var _waitToCloseFromClick = false;
		var _topLevelTimeout; // Used when _holdOpen is true, waits to open flyout

		var _revealController = _lsp.controllers.reveal;

		var OPEN_SPEED = 150;
		var EXIT_TIMEOUT = 500;
		var ENTER_TIMEOUT = 250;

		_this =  {
			name : 'flyout',
			events : {
				application : {
					onContextChangeLeavePhone : function(e, data){
						_this.attachMenu();
					},
					onContextChangeEnterPhone : function(e, data){
						_this.detachMenu();
					},

					// We want to make sure we fire after reveal.js (which uses onReady)
					onAfterReady : function(e, data){
						if(_lsp.controllers.application.getContext() !== 'phone'){
							_this.attachMenu();
						}
						if(document.location.href.indexOf('netsuite') > 0){
							_this.closeFlyout(true);
						}
					}
				}
			},
			assets : {},


			attachMenu : function(){

				// Release to the browser
				//setTimeout(function(){

					var _holdOpenFlyoutTimeout; // When the menu is holdOpen
												// we need to wait to activate a row
												// for the first time

					_flyoutControlButton = $('#flyoutControlButton');
					_flyout = $('#mainFlyout');
					_flyoutParent = $('#mainFlyout .topLevel');

					// Unbind the native reveal functionality
					if(_revealController){
						_revealController.unbindEvents(_flyoutParent);
					}

					// Create the menu
					_flyoutParent.menuAim({
						activate : _this.showRow,
						deactivate : _this.hideRow,
						exitTimeout : EXIT_TIMEOUT,
						exitMenu : function(){
							return true;
						},
						afterExitMenu : function(){
							_isOpen = false;
							_waitToOpen = _holdOpen;
							clearTimeout(_topLevelTimeout);
						}
					});

					// I'm using annynomus functions here to hide the event
					// argument from the controller methods. You shouldn't expect
					// openFlyout or closeFlyout to rely on the event - it's possible
					// to force it open from elsewhere (like on the home page)
					var closeTimeout;
					var openTimeout;
					
					// Control Button
					_flyoutControlButton.off('.flyout').on('mouseenter.lsp.flyout', function(e){ 
						if(!_isOpen && !_isClosedFromClick){
							openTimeout = setTimeout(_this.openFlyout, ENTER_TIMEOUT); // Start the timer
						}
					}).on('mouseleave.lsp.flyout', function(e){
						clearTimeout(openTimeout); // Clear timeout on exit

					}).on('click.lsp.flyout', function(e){
						_isOpenFromClick = !_isOpen;
						_isClosedFromClick = !_isOpenFromClick;
						_waitToCloseFromClick = true;
						_this.toggleFlyout();
						if(_isClosedFromClick){
							setTimeout(function(){
								_isClosedFromClick = false;
							}, 800);
						}
					});

					$('.topLevel').off('.flyout').on('click.lsp.flyout', function(e){
						_flyoutControlButton.click();
						e.stopPropagation();
					});
					$('.topLevel li').off('.flyout').on('click.lsp.flyout', function(e){
						e.stopPropagation();
					});

					// Container
					$('.container', _flyout).on('mouseenter.lsp.flyout', function(e){
						clearTimeout(closeTimeout);
					});

					// Wrapper
					$('.wrapper', _flyout).on('mouseleave.lsp.flyout', function(e){
						//clearTimeout(timeout);
						if(!_waitToCloseFromClick){
							closeTimeout = setTimeout(_this.closeFlyout, EXIT_TIMEOUT);
							clearTimeout(_topLevelTimeout);
						}
						_waitToCloseFromClick = false;
						e.stopPropagation();
					});

					// Trigger Event
					$(this).triggerHandler('onAfterAttach', {selector : _flyout});
				//}, 0);
			},

			detachMenu : function(){
				// If the flyout exists, destroy it
				if(_flyout){
					_this.closeFlyout();
					$('*', _flyout).off('.menuaim');
					_flyoutControlButton.off('.flyout');
					$('.wrapper', _flyout).off('.flyout');
				}

				// Rebind the reveal events
				if(_revealController){
					_revealController.bindEvents(_flyoutParent);
				}

			},
			
			// Opens the flyout, set holdOpen to true, and the menu will remain open
			// even when mousing out. holdOpen will also add a timeout to row activation
			// much in the same way there is a timeout on the main flyout button
			openFlyout : function(holdOpen){
				_holdOpen = holdOpen || false;
				_waitToOpen = _holdOpen;
				_isOpen = true;

				if(_flyout){
					_flyout.addClass('active');
					_flyoutControlButton.addClass('active');
					_util.scrollTo($('.collection:first-child', _flyout));
				}
			},

			closeFlyout : function(reset){

				if(_flyout){ // Only if attachMenu has been called
					clearTimeout(_topLevelTimeout);

					_isOpen = false;

					// This is used to put the home page flyout back to normal
					if(reset){
						_holdOpen = false;
						_waitToOpen = false;
					}

					if(!_holdOpen){
						_flyout.removeClass('active');
						_flyoutControlButton.removeClass('active');
						$('li.collection.active', _flyout).removeClass('active');

						// Finish any lingering animations
						if(_currentFlyoutTween){
							$(_currentFlyoutTween.elem).stop(true, true);
						}
						_currentFlyoutTween = null;

						_isOpen = false;
					}

					//_this.attachMenu(); // Reset
				}else{
					// Is in the phone, so close the reveals
					_lsp.controllers.reveal.close($('#mainFlyout, #mainFlyout *[data-reveal-children]'), false);
				}
			},
			toggleFlyout : function(){
				if(_isOpen){
					_this.closeFlyout();
				}else{
					_this.openFlyout();
				}
			},

			showRow : function(element, forceShow){

				// We want to wait to open it if it's _holdOpen, and
				// if it hasn't already been opened (_waitToOpen)
				// forceShow is a way to avoid having two functions
				// the timeout just calls itself again with the flag
				if(_holdOpen && _waitToOpen && !forceShow){
					
					clearTimeout(_topLevelTimeout);
					
					_topLevelTimeout = setTimeout(function(){
						_this.showRow(element, true);
					}, ENTER_TIMEOUT);

				}else{
								
					// Reset the close timeout
					element = $(element);
					_waitToOpen = false;

					if(!_isOpen){

						// Because the content windows are all unique
						// we need to 'transfer' the animation to the new
						// content window to create a seemless slide right

						// We do this by storing the tween object, and hijacking it
						// mid-animation -- there is a little cleanup work to be done
						// after doing this
						
						var flyout = $('.flyout', element);
						

						if(_currentFlyoutTween){
							// Animation in progress, hijack it!
							$(_currentFlyoutTween.elem).removeAttr('style'); // Cleanup!
							$(flyout[0]).css({'width' : _currentFlyoutTween.now, 'overflow' : 'hidden'}); // we are likely between frames, this helps smooth the transition
							_currentFlyoutTween.elem = flyout[0]; // Hijack it.

						}else{

							var width = flyout.outerWidth();
							
							// No animation has started, so create one
							flyout
								.css({width : 0})
								.animate({width: width}, {
									duration : OPEN_SPEED,
									easing : 'swing',
									step : function(a, tween){
										// on each frame, store the tween object
										// we really only need to do this once (not every step)- but this is the
										// only place I found we have access to the tween object
										_currentFlyoutTween = tween;
									},
									always : function(e){
										$('.flyout[style]', _flyout).css({width: ''}); // atomic cleanup, why?
										_currentFlyoutTween = null; // cleanup
										_isOpen = true; // prevent the animation from happening again
									}
								});
						}

					}

					// We have to use a class rather than just the :hover
					// pesduo element because it's possible to
					// hover an item but not be active (the whole reason
					// we are using this plugin)
					
					element.addClass('active');
					if(element.unveil){
						$('*[data-src]', element).unveil();
					}
				}
			},
			hideRow : function(element){
				$(element).removeClass('active');
			}
		};

		return _this;
		
	})());

});

})();
(function(){

define('models/api',['utilities/global', 'controllers/application'], function(){
	
	var _app = window.LSP;
	var _util = _app.utilities;

	// This is a generic API model that can be extended to overwrite : 
	//      _url - returns the url for the service
	//      _payload - formats the payload as nessesary
	//      _isSuccess - often services will not use HTTP status codes to
	//                   return actual request success/failure - you can write custom
	//                   logic here that will 'fail' a successful query
	//
	// Use like : $.extend({ _url : function(payload){ console.log('custom code'); }, _app.models.api)

	_util.register('model', 'api', {
		
		_timeout : 15000,

		_url : function(controller, payload){
			return '';
		},
		_payload : function(controller, payload){
			return payload;
		},
		_isSuccess : function(responseData){
			return (responseData || {}).success === true;
		},
		_afterSuccess : function(responseData){
			return responseData;
		},
		_request : function(type, dataType, controller, eventName, payload, passthrough){
		
			var result = $.Deferred();
			var eventData = {};
			
			$.support.cors = true;

			eventData.xhrData = {
				type : type,
				url : this._url(controller, payload),
				data : this._payload(controller, payload),
				crossDomain : true,
				dataType : dataType,
				context : this,
				timeout : this._timeout,
				passthrough : $.extend({}, passthrough)
			};
			
			// TODO : use $.extend

			// for(var key in payload){
			// 	if(payload.hasOwnProperty(key)){ eventData.xhrData.data[key] = payload[key]; } 
			// } // Merge objects
			
			console.log('API Request Sent via ' + eventName, eventData.xhrData);
			
			$(_app.controllers.application).triggerHandler('onBeforeAPICall', eventData);
			$(controller).triggerHandler('onBeforeAPICall', eventData);
			$(controller).triggerHandler(_util.camelCase('on-Before-API-'+eventName+'-call'), eventData);
			
			$.ajax(eventData.xhrData).done(function(responseData){
				
				eventData.serverResponse = responseData; // raw response needs a differnt property name
				try{
					eventData.response = $.parseJSON(responseData);
				}catch(e){
					eventData.response = responseData;
				}   

				if(this._isSuccess(responseData)){
					eventData.response = this._afterSuccess(eventData.response);
					result.resolve(eventData);
				}else{
					eventData.error = 'invalidFormat';
					result.reject(eventData);
				}
				
			}).fail(function(responseData){

				// jQuery dosen't auto-parse JSON data for failures
				eventData.serverResponse = responseData; // raw response needs a differnt property name
				try{
					eventData.response = $.parseJSON(responseData.responseText);
				}catch(e){
					eventData.response = responseData;
				}
				
				result.reject(eventData);
				
			}).always(function(){
				console.log('API Response Recieved via ' + eventName, eventData);
			});


			// By seperating the logic like this -- it allows us to "fail" a success HTTP response (see the .done() method above)
			$.when(result).done(function(responseData){
				
				// Fire onAfterMethodSuccess event
				// Fire mb.controllers.application's onAfterAPICallSuccess
				$(_app.controllers.application).triggerHandler('onAfterAPICallSuccess', responseData);
				$(controller).triggerHandler('onAfterAPICallSuccess', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName+'-success'), responseData);
				// $('body').addClass(controller.name + '-downloadSuccess');
				
			}).fail(function(responseData){
				
				// Fire onAfterMethodFailure event
				// Fire mb.controllers.application's onAfterAPICallFailure
				$(_app.controllers.application).triggerHandler('onAfterAPICallFailure', responseData);
				$(controller).triggerHandler('onAfterAPICallFailure', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName+'-failure'), responseData);
				// $('body').addClass(controller.name + '-downloadFailure');
				
			}).always(function(responseData){
				
				$(_app.controllers.application).triggerHandler('onAfterAPICall', responseData);
				$(controller).triggerHandler('onAfterAPICall', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName), responseData);
				// $('body').removeClass(controller.name + '-downloadWaiting');
				
			});

			return result.promise();
		},

		request : function(controller, eventName, method, data){
			return this._request('GET', 'jsonp', controller, eventName, method, data);
		}
	});

});
	
}());

(function(){

define('models/easyask',['utilities/global', 'controllers/application', 'models/api'], function(){

	var _util = window.LSP.utilities;
	var _models = window.LSP.models;
	
	_util.register('model', 'easyask', (function(){

		var _this = $.extend({}, _models.api);

		// var _dictionary = 'EcomDemo';
		// var _hostname = 'http://easyaskqa.easyaskondemand.com';
		
		var _dictionary = 'nslonestarpercussion';
		var _hostname = 'http://lonestarpercussion.prod.easyaskondemand.com';
		var _sessionId;

		var _attributeHistory = {};

		// Extends the generic API
		return $.extend(_this, {

			_timeout : 30000,

			_url : function(controller, payload){
				return _hostname + '/EasyAsk/apps/Advisor.jsp';
			},
			_payload : function(controller, payload){


				// payload : 
				// 	{sort, resultsPerPage, page, category, attributes ({thing : [thing1, thing2]}), keywords, action ('advisor'), method ('CA_Search')}

				var formattedPayload = {
					RequestAction : payload.action,
					RequestData : payload.method,
					currentpage : payload.page || 1,
					forcepage : 1,
					ResultsPerPage : payload.resultsPerPage || 24,
					defsortcols : (payload.sort === 'default' ? '' : payload.sort),
					indexed : 1, 
					rootprods : 1,
					oneshot : 1,
					//sessionID : _sessionId,
					defarrangeby : '///NONE///',
					disp : 'json',
					dct : _dictionary,
					q : (payload.keywords && payload.keywords.length) ? payload.keywords : undefined,
					AttribSel : _this.combineSimilarAttributesForRequest(payload.attribute, payload.allAttributes)
				};

				// if(payload.isSingleSelect){
				// 	formattedPayload.CatPath = payload.category;
				// 	formattedPayload.AttribSel = this.buildSingleAttributeString(payload.allAttributes);
				// }else{
				// 	// Build the category path by hand
				formattedPayload.CatPath = _util.cleanArray([(payload.category || '').replace('All Products', '') , _this.combineAndRemoveAllForPath(payload.attribute, payload.allAttributes), this.buildKeywordString(payload.keywords)])
					.join('/')
					.replace(/^\/{1,}-/, '-'); // It's possible it get a keyword search like /-keyword... which is interpreted as a category, it's best to clean this up
				//}

				if($.isEmptyObject(payload.allAttributes) && !payload.attribute && payload.method === 'CA_AttributeSelected'){
					formattedPayload.RequestData = 'CA_BreadcrumbClick'; // If there are no attributes, just load the category
				}

				// If we are trying to remove the last breadcrumb - this was a weird bug, and I'm still not super sure if it's
				// totally fixed.
				if(formattedPayload.RequestData === 'CA_BreadcrumbRemove' && !formattedPayload.q && !formattedPayload.AttribSel){
					formattedPayload.RequestData = 'CA_CategoryExpand';
				}

				if(formattedPayload.RequestData !== 'CA_Search'){
					delete formattedPayload.q;
				}

				if(formattedPayload.ResultsPerPage > 96 || (formattedPayload.ResultsPerPage + '' || '').toLowerCase() === 'all'){
					formattedPayload.ResultsPerPage = 96;
				}

				// As a form of cleanup - remove a trailing / from a category request
				formattedPayload.CatPath = formattedPayload.CatPath.replace(/\/$/, '').replace(/^\//, '').replace(/\/\//g, '/'); // Remove trailing / if it exists

				return formattedPayload;			
			},

			_isSuccess : function(responseData){
				return (responseData || {}).returnCode === 0;
			},

			isRedirect : function(responseData){
				return /((http|https)(:\/\/))?([a-zA-Z0-9]+[.]{1}){2}[a-zA-z0-9]+(\/{1}[a-zA-Z0-9]+)*\/?/.test(responseData.errorMsg) || /^\//.test(responseData.errorMsg); 
			},

			_afterSuccess : function(responseData){

				if(_this.isRedirect(responseData)){
					document.location = responseData.errorMsg;
					return;
				}
				
				_sessionId = responseData.sessionID;

				responseData.source = _this.clean(responseData.source);
				
				responseData.source.navPath._lsp = responseData.source.navPath._lsp || {};
				responseData.source.navPath._lsp.categoryNodes = _this.getCategoryNodes(responseData.source);
				responseData.source.navPath._lsp.refinementNodes = _this.getRefinementNodes(responseData.source);
				responseData.source.navPath._lsp.searchNode = _this.getSearchNode(responseData.source);
				
				this.cacheAttributes(responseData.source);
				responseData.source.attributes = responseData.source.attributes || {};
				responseData.source.attributes._lsp = responseData.source.attributes._lsp || {};
				responseData.source.attributes._lsp.cached = _this.injectCachedAttributes(responseData.source);

				responseData.source._lsp = responseData.source._lsp || {};
				responseData.source._lsp.query = _this.parseCommentaryForDidYouMean(responseData.source.commentary);

				for(var i = 0; i < ((responseData.source.products || {}).items || {}).length; i++){
					if(responseData.source.products.items[i].Matrix_Values){
						var children = $.parseJSON(responseData.source.products.items[i].Matrix_Values);
						responseData.source.products.items[i]._formattedMatrixObject = _this.parseMatrixChildren(children);
					}
				}

				return responseData;
			},

			clean : function(easyAskDataSourceObject){

				// Categories - Remove 'School'
				for(var i = 0; i < ((easyAskDataSourceObject.categories || {}).categoryList || []).length; i++){
					if(easyAskDataSourceObject.categories.categoryList[i].name === 'Schools'){
						easyAskDataSourceObject.categories.categoryList.splice(i, 1);
						i--;
					}
				}
				
				// if(((easyAskDataSourceObject.categories || {}).categoryList || []).length === 0){
				// 	delete easyAskDataSourceObject.categories;
				// }

				// Refinements
				var value;
				for(var i = 0; i < ((easyAskDataSourceObject.attributes || {}).attribute || {}).length; i++){
					for(var j = 0; j < (easyAskDataSourceObject.attributes.attribute[i].attributeValueList || {}).length; j++){
						value = easyAskDataSourceObject.attributes.attribute[i].attributeValueList[j].attributeValue;
						if(value.substr(0, 1) === '!' || value === 'None' || value === 'Unknown' || value === 'Required'){
							easyAskDataSourceObject.attributes.attribute[i].attributeValueList.splice(j, 1);
							j--;
						}
					}
					for(var j = 0; j < (easyAskDataSourceObject.attributes.attribute[i].initialAttributeValueList || {}).length; j++){
						value = easyAskDataSourceObject.attributes.attribute[i].initialAttributeValueList[j].attributeValue;
						if(value.substr(0, 1) === '!' || value === 'None' || value === 'Unknown' || value === 'Required'){
							easyAskDataSourceObject.attributes.attribute[i].initialAttributeValueList.splice(j, 1);
							easyAskDataSourceObject.attributes.attribute[i].initDispLimit--;
							j--;
						}
					}
					if(easyAskDataSourceObject.attributes.attribute[i].attributeValueList.length === 0){
						easyAskDataSourceObject.attributes.attribute.splice(i, 1);
						i--;
					}
				}

				if(((easyAskDataSourceObject.attributes || {}).attribute || []).length === 0){
					delete easyAskDataSourceObject.attributes;
				}

				return easyAskDataSourceObject;
			
			},


			// AttribSel needs to have all the options for a particular attribute
			// in the same request -- some of those are contained in the path - so
			// we need to remove them from the path, and add them to the AttribSel
			// parameter - combineAndRemoveAllForPath removes them for the path
			combineAndRemoveAllForPath : function(singleAttribute, allAttributes){
				if(allAttributes && singleAttribute){

					var singleAttributeName = singleAttribute.replace(/:.*/, '');
					allAttributes = allAttributes.split('/');

					for(var i = 0; i < allAttributes.length; i++){
						if(allAttributes[i].replace(/:.*/, '') === singleAttributeName){
							allAttributes.splice(i, 1);
							i--;
						}
					}
					return allAttributes.join('/');
				}

				return allAttributes;
				
			},

			// AttribSel needs to have all the options for a particular attribute
			// in the same request -- some of those are contained in the path - so
			// we need to remove them from the path, and add them to the AttribSel
			// parameter - combineSimilarAttributesForRequest combines them for
			// the request
			combineSimilarAttributesForRequest : function(singleAttribute, allAttributes){
				
				if(allAttributes && singleAttribute){

					var singleAttributeName = singleAttribute.replace(/:.*/, '');
					allAttributes = allAttributes.split('/');

					for(var i = 0; i < allAttributes.length; i++){
						if(allAttributes[i].replace(/:.*/, '') === singleAttributeName){
							singleAttribute += ';' + allAttributes[i];
						}
					}

					return singleAttribute;
				}

				return singleAttribute;
			},

			buildKeywordString : function(keywords){
				return (keywords ? ('-' + keywords).replace(/-{1,}/, '-') : null);
			},

			// buildMultiAttributeString : function(attributeHashMap){
				
			// 	var attributes = [];

			// 	if(attributeHashMap){
			// 		$.each(attributeHashMap, function(name, valueArray){

			// 			var selections = [];

			// 			$.each(valueArray, function(index, selectedValue){
			// 				// If index is null (it's the first index) add attribSel to the name
			// 				selections.push(selectedValue);
			// 			});

			// 			attributes.push(selections.join(';'));

			// 		});
			// 	}

			// 	return _util.cleanArray(attributes).join('/');

			// },

			buildSingleAttributeString : function(attributeHashMap){
				return this.buildMultiAttributeString(attributeHashMap).replace('AttribSelect=', '').replace(/\/\/\/\/*/, '');
			},

			clearCachedAttributes : function(){
				_attributeHistory = {};
			},

			cacheAttributes : function(easyAskDataSourceObject){

				var returnAttributeMap = {};


				// Mark everything as 'cached'
				$.each(_attributeHistory, function(i, cachedAttribute){
					_attributeHistory[cachedAttribute.attribute.name].isFromCached = true;
				});

				// Add all returned attributes to the cache, marking them as not cached
				for(var i = 0; i < ((easyAskDataSourceObject.attributes || {}).attribute || {}).length; i++){
					var attribute = easyAskDataSourceObject.attributes.attribute[i];
					_attributeHistory[attribute.name] = {index: i, attribute: attribute, isFromCached: false};
					returnAttributeMap[attribute.name] = true; // Small lookup map
				}

				// Clean cachedAttributes that shoudn't be there
				$.each(_attributeHistory, function(i, cachedAttribute){
					
					// If it's not been returned with Attributes
					var fullPath = $(easyAskDataSourceObject.navPath.navPathNodeList).last()[0].seoPath;
					var attributeSEOName = cachedAttribute.attribute.attributeValueList[0].nodeString.replace(/:.*/, '');

					// If it's neither returned, nor selected, it's ok to delete it from the cache
					if(!returnAttributeMap[cachedAttribute.attribute.name] && fullPath.indexOf(attributeSEOName+':') < 0){					
						delete _attributeHistory[cachedAttribute.attribute.name];
					}
				});

				return returnAttributeMap;

			},

			injectCachedAttributes : function(easyAskDataSourceObject){

				var lspAttributes = [];
				var _attributeHistoryArray = [];

				// Caching attributes and storing them in a map loses ordinality
				// Convert map to array, then sort by index
				$.each(_attributeHistory, function(key, attribute){
					_attributeHistoryArray.push(attribute);
				});
				_attributeHistoryArray.sort(function(a, b){

					if(a.index < b.index) return -1;
					if(a.index > b.index) return 1;
					if(a.isFromCached && !b.isFromCached) return -1;
					if(b.isFromCached && !a.isFromCached) return 1;

					return 0;
				});

				// Loop through cached attributes
				// See if the attribute came down in the response, if it is then use it
				// if it's not - then use the cached version.
				$.each(_attributeHistoryArray, function(i, cachedAttribute){
					var found = false;
					for(var j = 0; j < ((easyAskDataSourceObject.attributes || {}).attribute || {}).length; j++){
						if(easyAskDataSourceObject.attributes.attribute[j].attributeName === cachedAttribute.attribute.name){
							found = true;
							lspAttributes.push(easyAskDataSourceObject.attributes.attribute[j]);
						}
					}
					if(!found){
						lspAttributes.push(cachedAttribute.attribute);
					}

				});

				return this.markSelectedAttributes(easyAskDataSourceObject, lspAttributes);
			},

			markSelectedAttributes : function(easyAskDataSourceObject, attributes){
				
				var attributes = $.extend(true, [], attributes); // attributes is a pointer, we need it passed as a value

				$.each(((easyAskDataSourceObject.navPath || {})._lsp || {}).refinementNodes, function(j, refinementNode){

					// Find the attribute
					for(var i = 0; i < (attributes || {}).length; i++){
						if((attributes[i] || {}).name === refinementNode.attribute){

							// Find the matching value
							for(var j = 0; j < (attributes[i].attributeValueList || {}).length; j++){

								if(refinementNode.value === attributes[i].attributeValueList[j].attributeValue){
									// Mark it as selected
									attributes[i].attributeValueList[j].selected = true;
									break;
								}
							}

							break; // stop after the first attribute
						}
					}

					
				});

				return attributes;

			},

			getCategoryNodes : function(easyAskDataSourceObject){
				
				var categoryNodes = [];
				var navPathNodeList = easyAskDataSourceObject.navPath.navPathNodeList;
				var pureCategoryPath = this.getCategoriesFromSEOPath(navPathNodeList[navPathNodeList.length - 1].seoPath);

				// Creates a list of just category nodes, and adds a convinient removePath property
				for(var i = 0; i < easyAskDataSourceObject.navPath.navPathNodeList.length; i++){
					if(navPathNodeList[i].navNodePathType === 1){
						
						navPathNodeList[i].englishName = navPathNodeList[i].englishName.replace(/\/$/, '');
						navPathNodeList[i].englishName = (navPathNodeList[i].englishName === 'All-Products' ? 'All Products' : navPathNodeList[i].englishName);

						if(navPathNodeList[i].englishName !== 'All Products' && navPathNodeList[i].englishName !== 'School'){
							var len = categoryNodes.push(navPathNodeList[i]);
							var newCategoryName = categoryNodes[len - 1].seoPath;

							// Grab the stuff after newCategoryName
							categoryNodes[len - 1].removePath = pureCategoryPath.substr(pureCategoryPath.indexOf(newCategoryName) + newCategoryName.length, pureCategoryPath.length);
						}
					}
				}

				return categoryNodes;

			},

			getSearchNode : function(easyAskDataSourceObject){
				for(var i = 0; i < easyAskDataSourceObject.navPath.navPathNodeList.length; i++){
					if(easyAskDataSourceObject.navPath.navPathNodeList[i].navNodePathType === 3){ 
						return easyAskDataSourceObject.navPath.navPathNodeList[i];
					}
				}
			},


			// Creates an array of refinement node objects
			// and splits up each attribute selection into it's own
			// node
			// Is then accessible at .navPath._lsp
			getRefinementNodes : function(easyAskDataSourceObject){
				var attributeNodes = [];

				for(var i = 0; i < easyAskDataSourceObject.navPath.navPathNodeList.length; i++){
					
					var node = easyAskDataSourceObject.navPath.navPathNodeList[i];

					if(node.navNodePathType === 2){ // If it is a refinement

						var fullPath = decodeURIComponent(easyAskDataSourceObject.navPath.fullPath).replace(/\+/g, ' ');

						// A group is a collection of refinements of the same type (two manufactuers, or three diameters)
						var groups = node.englishName.substring(1, node.englishName.length - 2); // Remove starting and trailing parens
						groups = groups.split('\'); (');

						for(var k = 0; k < groups.length; k++){
							
							var attributeNode = groups[k].split('\' or ');

							for(var j = 0; j < attributeNode.length; j++){

								// Easy ask will sometimes append random numbers to the end of node values, and since convertToSEOString
								// can't figure it out - we need to search the seoPath, find and use the right nodeString
								var attribute = attributeNode[j].split(' = \''); // Grab the name [0] and value [1] 
								var initialNodeString = this.convertToSEOString(attribute[0]+':'+attribute[1]); // the part we know
								var additionalText = _util.findBetween(initialNodeString, ';', node.seoPath); // the potential part we don't

								attributeNodes.push({
									attribute : attribute[0],
									value : attribute[1],
									nodeString : initialNodeString + additionalText
								});
							}
						}

						
					}
				}

				return attributeNodes;
			},

			parseMatrixChildren : function(easyAskMatrixArray){

				var optionObject = {};
				var productObject= {};
				var easyAskMatrixArray = (typeof easyAskMatrixArray === 'string' ? $.parseJSON(easyAskMatrixArray) : easyAskMatrixArray) || [];
				
				for(var i = 0; i < easyAskMatrixArray.length; i++){
					var id = easyAskMatrixArray[i][0],
						item = easyAskMatrixArray[i][1].split('|'),
						label = item[0],
						value = item[1],
						index = item[2],
						imageUrl = item[3],
						mpn = item[4],
						onlinePrice = item[5],
						msrp = item[6],
						stockMessage = item[7];
						waysToSave = item[8];
						specialFeature = item[9];

					optionObject[label] = optionObject[label] || {};
					optionObject[label][value] = optionObject[label][value] || [];
					optionObject[label][value].push(id);

					productObject[id] = productObject[id] || {};
					productObject[id].options = productObject[id].options || {};
					productObject[id].options[label] = productObject[id].options[label] || {};
					productObject[id].options[label] = value;

					productObject[id].data = productObject[id].data || {};
					productObject[id].data.imageUrl = imageUrl;
					productObject[id].data.mpn = mpn;
					productObject[id].data.onlinePrice = onlinePrice;
					productObject[id].data.msrp = msrp;
					productObject[id].data.stockMessage = stockMessage;
					productObject[id].data.waysToSave = waysToSave;
					productObject[id].data.specialFeature = specialFeature;

				}

				return {options : optionObject, products : productObject};
			},

			filterMatrixChildren : function(easyAskMatrixData, filters){
				
				var filteredOptionsObject = {};
				var filteredProducts = {};
				
				$.each(easyAskMatrixData.products, function(id, options){
					
					// Loop through the products and check to see if any filters don't match
					for(var key in filters){
						if(filters.hasOwnProperty(key)){
							if(options.options[key] && options.options[key] != filters[key]){
								return;
							}
						}
					}

					// If we make it all the way through the filters, it means the product matches
					filteredProducts[id] = options;

				});

				// Create the options from the products
				$.each(filteredProducts, function(id, options){
					$.each(options.options, function(label, value){

						// // If option isn't part of the filters
						if(!filters[label]){
							// We avoid adding filtered options here because 1) state dosen't change like it does
							// for search refinements (where we WANT easyask to return selected attributes, but they don't)
							// and 2) because it makes replacing them easier - just loop through the filteredOptions and if it exists in the object, it needs to get updated.
							filteredOptionsObject[label] = filteredOptionsObject[label] || {};
							filteredOptionsObject[label][value] = filteredOptionsObject[label][value] || [];
							filteredOptionsObject[label][value].push(id);
						}
					});
				});

				return filteredOptionsObject;
			},


			convertToSEOString : function(string){
				return string.replace(/'/g, '') // remove apostrphes which are skipped by the next line
					.replace(/[^A-Za-z0-9:]/g, '-') //Everything not a A-Z or 0-9
					.replace(/-{1,}/g, '-') // two or more -
					.replace(/-$/, '') // end with -
					.replace(/:-/, ':'); // remove starting - from any values
			},

			getCategoriesFromSEOPath : function(seoPath){

				var seoPath = seoPath.split('/');

				for(var i = 0; i < seoPath.length; i++){
					if(seoPath[i].indexOf(':') > 0 || seoPath[i].indexOf('-') === 0){
						seoPath.splice(i, 1);
						i--; // We just removed an element from the array
					}
				}
				
				return seoPath.join('/');
			},

			getRefinementsFromSEOPath : function(seoPath){

				var seoPath = seoPath.split('/');

				for(var i = 0; i < seoPath.length; i++){
					if(seoPath[i].indexOf(':') < 0 || seoPath[i].indexOf('-') === 0){
						seoPath.splice(i, 1);
						i--; // We just removed an element from the array
					}
				}
				
				return seoPath.join('/');
			},

			getKeywordsFromSEOPath : function(seoPath){

				var seoPath = unescape(seoPath).split('/');

				for(var i = 0; i < seoPath.length; i++){
					if(seoPath[i].indexOf('-') === 0){
						return encodeURIComponent(seoPath[i]);
					}
				}

				return '';
			},
			parseCommentaryForDidYouMean : function(commentaryString){
				
				var returnObject = {};

				if(commentaryString.length > 0 && commentaryString.indexOf('Corrected Word') > -1){
					var spaced = commentaryString.split(' ');

					returnObject.originalQuery = _util.findBetween('Corrected Word: ', ' is ', commentaryString);
					returnObject.assumedQuery =  _util.findBetween(' is ', '; ', commentaryString);
					returnObject.otherSuggestions = (_util.findBetween(' could be  ', '~END', commentaryString + '~END') || '').split(', ');

				}
				
				return returnObject;

			}
		});

	}()));

});
	
}());
/**
 * Copyright (c) 2010 Maxim Vasiliev
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @author Maxim Vasiliev
 * Date: 09.09.2010
 * Time: 19:02:33
 */

var form2js = (function()
{
	

	/**
	 * Returns form values represented as Javascript object
	 * "name" attribute defines structure of resulting object
	 *
	 * @param rootNode {Element|String} root form element (or it's id) or array of root elements
	 * @param delimiter {String} structure parts delimiter defaults to '.'
	 * @param skipEmpty {Boolean} should skip empty text values, defaults to true
	 * @param emptyToNull {Boolean} should empty values be converted to null?
	 * @param nodeCallback {Function} custom function to get node value
	 * @param useIdIfEmptyName {Boolean} if true value of id attribute of field will be used if name of field is empty
	 */
	function form2js(rootNode, delimiter, skipEmpty, emptyToNull, nodeCallback, useIdIfEmptyName)
	{
		if (typeof skipEmpty == 'undefined' || skipEmpty == null) skipEmpty = true;
		if (typeof emptyToNull == 'undefined' || emptyToNull == null) emptyToNull = true;
		if (typeof delimiter == 'undefined' || delimiter == null) delimiter = '.';
		if (arguments.length < 6) useIdIfEmptyName = false;

		rootNode = typeof rootNode == 'string' ? document.getElementById(rootNode) : rootNode;

		var formValues = [],
			currNode,
			i = 0;

		/* If rootNode is array - combine values */
		if (rootNode.constructor == Array || (typeof NodeList != 'undefined' && rootNode.constructor == NodeList))
		{
			while(currNode = rootNode[i++])
			{
				formValues = formValues.concat(getFormValues(currNode, nodeCallback, useIdIfEmptyName));
			}
		}
		else
		{
			formValues = getFormValues(rootNode, nodeCallback, useIdIfEmptyName);
		}

		return processNameValues(formValues, skipEmpty, emptyToNull, delimiter);
	}

	/**
	 * Processes collection of { name: 'name', value: 'value' } objects.
	 * @param nameValues
	 * @param skipEmpty if true skips elements with value == '' or value == null
	 * @param delimiter
	 */
	function processNameValues(nameValues, skipEmpty, emptyToNull, delimiter)
	{
		var result = {},
			arrays = {},
			i, j, k, l,
			value,
			nameParts,
			currResult,
			arrNameFull,
			arrName,
			arrIdx,
			namePart,
			name,
			_nameParts;

		for (i = 0; i < nameValues.length; i++)
		{
			value = nameValues[i].value;

			if (emptyToNull && (value === '')) { value = null; }
			if (skipEmpty && (value === '' || value === null)) continue;

			name = nameValues[i].name;
			if (typeof name === 'undefined') continue;

			_nameParts = name.split(delimiter);
			nameParts = [];
			currResult = result;
			arrNameFull = '';

			for(j = 0; j < _nameParts.length; j++)
			{
				namePart = _nameParts[j].split('][');
				if (namePart.length > 1)
				{
					for(k = 0; k < namePart.length; k++)
					{
						if (k == 0)
						{
							namePart[k] = namePart[k] + ']';
						}
						else if (k == namePart.length - 1)
						{
							namePart[k] = '[' + namePart[k];
						}
						else
						{
							namePart[k] = '[' + namePart[k] + ']';
						}

						arrIdx = namePart[k].match(/([a-z_]+)?\[([a-z_][a-z0-9_]+?)\]/i);
						if (arrIdx)
						{
							for(l = 1; l < arrIdx.length; l++)
							{
								if (arrIdx[l]) nameParts.push(arrIdx[l]);
							}
						}
						else{
							nameParts.push(namePart[k]);
						}
					}
				}
				else
					nameParts = nameParts.concat(namePart);
			}

			for (j = 0; j < nameParts.length; j++)
			{
				namePart = nameParts[j];

				if (namePart.indexOf('[]') > -1 && j == nameParts.length - 1)
				{
					arrName = namePart.substr(0, namePart.indexOf('['));
					arrNameFull += arrName;

					if (!currResult[arrName]) currResult[arrName] = [];
					currResult[arrName].push(value);
				}
				else if (namePart.indexOf('[') > -1)
				{
					arrName = namePart.substr(0, namePart.indexOf('['));
					arrIdx = namePart.replace(/(^([a-z_]+)?\[)|(\]$)/gi, '');

					/* Unique array name */
					arrNameFull += '_' + arrName + '_' + arrIdx;

					/*
					 * Because arrIdx in field name can be not zero-based and step can be
					 * other than 1, we can't use them in target array directly.
					 * Instead we're making a hash where key is arrIdx and value is a reference to
					 * added array element
					 */

					if (!arrays[arrNameFull]) arrays[arrNameFull] = {};
					if (arrName != '' && !currResult[arrName]) currResult[arrName] = [];

					if (j == nameParts.length - 1)
					{
						if (arrName == '')
						{
							currResult.push(value);
							arrays[arrNameFull][arrIdx] = currResult[currResult.length - 1];
						}
						else
						{
							currResult[arrName].push(value);
							arrays[arrNameFull][arrIdx] = currResult[arrName][currResult[arrName].length - 1];
						}
					}
					else
					{
						if (!arrays[arrNameFull][arrIdx])
						{
							if ((/^[a-z_]+\[?/i).test(nameParts[j+1])) currResult[arrName].push({});
							else currResult[arrName].push([]);

							arrays[arrNameFull][arrIdx] = currResult[arrName][currResult[arrName].length - 1];
						}
					}

					currResult = arrays[arrNameFull][arrIdx];
				}
				else
				{
					arrNameFull += namePart;

					if (j < nameParts.length - 1) /* Not the last part of name - means object */
					{
						if (!currResult[namePart]) currResult[namePart] = {};
						currResult = currResult[namePart];
					}
					else
					{
						currResult[namePart] = value;
					}
				}
			}
		}

		return result;
	}

    function getFormValues(rootNode, nodeCallback, useIdIfEmptyName)
    {
        var result = extractNodeValues(rootNode, nodeCallback, useIdIfEmptyName);
        return result.length > 0 ? result : getSubFormValues(rootNode, nodeCallback, useIdIfEmptyName);
    }

    function getSubFormValues(rootNode, nodeCallback, useIdIfEmptyName)
	{
		var result = [],
			currentNode = rootNode.firstChild;
		
		while (currentNode)
		{
			result = result.concat(extractNodeValues(currentNode, nodeCallback, useIdIfEmptyName));
			currentNode = currentNode.nextSibling;
		}

		return result;
	}

    function extractNodeValues(node, nodeCallback, useIdIfEmptyName) {
        var callbackResult, fieldValue, result, fieldName = getFieldName(node, useIdIfEmptyName);

        callbackResult = nodeCallback && nodeCallback(node);

        if (callbackResult && callbackResult.name) {
            result = [callbackResult];
        }
        else if (fieldName != '' && node.nodeName.match(/INPUT|TEXTAREA/i)) {
            fieldValue = getFieldValue(node);   
	        if (fieldValue == null && node.type == 'radio')
                result = [];
            else
                result = [ { name: fieldName, value: fieldValue} ];
        }
        else if (fieldName != '' && node.nodeName.match(/SELECT/i)) {
	        fieldValue = getFieldValue(node);
	        result = [ { name: fieldName.replace(/\[\]$/, ''), value: fieldValue } ];
        }
        else {
            result = getSubFormValues(node, nodeCallback, useIdIfEmptyName);
        }

        return result;
    }

	function getFieldName(node, useIdIfEmptyName)
	{
		if (node.name && node.name != '') return node.name;
		else if (useIdIfEmptyName && node.id && node.id != '') return node.id;
		else return '';
	}


	function getFieldValue(fieldNode)
	{
		if (fieldNode.disabled) return null;
		
		switch (fieldNode.nodeName) {
			
			case 'TEXTAREA':
				return $('<div/>').text(fieldNode.value).html(); // Escapes the textarea
				break;
			case 'INPUT':
				switch (fieldNode.type.toLowerCase()) {
					case 'radio':
					case 'checkbox':
						if (fieldNode.checked) return fieldNode.value;
						break;

					case 'button':
					case 'reset':
					case 'submit':
					case 'image':
						return '';
						break;

					default:
						return fieldNode.value;
						break;
				}
				break;

			case 'SELECT':
				return getSelectedOptionValue(fieldNode);
				break;

			default:
				break;
		}

		return null;
	}

	function getSelectedOptionValue(selectNode)
	{
		var multiple = selectNode.multiple,
			result = [],
			options,
			i, l;

		if (!multiple) return selectNode.value;

		for (options = selectNode.getElementsByTagName('option'), i = 0, l = options.length; i < l; i++)
		{
			if (options[i].selected) result.push(options[i].value);
		}

		return result;
	}

	return form2js;

})();

LSP.utilities = LSP.utilities || {};
LSP.utilities.formToObject = form2js;
define("vendors/form2js/form2js", function(){});

(function(){

define('plugins/search',['utilities/global', 'controllers/application', 'models/api', 'models/easyask'], function(){
	
	var _util = window.LSP.utilities;
	
	_util.register('controller', 'search', (function(){
		var _this = {};
		var _app = window.LSP;
		var _api = _app.models.easyask;

		var IS_SINGLE_SELECT = false;

		var _isFirstRequest = true;

		var _state = { };

		var _attributeHistory = []; // [{name : attributeName, state : 'temporary or static'}]

		var _activeDataObject = {};
		// {sort, resultsPerPage, page, category, attributes ({thing : [thing1, thing2]}), keywords, action ('advisor'), method ('CA_Search')}

		_this = {
			events : {
				search : {
					// onBeforeAPICall : function(e, data){
					// 	_state.path = data.xhrData.data.CatPath;
					// 	_app.controllers.application.pushState(_this, _state);
					// },

					onBeforeAPICall : function(e, data){
						var searchTemplate = $('#templates-search-page');

						if(searchTemplate.length){
							var height = $('.page-generic').height();
							$('.page-search').addClass('loading');
						}else{
							alert("Unfortunately it appears the templates can't be loaded, please call to complete your order");
							_gaq.push(['_trackEvent', 'search', 'error', 'templatesCannotBeLoaded']);

							return false;
						}
					},
					
					onAfterAPICall : function(e, data){
						$('.page-search, .page-generic').removeClass('loading');
						$('html').removeClass('search-loading');
						_isFirstRequest = false;
					},

					onAfterAPICallSuccess : function(e, data){

						if(data.response){

							var navPathNodeList = data.response.source.navPath.navPathNodeList;

							// Remove everything except categories, then remove trailing /
							_state.category = (_api.getCategoriesFromSEOPath(navPathNodeList[navPathNodeList.length - 1].seoPath)).replace(/\/$/, '');
							_state.category = _state.category.replace(/\/.*\/.*\//, '/');
							
							_state.allAttributes = (_api.getRefinementsFromSEOPath(navPathNodeList[navPathNodeList.length - 1].seoPath)).replace(/\/$/, '');
							_state.keywords = decodeURIComponent((_api.getKeywordsFromSEOPath(navPathNodeList[navPathNodeList.length - 1].seoPath)).replace(/\-/g, ' ').replace(/^ /, ''));
							_state.page = ((data.response.source.products || {}).itemDescription || {}).currentPage;
							
							// Set the activeDataObject, used to rebuild matrix option selections
							_activeDataObject = data;

							// If we don't scroll first - the scroll position will be saved
							// and you will jump around when clicking the back button
							$.when(_this.scrollToFirst()).done(function(){
								// onReady and onStateChange make use of preventPushState because those requests are
								// administrative and shouldn't create new history entries
								if(!data.xhrData.passthrough.preventPushState){
									_this.pushState();
								}
								
							});
						}
					},

					onAfterAPICallFailure : function(e, data){
						_this.renderFatalError(data);
					},

					onRemoveFilter : function(e, data){

						var name = $(data.selector).data('attribute');
						
						$('#refinementForm input[name="' + name + '[]"][value="' + $(data.selector).data('value') + '"]').attr('checked', false);

						_this.updateHistoryMap(name);
						
						_this.removeFilterAttribute($(data.selector).data('value'));

						var filtered = $(data.selector).data('value').split(':');
						_gaq.push(['_trackEvent', 'search', 'removeFilterAttribute', filtered[0], filtered[1]]);
						
					},

					onSearch : function(e, data){

						var query = $('input[name="searchQuery"]', data.selector).trigger('blur').val() || '';

						if(query.length > 0){
							if(document.location.href.indexOf('https') === -1){						
								$('.mobileSearch .b3').click(); // hide it

								// If the query has text, or if there are searched keywords (even if the query is blank - they must be clearing it)
								if(query !== 'undefined' && query.length || (_state.keywords && (_state.keywords || {}).length)){
									
									// Remove the delete statements if you want search to work within a category
									delete _state.category;
									delete _state.allAttributes;
									_isFirstRequest = false;

									_state.keywords = query; // usually we wait until the response to update the state
															 // but search is unique because it's ubiquious and can be done from anywhere
															 // we might need to redirect (via onBeforeAPICall) and we'll update the state string a little early
									_this.search(query);

								}
							}else{
								document.location = 'http://www.lonestarpercussion.com/#/~search/keywords/' + encodeURIComponent(query);
							}
						}

						_gaq.push(['_trackEvent', 'search', 'keywordSearch', query]);
					},

					// Originally used for suggestions on "did you mean" - but deprecated now
					// onSearch : function(e, data){
					// 	var query = $(data.selector).data('query');
					// 	_this.search(query);
					// 	$('#searchQuery').val(query).change();
					// },

					onRemoveSearch : function(e, data){

						_this.removeSearch();

						$('input[name="searchQuery"]').val('').change();
					},

					onFilterAttribute : function(e, data){

						var name = $(data.selector).attr('name').replace('[]', '');

						_this.updateHistoryMap(name);

						if($(data.selector).is(':checked')){
							_this.addFilterAttribute($(data.selector).val());
						}else{
							_this.removeFilterAttribute($(data.selector).val());
						}
					
						var filtered = $(data.selector).val().split(':');
						_gaq.push(['_trackEvent', 'search', 'filterAttribute', filtered[0], filtered[1]]);
						
					},

					onClearAllRefinements : function(e, data){

						_attributeHistory = [];
						_state.allAttributes = '';
						_state.keywords = '';
						_this.loadCategory(_state.category);

						_gaq.push(['_trackEvent', 'search', 'clearAllRefinements', true]);

					},

					onLoadCategory : function(e, data){
						_this.loadCategory($(data.selector).data('path'), true);
						data.originalEvent.preventDefault();
						_isFirstRequest = false;

						_gaq.push(['_trackEvent', 'search', 'filterCategory', $(data.selector).data('path')]);
					},

					onDestroyAndLoadCategory : function(e, data){

						_isFirstRequest = false;
						
						if(document.location.href.indexOf('https') === -1){
							var url = ($(data.selector).attr('href') + '#').split('#');
						
							var state = (_app.controllers.application.parseStateFromHash(url[1]) || {}).search || {};
							state.category = state.category || url[0];

							//_api.clearCachedAttributes();
							_attributeHistory = [];

							// Force pushState
							if(_this.loadState(state, null, true)){
								$('html').attr('data-path', '').addClass('search-loading');
								_this.scrollToFirst();
								_app.controllers.flyout.closeFlyout();
								data.originalEvent.preventDefault();
							}
						}

						_gaq.push(['_trackEvent', 'search', 'browseToCategory', state.category]);

					},

					onRemoveCategory : function(e, data){
						var path = '/' + _state.category;
						var categoriesToRemove = $(data.selector).data('removepath').split('/');

						// Loop through and remove the sub categories
						for(var i = 0; i < categoriesToRemove.length; i++){
							if(categoriesToRemove[i].length > 0){
								path = (path + '/').replace('/' + categoriesToRemove[i] + '/', '/'); // Begins the phrase
							}
						}
						_this.loadCategory(path.replace(/\/{1,}/g, '/', '/'), true);

						_gaq.push(['_trackEvent', 'search', 'removeCategory', categoriesToRemove]);

					},

					onNextPage : function(e, data){
						_this.paginate('next');
						_gaq.push(['_trackEvent', 'search', 'paginate', 'next']);
					},

					onPreviousPage : function(e, data){
						_this.paginate('prev');
						_gaq.push(['_trackEvent', 'search', 'paginate', 'previous']);
					},

					onSort : function(e, data){
						_state.sort = $(data.selector).val();
						_this.paginate('first');
						_gaq.push(['_trackEvent', 'search', 'sort', $(data.selector).val()]);
					},

					onItemsPerPage : function(e, data){
						_state.resultsPerPage = $(data.selector).val();
						_this.paginate('first');
						_gaq.push(['_trackEvent', 'search', 'resultsPerPage', $(data.selector).val()]);
					},

					onShowCompactView : function(e, data){
						_this.changeView('gridView');
						_this.pushState();
						_gaq.push(['_trackEvent', 'search', 'changeView', 'compact']);
					},

					onShowDetailsView : function(e, data){
						_this.changeView('listView');
						_this.pushState();
						_gaq.push(['_trackEvent', 'search', 'changeView', 'detailed']);
					}
				},

				application : {

					onStateChange : function(e, data){
						if(_app.controllers.application.pullState(_this)){
							_isFirstRequest = false;
							_this.loadCurrentState();
						}else{

							// They hit the back button - so the code is still avliable in .page-generic .. but you have to reinitialize the page
							// $('.page-search').hide();
							// $('.page-generic').show();

							// TODO : load state for pages so back button navigation can be snappy
							if(!_isFirstRequest){
								document.location.reload();
							}
						}
					},

					onReady : function(e, data){
						if(_app.controllers.application.pullState(_this) || ((LSP.config || {}).search || {}).loadCurrentState){
							_this.loadCurrentState();
						}
					},
					
					onInit : function(e, data){
						// Initialize the state
						//_this.pullState(_app.controllers.application.pullState(_this));
					},

					onContextChangeEnterPhone : function(e, data){
						_this.changeView('listView');

					}
				}
			},
			
			assets : {},

			updateHistoryMap : function(name){
				// The basic idea here is, the first time you check a box it gets
				// added to the history, to account unchecking we make sure
				// all of the elements in history are present as checked boxes in the form

				// On the retuning request, the attributes will be marked as "static" or "temporary"
				// and will consequently be rendered differently.
				require(['vendors/form2js/form2js'], function updateHistoryMapRequired(){

					var formObject = _util.formToObject($('#refinementForm')[0]);

					// If it's not part of the history (first time it's been checked), add it to the history
					// We can rely on the fact that doing attribute 1, attribute 2, attribute 1 selection
					// paths will never happen because we will be hiding them

					// If we have unselected another attribute (different from the last selected) then we need to
					// mark the last selected as static. This solves the use case of selecting two "Color" then "Artist" then
					// unselecting a "Color" and "Artist" should "collapse" into it's static form 
					var isInHistory = $.grep(_attributeHistory, function(a){ return a.name === name; }).length;
					if(!isInHistory){
						_attributeHistory.push({name : name, displayState : 'temporary'});
					}else if(_attributeHistory[_attributeHistory.length - 1].name !== name){
						_attributeHistory[_attributeHistory.length - 1].displayState = 'static';
					}

					// Mark everything not curent as static
					for(var i = 0; i < _attributeHistory.length - 1; i++){
						_attributeHistory[i].displayState = 'static';
					}

					// Clear unnessesary history elements
					for(var i = 0; i < _attributeHistory.length; i++){

						// Chop off the last two characters "[]"
						var attributeName = _attributeHistory[i].name;

						// If the history element isn't in the form it means nothing is selected for
						// that attribute any longer
						if(!formObject[attributeName]){
							_attributeHistory.splice(i, 1);
						}
					}

				})
			},

			loadCurrentState : function(){
				// We need to push a state on to the beginning of the stack
				_this.loadState(_app.controllers.application.pullState(_this), {preventPushState : !_isFirstRequest});
			},


			// Prepares the _state object for storing in the path
			getState : function(){
				
				// This keeps other controllers from accidentially modifying state
				var tmpState = $.extend({}, _state);
				
				// If it has push state, delete category, otherwise we need to store it in the hash
				if(_app.controllers.application.hasPushState()){
					delete tmpState.category; // Remove Category from the hash (it's being 'saved' in the URL)
				}

				tmpState.allAttributes = {value : (tmpState.allAttributes || '').replace(/[\/]/g, ','), uriEncode : false};
				tmpState.path = _state.category;

				if(tmpState.allAttributes.value.length === 0){
					delete tmpState.allAttributes;
				}

				return tmpState;

			},

			// Convienice hook to application pushstate
			pushState : function(){

				var pushedState = _this.getState();
				// if isFirstRequest is true, then app.pushState will use history.replaceState instead
				return _app.controllers.application.pushState(_this, pushedState, _isFirstRequest);
			},

			// Reads / parses state and changes the _state object
			pullState : function(state){

				var path = document.location.pathname.replace(/\?.*/, '');

				var _defaultState = {
					// resultsPerPage : '24',
					page : '1',
					// sort : 'default',
					// category : '',
					// allAttributes : ''
					view : (LSP.settings || {}).defaultSearchView || 'listView'
				};

				_state = $.extend({}, _defaultState, (state || {}));

				_state.allAttributes = ((_state || {}).allAttributes || '').replace(/[\|\,]/g, '/');
				
				// If the path has .html in it - remove the filename and use the category
				if(path.indexOf('.html') > -1 && !_state.category){
					_state.category = path.substring(0, path.lastIndexOf("/"));
				}else if(!_state.category){
					_state.category = path;
				}

				// if it's only a /
				_state.category = (_state.category === '/' ? '' : _state.category);
				_state.category = _state.category.replace(/^\//, '');
				_state.category = _state.category.replace(/\/$/, '');

				if(_state.keywords){
					_state.keywords = decodeURIComponent(_state.keywords).replace(/\-/g, ' ').replace(/^ /, '');
				}

				return _state;
			},

			loadState : function(state, passthrough, forcePushState){
				var tmpState = $.extend({}, _state);
				_this.pullState(state);
				
				// Populate the input with the search keywords
				$('input[name="searchQuery"]').val(_state.keywords);
				// Load the state only if the new state is different from the old state (tmpState)
				if(!_util.isEqual(tmpState, _state)){
					if(forcePushState){
						_isFirstRequest = false;
					}

					_this.search(null, passthrough);
					
					return true;
				}
				return false;
			},

			// By keyword
			search : function(keywords, passthrough){

				var payload = {
					action : 'advisor',
					method : 'CA_Search',
					keywords : (keywords === null ? _state.keywords : keywords)
				};

				return _api.request(_this, 'search', $.extend({}, _state, {isSingleSelect : IS_SINGLE_SELECT}, payload), passthrough)
					.done(function(data){
						if(data.response){
							if(((((data.response || {}).source || {}).products || {}).items || []).length === 1 && !((((data.response || {}).source || {})._lsp || {}).query || {}).assumedQuery){
								document.location.replace(data.serverResponse.source.products.items[0].Item_URL);
							}else{
								_this.renderPage(data.response.source);
							}
						}
					});
			},
			removeSearch : function(){

				var payload = {
					action : 'advisor',
					method : 'CA_BreadcrumbRemove'
				};

				delete _state.keywords;

				return _api.request(_this, 'removeSearch', $.extend({}, _state, {isSingleSelect : IS_SINGLE_SELECT}, payload))
					.done(function(data){
						_this.renderPage(data.response.source);
					});
			},

			loadCategory : function(categoryPath, isAtomic){

				var payload = {
					action : 'advisor',
					method : 'CA_CategoryExpand',
					category : (isAtomic ? categoryPath : _state.category.replace(/\/$/, '') + '/' + categoryPath)
				};

				return _api.request(_this, 'loadCategory', $.extend({}, _state, {isSingleSelect : IS_SINGLE_SELECT}, payload))
					.done(function(data){
						_this.renderPage(data.response.source);
					});
			},

			addFilterAttribute : function(attributeSlug){

				var payload = {
					action : 'advisor',
					method : 'CA_AttributeSelected',
					attribute : attributeSlug
				};

				return _api.request(_this, 'filter', $.extend({}, _state, {isSingleSelect : IS_SINGLE_SELECT}, payload))
					.done(function(data){
						_this.renderPage(data.response.source);
					});
			},

			removeFilterAttribute : function(attributeSlug){

				var payload = {
					action : 'advisor',
					method : 'CA_BreadcrumbRemove',
					allAttributes : _state.allAttributes.replace(attributeSlug, '').replace(';;', ';').replace('//', '/').replace(/((\/;)|(;\/))/g, '/').replace(/^[\/;]/, '').replace(/[;\/]$/, '') // remove it, and remove leftover ;;
				};

				return _api.request(_this, 'removeFilter', $.extend({}, _state, {isSingleSelect : IS_SINGLE_SELECT}, payload))
					.done(function(data){
						_this.renderPage(data.response.source);
					});
			},

			// breadcrumbClick : function(bc){
			//	var request = {
			//		requestAction : 'advisor',
			//		requestData : 'CA_BreadcrumbClick'
			//	};
			//	//var url = formURL() + '&RequestAction=advisor&RequestData=CA_BreadcrumbClick&CatPath='+encodeURIComponent(bc);
			//	//invoke(url);
			// },

			// loadPage : function(pageName){
			// 	var payload = {
			// 		action : 'navbar',
			// 		method : 'page' + pageName
			// 	};

			// 	return _api.request(_this, 'loadPage', $.extend({}, _state, payload));
			// },

			// Direction can be [first, last, next, prev]
			paginate: function(direction){

				var payload = {
					action : 'navbar',
					method : ($.isNumeric(direction) ? 'page' + direction : direction),
					currentPage : _state.page
				};

				return _api.request(_this, 'paginate', $.extend({}, _state, payload))
					.done(function(data){
						_this.renderSummary(data.response.source);
						_this.renderProducts(data.response.source);
					});

			},

			// removePathNode : function(node){
				
			// 	var payload = {
			// 		category : _state.category.replace('////' + node, ''),
			// 		RequestAction : 'advisor',
			// 		RequestData : 'CA_BreadcrumbRemove'
			// 	};

			// 	return _api.request(_this, 'removeNode', payload)
			// 		.done(function(data){
			// 			_this.renderPage(data.response.source);
			// 		});
			// },

			changeView : function(viewType){
				if(viewType === 'gridView' || viewType === 'listView'){
					$('#resultsContainer')
						.removeClass('gridView')
						.removeClass('listView')
						.addClass(viewType);

					_state.view = viewType;

					// Trigger New Images
					$('.thumbnail img[data-src][data-lazy-handled]').unveil();
				}
			},

			renderPage : function(easyAskDataObject){

				// if(((easyAskDataObject.products || {}).items ||{}).length === 1){
						
				// 	_util.redirectTo(data.response.source.products.items[0].Item_URL);
				
				// }else{

					// If the page hasn't been injected yet
					if(!$('.page-search').length){

						// We must be on an error page, they don't get the <div class=''
						if(!$('.page-generic').length){
							$('#div__body').addClass('page-generic');
						}
						
						// Doing it via a node rather than directly into the after()
						// prevents the page from shrinking height while rendering
						var pageHTML = _util.parseMicroTemplate('templates-search-page', {});
						var searchPageNode = $.parseHTML(pageHTML);
						$('.page-generic').after(searchPageNode).hide();

						_app.controllers.application.attachEvents($('.page-search'));
					}

					_this.changeView(_state.view);

					$('.page-search').show();
					$('.page-generic').hide();

					// Render Sections
					_this.renderSummary(easyAskDataObject);
					_this.renderSelectedRefinements(easyAskDataObject);
					_this.renderRefinements(easyAskDataObject);
					_this.renderProducts(easyAskDataObject);
					

					//Make page full width if refinements aren't there.
					// if(!easyAskDataObject.navPath._lsp.refinementNodes.length && !easyAskDataObject.attributes.attribute){
					// 	$('#searchTitle, #resultsContainer').removeClass('span9').addClass('span12 row');
					// }else{
					// 	$('#searchTitle, #resultsContainer').removeClass('span12 row').addClass('span9');
					// }
				//}
			},

			scrollToFirst : function(){
				// Scroll To Top
				return _util.scrollTo($('body'));
			},

			renderSummary : function(easyAskDataObject){

				var path = _state.category;
				var currentPageNumber = ((easyAskDataObject.products || {}).itemDescription || {}).currentPage;
				var totalPages = ((easyAskDataObject.products || {}).itemDescription || {}).pageCount;

				var breadcrumbHTML = _util.parseMicroTemplate('templates-search-breadcrumbs', $.extend({}, easyAskDataObject));
				var breadcrumbElement = $('#breadcrumbs').html(breadcrumbHTML);
				_app.controllers.application.attachEvents(breadcrumbElement);
				if(breadcrumbElement.is(':has(button)')){
					breadcrumbElement.parent('.breadcrumbs').removeClass('hide'); // Show the breadcrumbs if they are not empty
				}else{
					breadcrumbElement.parent('.breadcrumbs').addClass('hide');
				}

				var titleHTML = _util.parseMicroTemplate('templates-search-title', $.extend({}, easyAskDataObject));
				_app.controllers.application.attachEvents($('#searchTitle').html(titleHTML));

				$('.currentPageNumber').html(currentPageNumber);
				$('.totalPages').html(totalPages);
				$('.numberOfResults').html(((easyAskDataObject.products || {}).itemDescription || {}).totalItems);

				var sortOrder = ((easyAskDataObject.products || {}).itemDescription || {}).sortOrder || 'default';
				$('select[data-action="sort"]').val(sortOrder.indexOf('EAScore') > -1 ? 'default' : sortOrder);
				$('select[data-action="itemsPerPage"]').val(((easyAskDataObject.products || {}).itemDescription || {}).resultsPerPage);

				if(currentPageNumber === 1){
					$('*[data-action="previousPage"]').css('visibility', 'hidden');
				}else{
					$('*[data-action="previousPage"]').css('visibility', 'visible');
				}

				if(currentPageNumber === totalPages){
					$('*[data-action="nextPage"]').css('visibility', 'hidden');
				}else{
					$('*[data-action="nextPage"]').css('visibility', 'visible');
				}

				// Update Title
				var refinements = [];
				
				if(easyAskDataObject.navPath._lsp.searchNode){
					refinements.push('"' + easyAskDataObject.navPath._lsp.searchNode.englishName + '"');
				}
				// Looping backwards so the refinements come out in a sort-of first-picked-first-in-list format
				for(var i = easyAskDataObject.navPath._lsp.refinementNodes.length - 1; i >= 0 ; i--){
					refinements.push(easyAskDataObject.navPath._lsp.refinementNodes[i].value);
				}
				document.title = ($('#pageName').text() + (refinements.length ? ' : ' + refinements.join(', ') : '') + ' | Lone Star Percussion');
				$('html').attr('data-title', document.title);
				
				_gaq.push(['_trackPageview', _state.category + (_state.keywords ? '/?search=' + _state.keywords : '')]);

			},

			renderSelectedRefinements : function(easyAskDataObject){
				var selectedHTML = _util.parseMicroTemplate('templates-search-selectedRefinements', $.extend({}, easyAskDataObject));
				_app.controllers.application.attachEvents($('#selectedRefinements').html(selectedHTML));
			},


			renderRefinements : function(easyAskDataObject){

				// Mark attributes._lsp.cached attributes with _attributeHistory states
				// Loop through the history, then loop through the cached attributes
				// looking to find the entry, and mark it with the saved state
				for(var i = 0; i < _attributeHistory.length; i++){
					for(var j = 0; j < easyAskDataObject.attributes._lsp.cached.length; j++){
						var cachedAttribute = easyAskDataObject.attributes._lsp.cached[j];

						if((_attributeHistory[i] || {}).name === cachedAttribute.name){
							easyAskDataObject.attributes._lsp.cached[j].displayState = _attributeHistory[i].displayState;
							break;
						}
					}
				}

				var refinementHTML = _util.parseMicroTemplate('templates-search-refinements', $.extend({}, easyAskDataObject));
				_app.controllers.application.attachEvents($('#searchRefinements').html(refinementHTML).show());
				
				//If there aren't any attributes, hide the panel
				if(!(easyAskDataObject.attributes._lsp.cached || {}).length){
					$('#searchRefinements').addClass('empty');
				}else{
					$('#searchRefinements').removeClass('empty');
				}
			
			},

			renderProducts : function(easyAskDataObject){
				var entriesHTML = _util.parseMicroTemplate('templates-search-entries', $.extend({}, easyAskDataObject));
				_app.controllers.application.attachEvents($('#searchEntries').html(entriesHTML));

				_this.changeView(_state.view);
				
			},

			renderFatalError : function(response){
				_gaq.push(['_trackEvent', 'search', 'error', 'fatalError : ' + response.serverResponse.status + ' : ' + response.serverResponse.statusText]);
				receievedMessage = ((response.response.errorMsg || '').length > 0) ? ' ' + response.response.errorMsg + ' ' : ' ';
				alert('Something has gone wrong with our network connection to our database.' + receievedMessage +'Sorry about that!');
			}
		};
		
		return _this;

	}()));

});

}());
(function(){

define('plugins/clearable',['utilities/global', 'controllers/application'], function(){
	
	var _util = window.LSP.utilities;
	
	_util.register('controller', 'clearable', (function(){
		var _this = {};
		var _lsp = window.LSP;
		
		_this =  {
			name : 'clearable',
			events : {
				clearable : {
					onClear : function(e, data){
						$(data.passthrough.targetInput).val('');
						$(data.passthrough.targetInput).trigger('change');
					},
					onShowHideButton : function(e, data){
						var input = $(data.passthrough.targetInput);
						if($(data.passthrough.targetInput).val().length > 0){
							input.next('button').fadeIn(200);
						}else{
							input.next('button').fadeOut(200);
						}
						//debugger;
						//input.focus();

					},
					onSelectedInput : function(e, data){
						$(data.selector).select();
					}
				},
				application : {
					onAttachEvents : function(e, data){
						setTimeout(function(){
							$('.clearable:not([data-isclearablehandled])', data.selector).each(function(i, element){ _this.attach(element); });
							$('input[type="text"], input[type="number"], input[type="tel"]', data.selector)
								.off('focusable')
								.on('click.lsp.focusable', function(e){
								$(_this).triggerHandler('onSelectedInput', {selector : $(this)});
							}).change();
						}, 200);
					}
				}
			},
			assets : {},
			attach : function(element){

				var button = $('<button type="button" class="b5 clearContents" tabindex="-1">Clear Contents</button>')
					.on('click.lsp.clearable', _lsp.controllers.application.createHandlerBridge(_this, 'clear', {targetInput : element}));
				
				$(element)
					.off('clearable')
					.on('keyup.lsp.clearable change.lsp.clearable', _lsp.controllers.application.createHandlerBridge(_this, 'showHideButton', {targetInput : element}))
					.wrap('<div class="clearableContainer" />')
					.after(button)
					.attr('data-isclearablehandled', true);

				//_lsp.controllers.application.attachEvents(element);
			},
			// makeElement : function(index, elementString){
			// 	return '<div class="badges-badge badge-'+$(this).data('badge')+'">'+ $(this).data('badge') +'</div>';
			// }
		};

		return _this;

	}()));

});

})();
require([
	'utilities/global', 
	'controllers/application', 
	'plugins/flyout', 
	'plugins/search', 
	'plugins/reveal', 
	'plugins/clearable'
], function(){});

// jquery + require.js

// loader
// 	application core

// application core
// 	utilities
// 	application
// 	flyout
// 	search
// 		model.easyask
// 			api
// 	reveal
// 	clearable


// components
// 	ads
// 	badges
// 	definitions
// 	suggestions
// 		touchcarousel
// 	validation
// 	product
// 		jqzoom
// 		reviews
// 			form2js
// 			formatdate
// 			model.netsuite
// 	netsuite
// 		model.netsuite
// 	shipping
// 	wishlist
// 	home
;
define("combined/core", function(){});


(function(){

define('models/api',['utilities/global', 'controllers/application'], function(){
	
	var _app = window.LSP;
	var _util = _app.utilities;

	// This is a generic API model that can be extended to overwrite : 
	//      _url - returns the url for the service
	//      _payload - formats the payload as nessesary
	//      _isSuccess - often services will not use HTTP status codes to
	//                   return actual request success/failure - you can write custom
	//                   logic here that will 'fail' a successful query
	//
	// Use like : $.extend({ _url : function(payload){ console.log('custom code'); }, _app.models.api)

	_util.register('model', 'api', {
		
		_timeout : 15000,

		_url : function(controller, payload){
			return '';
		},
		_payload : function(controller, payload){
			return payload;
		},
		_isSuccess : function(responseData){
			return (responseData || {}).success === true;
		},
		_afterSuccess : function(responseData){
			return responseData;
		},
		_request : function(type, dataType, controller, eventName, payload, passthrough){
		
			var result = $.Deferred();
			var eventData = {};
			
			$.support.cors = true;

			eventData.xhrData = {
				type : type,
				url : this._url(controller, payload),
				data : this._payload(controller, payload),
				crossDomain : true,
				dataType : dataType,
				context : this,
				timeout : this._timeout,
				passthrough : $.extend({}, passthrough)
			};
			
			// TODO : use $.extend

			// for(var key in payload){
			// 	if(payload.hasOwnProperty(key)){ eventData.xhrData.data[key] = payload[key]; } 
			// } // Merge objects
			
			console.log('API Request Sent via ' + eventName, eventData.xhrData);
			
			$(_app.controllers.application).triggerHandler('onBeforeAPICall', eventData);
			$(controller).triggerHandler('onBeforeAPICall', eventData);
			$(controller).triggerHandler(_util.camelCase('on-Before-API-'+eventName+'-call'), eventData);
			
			$.ajax(eventData.xhrData).done(function(responseData){
				
				eventData.serverResponse = responseData; // raw response needs a differnt property name
				try{
					eventData.response = $.parseJSON(responseData);
				}catch(e){
					eventData.response = responseData;
				}   

				if(this._isSuccess(responseData)){
					eventData.response = this._afterSuccess(eventData.response);
					result.resolve(eventData);
				}else{
					eventData.error = 'invalidFormat';
					result.reject(eventData);
				}
				
			}).fail(function(responseData){

				// jQuery dosen't auto-parse JSON data for failures
				eventData.serverResponse = responseData; // raw response needs a differnt property name
				try{
					eventData.response = $.parseJSON(responseData.responseText);
				}catch(e){
					eventData.response = responseData;
				}
				
				result.reject(eventData);
				
			}).always(function(){
				console.log('API Response Recieved via ' + eventName, eventData);
			});


			// By seperating the logic like this -- it allows us to "fail" a success HTTP response (see the .done() method above)
			$.when(result).done(function(responseData){
				
				// Fire onAfterMethodSuccess event
				// Fire mb.controllers.application's onAfterAPICallSuccess
				$(_app.controllers.application).triggerHandler('onAfterAPICallSuccess', responseData);
				$(controller).triggerHandler('onAfterAPICallSuccess', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName+'-success'), responseData);
				// $('body').addClass(controller.name + '-downloadSuccess');
				
			}).fail(function(responseData){
				
				// Fire onAfterMethodFailure event
				// Fire mb.controllers.application's onAfterAPICallFailure
				$(_app.controllers.application).triggerHandler('onAfterAPICallFailure', responseData);
				$(controller).triggerHandler('onAfterAPICallFailure', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName+'-failure'), responseData);
				// $('body').addClass(controller.name + '-downloadFailure');
				
			}).always(function(responseData){
				
				$(_app.controllers.application).triggerHandler('onAfterAPICall', responseData);
				$(controller).triggerHandler('onAfterAPICall', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName), responseData);
				// $('body').removeClass(controller.name + '-downloadWaiting');
				
			});

			return result.promise();
		},

		request : function(controller, eventName, method, data){
			return this._request('GET', 'jsonp', controller, eventName, method, data);
		}
	});

});
	
}());

(function(){

define('models/easyask',['utilities/global', 'controllers/application', 'models/api'], function(){

	var _util = window.LSP.utilities;
	var _models = window.LSP.models;
	
	_util.register('model', 'easyask', (function(){

		var _this = $.extend({}, _models.api);

		// var _dictionary = 'EcomDemo';
		// var _hostname = 'http://easyaskqa.easyaskondemand.com';
		
		var _dictionary = 'nslonestarpercussion';
		var _hostname = 'http://lonestarpercussion.prod.easyaskondemand.com';
		var _sessionId;

		var _attributeHistory = {};

		// Extends the generic API
		return $.extend(_this, {

			_timeout : 30000,

			_url : function(controller, payload){
				return _hostname + '/EasyAsk/apps/Advisor.jsp';
			},
			_payload : function(controller, payload){


				// payload : 
				// 	{sort, resultsPerPage, page, category, attributes ({thing : [thing1, thing2]}), keywords, action ('advisor'), method ('CA_Search')}

				var formattedPayload = {
					RequestAction : payload.action,
					RequestData : payload.method,
					currentpage : payload.page || 1,
					forcepage : 1,
					ResultsPerPage : payload.resultsPerPage || 24,
					defsortcols : (payload.sort === 'default' ? '' : payload.sort),
					indexed : 1, 
					rootprods : 1,
					oneshot : 1,
					//sessionID : _sessionId,
					defarrangeby : '///NONE///',
					disp : 'json',
					dct : _dictionary,
					q : (payload.keywords && payload.keywords.length) ? payload.keywords : undefined,
					AttribSel : _this.combineSimilarAttributesForRequest(payload.attribute, payload.allAttributes)
				};

				// if(payload.isSingleSelect){
				// 	formattedPayload.CatPath = payload.category;
				// 	formattedPayload.AttribSel = this.buildSingleAttributeString(payload.allAttributes);
				// }else{
				// 	// Build the category path by hand
				formattedPayload.CatPath = _util.cleanArray([(payload.category || '').replace('All Products', '') , _this.combineAndRemoveAllForPath(payload.attribute, payload.allAttributes), this.buildKeywordString(payload.keywords)])
					.join('/')
					.replace(/^\/{1,}-/, '-'); // It's possible it get a keyword search like /-keyword... which is interpreted as a category, it's best to clean this up
				//}

				if($.isEmptyObject(payload.allAttributes) && !payload.attribute && payload.method === 'CA_AttributeSelected'){
					formattedPayload.RequestData = 'CA_BreadcrumbClick'; // If there are no attributes, just load the category
				}

				// If we are trying to remove the last breadcrumb - this was a weird bug, and I'm still not super sure if it's
				// totally fixed.
				if(formattedPayload.RequestData === 'CA_BreadcrumbRemove' && !formattedPayload.q && !formattedPayload.AttribSel){
					formattedPayload.RequestData = 'CA_CategoryExpand';
				}

				if(formattedPayload.RequestData !== 'CA_Search'){
					delete formattedPayload.q;
				}

				if(formattedPayload.ResultsPerPage > 96 || (formattedPayload.ResultsPerPage + '' || '').toLowerCase() === 'all'){
					formattedPayload.ResultsPerPage = 96;
				}

				// As a form of cleanup - remove a trailing / from a category request
				formattedPayload.CatPath = formattedPayload.CatPath.replace(/\/$/, '').replace(/^\//, '').replace(/\/\//g, '/'); // Remove trailing / if it exists

				return formattedPayload;			
			},

			_isSuccess : function(responseData){
				return (responseData || {}).returnCode === 0;
			},

			isRedirect : function(responseData){
				return /((http|https)(:\/\/))?([a-zA-Z0-9]+[.]{1}){2}[a-zA-z0-9]+(\/{1}[a-zA-Z0-9]+)*\/?/.test(responseData.errorMsg) || /^\//.test(responseData.errorMsg); 
			},

			_afterSuccess : function(responseData){

				if(_this.isRedirect(responseData)){
					document.location = responseData.errorMsg;
					return;
				}
				
				_sessionId = responseData.sessionID;

				responseData.source = _this.clean(responseData.source);
				
				responseData.source.navPath._lsp = responseData.source.navPath._lsp || {};
				responseData.source.navPath._lsp.categoryNodes = _this.getCategoryNodes(responseData.source);
				responseData.source.navPath._lsp.refinementNodes = _this.getRefinementNodes(responseData.source);
				responseData.source.navPath._lsp.searchNode = _this.getSearchNode(responseData.source);
				
				this.cacheAttributes(responseData.source);
				responseData.source.attributes = responseData.source.attributes || {};
				responseData.source.attributes._lsp = responseData.source.attributes._lsp || {};
				responseData.source.attributes._lsp.cached = _this.injectCachedAttributes(responseData.source);

				responseData.source._lsp = responseData.source._lsp || {};
				responseData.source._lsp.query = _this.parseCommentaryForDidYouMean(responseData.source.commentary);

				for(var i = 0; i < ((responseData.source.products || {}).items || {}).length; i++){
					if(responseData.source.products.items[i].Matrix_Values){
						var children = $.parseJSON(responseData.source.products.items[i].Matrix_Values);
						responseData.source.products.items[i]._formattedMatrixObject = _this.parseMatrixChildren(children);
					}
				}

				return responseData;
			},

			clean : function(easyAskDataSourceObject){

				// Categories - Remove 'School'
				for(var i = 0; i < ((easyAskDataSourceObject.categories || {}).categoryList || []).length; i++){
					if(easyAskDataSourceObject.categories.categoryList[i].name === 'Schools'){
						easyAskDataSourceObject.categories.categoryList.splice(i, 1);
						i--;
					}
				}
				
				// if(((easyAskDataSourceObject.categories || {}).categoryList || []).length === 0){
				// 	delete easyAskDataSourceObject.categories;
				// }

				// Refinements
				var value;
				for(var i = 0; i < ((easyAskDataSourceObject.attributes || {}).attribute || {}).length; i++){
					for(var j = 0; j < (easyAskDataSourceObject.attributes.attribute[i].attributeValueList || {}).length; j++){
						value = easyAskDataSourceObject.attributes.attribute[i].attributeValueList[j].attributeValue;
						if(value.substr(0, 1) === '!' || value === 'None' || value === 'Unknown' || value === 'Required'){
							easyAskDataSourceObject.attributes.attribute[i].attributeValueList.splice(j, 1);
							j--;
						}
					}
					for(var j = 0; j < (easyAskDataSourceObject.attributes.attribute[i].initialAttributeValueList || {}).length; j++){
						value = easyAskDataSourceObject.attributes.attribute[i].initialAttributeValueList[j].attributeValue;
						if(value.substr(0, 1) === '!' || value === 'None' || value === 'Unknown' || value === 'Required'){
							easyAskDataSourceObject.attributes.attribute[i].initialAttributeValueList.splice(j, 1);
							easyAskDataSourceObject.attributes.attribute[i].initDispLimit--;
							j--;
						}
					}
					if(easyAskDataSourceObject.attributes.attribute[i].attributeValueList.length === 0){
						easyAskDataSourceObject.attributes.attribute.splice(i, 1);
						i--;
					}
				}

				if(((easyAskDataSourceObject.attributes || {}).attribute || []).length === 0){
					delete easyAskDataSourceObject.attributes;
				}

				return easyAskDataSourceObject;
			
			},


			// AttribSel needs to have all the options for a particular attribute
			// in the same request -- some of those are contained in the path - so
			// we need to remove them from the path, and add them to the AttribSel
			// parameter - combineAndRemoveAllForPath removes them for the path
			combineAndRemoveAllForPath : function(singleAttribute, allAttributes){
				if(allAttributes && singleAttribute){

					var singleAttributeName = singleAttribute.replace(/:.*/, '');
					allAttributes = allAttributes.split('/');

					for(var i = 0; i < allAttributes.length; i++){
						if(allAttributes[i].replace(/:.*/, '') === singleAttributeName){
							allAttributes.splice(i, 1);
							i--;
						}
					}
					return allAttributes.join('/');
				}

				return allAttributes;
				
			},

			// AttribSel needs to have all the options for a particular attribute
			// in the same request -- some of those are contained in the path - so
			// we need to remove them from the path, and add them to the AttribSel
			// parameter - combineSimilarAttributesForRequest combines them for
			// the request
			combineSimilarAttributesForRequest : function(singleAttribute, allAttributes){
				
				if(allAttributes && singleAttribute){

					var singleAttributeName = singleAttribute.replace(/:.*/, '');
					allAttributes = allAttributes.split('/');

					for(var i = 0; i < allAttributes.length; i++){
						if(allAttributes[i].replace(/:.*/, '') === singleAttributeName){
							singleAttribute += ';' + allAttributes[i];
						}
					}

					return singleAttribute;
				}

				return singleAttribute;
			},

			buildKeywordString : function(keywords){
				return (keywords ? ('-' + keywords).replace(/-{1,}/, '-') : null);
			},

			// buildMultiAttributeString : function(attributeHashMap){
				
			// 	var attributes = [];

			// 	if(attributeHashMap){
			// 		$.each(attributeHashMap, function(name, valueArray){

			// 			var selections = [];

			// 			$.each(valueArray, function(index, selectedValue){
			// 				// If index is null (it's the first index) add attribSel to the name
			// 				selections.push(selectedValue);
			// 			});

			// 			attributes.push(selections.join(';'));

			// 		});
			// 	}

			// 	return _util.cleanArray(attributes).join('/');

			// },

			buildSingleAttributeString : function(attributeHashMap){
				return this.buildMultiAttributeString(attributeHashMap).replace('AttribSelect=', '').replace(/\/\/\/\/*/, '');
			},

			clearCachedAttributes : function(){
				_attributeHistory = {};
			},

			cacheAttributes : function(easyAskDataSourceObject){

				var returnAttributeMap = {};


				// Mark everything as 'cached'
				$.each(_attributeHistory, function(i, cachedAttribute){
					_attributeHistory[cachedAttribute.attribute.name].isFromCached = true;
				});

				// Add all returned attributes to the cache, marking them as not cached
				for(var i = 0; i < ((easyAskDataSourceObject.attributes || {}).attribute || {}).length; i++){
					var attribute = easyAskDataSourceObject.attributes.attribute[i];
					_attributeHistory[attribute.name] = {index: i, attribute: attribute, isFromCached: false};
					returnAttributeMap[attribute.name] = true; // Small lookup map
				}

				// Clean cachedAttributes that shoudn't be there
				$.each(_attributeHistory, function(i, cachedAttribute){
					
					// If it's not been returned with Attributes
					var fullPath = $(easyAskDataSourceObject.navPath.navPathNodeList).last()[0].seoPath;
					var attributeSEOName = cachedAttribute.attribute.attributeValueList[0].nodeString.replace(/:.*/, '');

					// If it's neither returned, nor selected, it's ok to delete it from the cache
					if(!returnAttributeMap[cachedAttribute.attribute.name] && fullPath.indexOf(attributeSEOName+':') < 0){					
						delete _attributeHistory[cachedAttribute.attribute.name];
					}
				});

				return returnAttributeMap;

			},

			injectCachedAttributes : function(easyAskDataSourceObject){

				var lspAttributes = [];
				var _attributeHistoryArray = [];

				// Caching attributes and storing them in a map loses ordinality
				// Convert map to array, then sort by index
				$.each(_attributeHistory, function(key, attribute){
					_attributeHistoryArray.push(attribute);
				});
				_attributeHistoryArray.sort(function(a, b){

					if(a.index < b.index) return -1;
					if(a.index > b.index) return 1;
					if(a.isFromCached && !b.isFromCached) return -1;
					if(b.isFromCached && !a.isFromCached) return 1;

					return 0;
				});

				// Loop through cached attributes
				// See if the attribute came down in the response, if it is then use it
				// if it's not - then use the cached version.
				$.each(_attributeHistoryArray, function(i, cachedAttribute){
					var found = false;
					for(var j = 0; j < ((easyAskDataSourceObject.attributes || {}).attribute || {}).length; j++){
						if(easyAskDataSourceObject.attributes.attribute[j].attributeName === cachedAttribute.attribute.name){
							found = true;
							lspAttributes.push(easyAskDataSourceObject.attributes.attribute[j]);
						}
					}
					if(!found){
						lspAttributes.push(cachedAttribute.attribute);
					}

				});

				return this.markSelectedAttributes(easyAskDataSourceObject, lspAttributes);
			},

			markSelectedAttributes : function(easyAskDataSourceObject, attributes){
				
				var attributes = $.extend(true, [], attributes); // attributes is a pointer, we need it passed as a value

				$.each(((easyAskDataSourceObject.navPath || {})._lsp || {}).refinementNodes, function(j, refinementNode){

					// Find the attribute
					for(var i = 0; i < (attributes || {}).length; i++){
						if((attributes[i] || {}).name === refinementNode.attribute){

							// Find the matching value
							for(var j = 0; j < (attributes[i].attributeValueList || {}).length; j++){

								if(refinementNode.value === attributes[i].attributeValueList[j].attributeValue){
									// Mark it as selected
									attributes[i].attributeValueList[j].selected = true;
									break;
								}
							}

							break; // stop after the first attribute
						}
					}

					
				});

				return attributes;

			},

			getCategoryNodes : function(easyAskDataSourceObject){
				
				var categoryNodes = [];
				var navPathNodeList = easyAskDataSourceObject.navPath.navPathNodeList;
				var pureCategoryPath = this.getCategoriesFromSEOPath(navPathNodeList[navPathNodeList.length - 1].seoPath);

				// Creates a list of just category nodes, and adds a convinient removePath property
				for(var i = 0; i < easyAskDataSourceObject.navPath.navPathNodeList.length; i++){
					if(navPathNodeList[i].navNodePathType === 1){
						
						navPathNodeList[i].englishName = navPathNodeList[i].englishName.replace(/\/$/, '');
						navPathNodeList[i].englishName = (navPathNodeList[i].englishName === 'All-Products' ? 'All Products' : navPathNodeList[i].englishName);

						if(navPathNodeList[i].englishName !== 'All Products' && navPathNodeList[i].englishName !== 'School'){
							var len = categoryNodes.push(navPathNodeList[i]);
							var newCategoryName = categoryNodes[len - 1].seoPath;

							// Grab the stuff after newCategoryName
							categoryNodes[len - 1].removePath = pureCategoryPath.substr(pureCategoryPath.indexOf(newCategoryName) + newCategoryName.length, pureCategoryPath.length);
						}
					}
				}

				return categoryNodes;

			},

			getSearchNode : function(easyAskDataSourceObject){
				for(var i = 0; i < easyAskDataSourceObject.navPath.navPathNodeList.length; i++){
					if(easyAskDataSourceObject.navPath.navPathNodeList[i].navNodePathType === 3){ 
						return easyAskDataSourceObject.navPath.navPathNodeList[i];
					}
				}
			},


			// Creates an array of refinement node objects
			// and splits up each attribute selection into it's own
			// node
			// Is then accessible at .navPath._lsp
			getRefinementNodes : function(easyAskDataSourceObject){
				var attributeNodes = [];

				for(var i = 0; i < easyAskDataSourceObject.navPath.navPathNodeList.length; i++){
					
					var node = easyAskDataSourceObject.navPath.navPathNodeList[i];

					if(node.navNodePathType === 2){ // If it is a refinement

						var fullPath = decodeURIComponent(easyAskDataSourceObject.navPath.fullPath).replace(/\+/g, ' ');

						// A group is a collection of refinements of the same type (two manufactuers, or three diameters)
						var groups = node.englishName.substring(1, node.englishName.length - 2); // Remove starting and trailing parens
						groups = groups.split('\'); (');

						for(var k = 0; k < groups.length; k++){
							
							var attributeNode = groups[k].split('\' or ');

							for(var j = 0; j < attributeNode.length; j++){

								// Easy ask will sometimes append random numbers to the end of node values, and since convertToSEOString
								// can't figure it out - we need to search the seoPath, find and use the right nodeString
								var attribute = attributeNode[j].split(' = \''); // Grab the name [0] and value [1] 
								var initialNodeString = this.convertToSEOString(attribute[0]+':'+attribute[1]); // the part we know
								var additionalText = _util.findBetween(initialNodeString, ';', node.seoPath); // the potential part we don't

								attributeNodes.push({
									attribute : attribute[0],
									value : attribute[1],
									nodeString : initialNodeString + additionalText
								});
							}
						}

						
					}
				}

				return attributeNodes;
			},

			parseMatrixChildren : function(easyAskMatrixArray){

				var optionObject = {};
				var productObject= {};
				var easyAskMatrixArray = (typeof easyAskMatrixArray === 'string' ? $.parseJSON(easyAskMatrixArray) : easyAskMatrixArray) || [];
				
				for(var i = 0; i < easyAskMatrixArray.length; i++){
					var id = easyAskMatrixArray[i][0],
						item = easyAskMatrixArray[i][1].split('|'),
						label = item[0],
						value = item[1],
						index = item[2],
						imageUrl = item[3],
						mpn = item[4],
						onlinePrice = item[5],
						msrp = item[6],
						stockMessage = item[7];
						waysToSave = item[8];
						specialFeature = item[9];

					optionObject[label] = optionObject[label] || {};
					optionObject[label][value] = optionObject[label][value] || [];
					optionObject[label][value].push(id);

					productObject[id] = productObject[id] || {};
					productObject[id].options = productObject[id].options || {};
					productObject[id].options[label] = productObject[id].options[label] || {};
					productObject[id].options[label] = value;

					productObject[id].data = productObject[id].data || {};
					productObject[id].data.imageUrl = imageUrl;
					productObject[id].data.mpn = mpn;
					productObject[id].data.onlinePrice = onlinePrice;
					productObject[id].data.msrp = msrp;
					productObject[id].data.stockMessage = stockMessage;
					productObject[id].data.waysToSave = waysToSave;
					productObject[id].data.specialFeature = specialFeature;

				}

				return {options : optionObject, products : productObject};
			},

			filterMatrixChildren : function(easyAskMatrixData, filters){
				
				var filteredOptionsObject = {};
				var filteredProducts = {};
				
				$.each(easyAskMatrixData.products, function(id, options){
					
					// Loop through the products and check to see if any filters don't match
					for(var key in filters){
						if(filters.hasOwnProperty(key)){
							if(options.options[key] && options.options[key] != filters[key]){
								return;
							}
						}
					}

					// If we make it all the way through the filters, it means the product matches
					filteredProducts[id] = options;

				});

				// Create the options from the products
				$.each(filteredProducts, function(id, options){
					$.each(options.options, function(label, value){

						// // If option isn't part of the filters
						if(!filters[label]){
							// We avoid adding filtered options here because 1) state dosen't change like it does
							// for search refinements (where we WANT easyask to return selected attributes, but they don't)
							// and 2) because it makes replacing them easier - just loop through the filteredOptions and if it exists in the object, it needs to get updated.
							filteredOptionsObject[label] = filteredOptionsObject[label] || {};
							filteredOptionsObject[label][value] = filteredOptionsObject[label][value] || [];
							filteredOptionsObject[label][value].push(id);
						}
					});
				});

				return filteredOptionsObject;
			},


			convertToSEOString : function(string){
				return string.replace(/'/g, '') // remove apostrphes which are skipped by the next line
					.replace(/[^A-Za-z0-9:]/g, '-') //Everything not a A-Z or 0-9
					.replace(/-{1,}/g, '-') // two or more -
					.replace(/-$/, '') // end with -
					.replace(/:-/, ':'); // remove starting - from any values
			},

			getCategoriesFromSEOPath : function(seoPath){

				var seoPath = seoPath.split('/');

				for(var i = 0; i < seoPath.length; i++){
					if(seoPath[i].indexOf(':') > 0 || seoPath[i].indexOf('-') === 0){
						seoPath.splice(i, 1);
						i--; // We just removed an element from the array
					}
				}
				
				return seoPath.join('/');
			},

			getRefinementsFromSEOPath : function(seoPath){

				var seoPath = seoPath.split('/');

				for(var i = 0; i < seoPath.length; i++){
					if(seoPath[i].indexOf(':') < 0 || seoPath[i].indexOf('-') === 0){
						seoPath.splice(i, 1);
						i--; // We just removed an element from the array
					}
				}
				
				return seoPath.join('/');
			},

			getKeywordsFromSEOPath : function(seoPath){

				var seoPath = unescape(seoPath).split('/');

				for(var i = 0; i < seoPath.length; i++){
					if(seoPath[i].indexOf('-') === 0){
						return encodeURIComponent(seoPath[i]);
					}
				}

				return '';
			},
			parseCommentaryForDidYouMean : function(commentaryString){
				
				var returnObject = {};

				if(commentaryString.length > 0 && commentaryString.indexOf('Corrected Word') > -1){
					var spaced = commentaryString.split(' ');

					returnObject.originalQuery = _util.findBetween('Corrected Word: ', ' is ', commentaryString);
					returnObject.assumedQuery =  _util.findBetween(' is ', '; ', commentaryString);
					returnObject.otherSuggestions = (_util.findBetween(' could be  ', '~END', commentaryString + '~END') || '').split(', ');

				}
				
				return returnObject;

			}
		});

	}()));

});
	
}());
/*!
 * jQzoom Evolution Library v2.3  - Javascript Image magnifier
 * http://www.mind-projects.it
 *
 * Copyright 2011, Engineer Marco Renzi
 * Licensed under the BSD license.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the organization nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * Date: 03 May 2011 22:16:00
 */

define('vendors/jqzoom/jqzoom',['jquery'], function(){

(function ($) {
	//GLOBAL VARIABLES
	var isIE6 = ($.browser && $.browser.msie && $.browser.version < 7);
	var body = $(document.body);
	var window = $(window);
	var jqzoompluging_disabled = false; //disabilita globalmente il plugin
	//var timeoutId;
	$.fn.jqzoom = function (options) {
		return this.each(function () {
			var node = this.nodeName.toLowerCase();
			if (node == 'a') {
				new jqzoom(this, options);
			}
		});
	};
	jqzoom = function (el, options) {
		var api = null;
		api = $(el).data("jqzoom");
		if (api) return api;
		var obj = this;
		var settings = $.extend({}, $.jqzoom.defaults, options || {});
		obj.el = el;
		el.rel = $(el).attr('rel');
		//ANCHOR ELEMENT
		el.zoom_active = false;
		el.zoom_disabled = false; //to disable single zoom instance
		el.largeimageloading = false; //tell us if large image is loading
		el.largeimageloaded = false; //tell us if large image is loaded
		el.scale = {};
		el.timer = null;
		el.mousepos = {};
		el.mouseDown = false;
		$(el).css({
			'outline-style': 'none',
			'text-decoration': 'none'
		});
		//BASE IMAGE
		var img = $("img:eq(0)", el);
		el.title = $(el).attr('title');
		el.imagetitle = img.attr('title');
		var zoomtitle = ($.trim(el.title).length > 0) ? el.title : el.imagetitle;
		var smallimage = new Smallimage(img);
		var lens = new Lens();
		var stage = new Stage();
		var largeimage = new Largeimage();
		var loader = new Loader();
		//preventing default click,allowing the onclick event [exmple: lightbox]
		$(el).on('click.jqzoom', function (e) {
			e.preventDefault();
			return false;
		});
		//setting the default zoomType if not in settings
		var zoomtypes = ['standard', 'drag', 'innerzoom', 'reverse'];
		if ($.inArray($.trim(settings.zoomType), zoomtypes) < 0) {
			settings.zoomType = 'standard';
		}
		$.extend(obj, {
			create: function () { //create the main objects
				//create ZoomPad
				if ($(".zoomPad", el).length == 0) {
					el.zoomPad = $('<div/>').addClass('zoomPad');
					img.wrap(el.zoomPad);
				}
				if(settings.zoomType == 'innerzoom'){
					settings.zoomWidth  = smallimage.w;
					settings.zoomHeight  =   smallimage.h;
				}
				//creating ZoomPup
				if ($(".zoomPup", el).length == 0) {
					lens.append();
				}
				//creating zoomWindow
				if ($(".zoomWindow", el).length == 0) {
					stage.append();
				}
				//creating Preload
				if ($(".zoomPreload", el).length == 0) {
					loader.append();
				}
				//preloading images
				if (settings.preloadImages || settings.zoomType == 'drag' || settings.alwaysOn) {
					obj.load();
				}
				obj.init();
			},
			init: function () {
				//drag option
				if (settings.zoomType == 'drag') {
					$(".zoomPad", el).mousedown(function () {
						el.mouseDown = true;
					});
					$(".zoomPad", el).mouseup(function () {
						el.mouseDown = false;
					});
					document.body.ondragstart = function () {
						return false;
					};
					$(".zoomPad", el).css({
						cursor: 'default'
					});
					$(".zoomPup", el).css({
						cursor: 'move'
					});
				}
				if (settings.zoomType == 'innerzoom') {
					$(".zoomWrapper", el).css({
						cursor: 'crosshair'
					});
				}
				$(".zoomPad", el).on('mouseenter.jqzoom mouseover.jqzoom', function (event) {
					img.attr('title', '');
					$(el).attr('title', '');
					el.zoom_active = true;
					//if loaded then activate else load large image
					smallimage.fetchdata();
					if (el.largeimageloaded) {
						obj.activate(event);
					} else {
						obj.load();
					}
				});
				$(".zoomPad", el).bind('mouseleave.jqzoom', function (event) {
					obj.deactivate();
				});
				$("body").bind('touchstart.jqzoom', function(e){
					if(!$(e.target).parent().is('.zoomPad'))
						obj.deactivate();
				})
				$(".zoomPad", el).bind('mousemove.jqzoom mousedown.jqzoom', function (e) {

					//prevent fast mouse mevements not to fire the mouseout event
					if (e.pageX > smallimage.pos.r || e.pageX < smallimage.pos.l || e.pageY < smallimage.pos.t || e.pageY > smallimage.pos.b) {
						lens.setcenter();
						return false;
					}
					el.zoom_active = true;
					//if (el.largeimageloaded && !$('.zoomWindow', el).is(':visible')) {
						obj.activate(e);
					//}
					//if (el.largeimageloaded && (settings.zoomType != 'drag' || (settings.zoomType == 'drag' && el.mouseDown))) {
						lens.setposition(e);
					//}
				});
				var thumb_preload = [];
				var i = 0;
				//binding click event on thumbnails
				var thumblist = [];
				thumblist = $('.zoom-thumbnails[data-targetZoomId=' + el.id + '] a');
				if (thumblist.length > 0) {
					//getting the first to the last
					var first = thumblist.splice(0, 1);
					thumblist.push(first);
				}
			thumblist.each(function () {
					//preloading thumbs
					if (settings.preloadImages && $(this).data('prezoomimage').indexOf('#') === -1) {
						thumb_preload[i] = new Image();
						thumb_preload[i].src = $(this).data('prezoomimage');
						i++;
					}
					$(this).click(function (e) {
						if($(this).hasClass('zoomThumbActive')){
						  return false;
						}
						thumblist.each(function () {
							$(this).removeClass('zoomThumbActive');
						});
						e.preventDefault();
						obj.swapimage(this);
						return false;
					});
				});
			},
			load: function () {
				if (el.largeimageloaded === false && el.largeimageloading === false) {
					var url = $(el).attr('href');
					if(largeimage.node.src !== url){
						el.largeimageloading = true;
						largeimage.loadimage(url);
					}
				}
			},
			activate: function (e) {
				clearTimeout(el.timer);
				//show lens and zoomWindow
				el.timer = setTimeout(function(){
					lens.show();
					stage.show();
					$('.zoomWindow', el).bind('mouseenter', function(){
						obj.deactivate();
					});
				}, settings.delay);
				
			},
			deactivate: function (e) {
				clearTimeout(el.timer);
				switch (settings.zoomType) {
				case 'drag':
					//nothing or lens.setcenter();
					break;
				default:
					img.attr('title', el.imagetitle);
					$(el).attr('title', el.title);
					if (settings.alwaysOn) {
						lens.setcenter();
					} else {
						stage.hide();
						lens.hide();
					}
					break;
				}
				el.zoom_active = false;
			},
			swapimage: function (link) {
				el.largeimageloading = false;
				el.largeimageloaded = false;
				var smallimage = $(link).data('prezoomimage');
				var largeimage = $(link).attr('href');
				
				if (smallimage && largeimage) {
					$(link).addClass('zoomThumbActive');
					$(el).attr('href', largeimage);
					img.attr('src', smallimage);
					lens.hide();
					stage.hide();
					obj.load();

					_gaq.push(['_trackEvent', 'product', 'zoom', 'thumbnailClick']);
				
				} else {
					//alert('ERROR :: Missing parameter for largeimage or smallimage.');
					//throw 'ERROR :: Missing parameter for largeimage or smallimage.';
					console.error('jqZoom : Missing parameter for large image or small image');
					_gaq.push(['_trackEvent', 'product', 'zoom', 'missingParameterError']);
				}
				return false;
			}
		});
		//sometimes image is already loaded and onload will not fire
		if (img[0].complete) {
			//fetching data from sallimage if was previously loaded
			smallimage.fetchdata();
			if ($(".zoomPad", el).length == 0) obj.create();
		}
/*========================================================,
|   Smallimage
|---------------------------------------------------------:
|   Base image into the anchor element
`========================================================*/

		function Smallimage(image) {
			var $obj = this;
			this.node = image[0];
			this.findborder = function () {
				var bordertop = 0;
				bordertop = image.css('border-top-width');
				btop = '';
				var borderleft = 0;
				borderleft = image.css('border-left-width');
				bleft = '';
				if (bordertop) {
					for (i = 0; i < 3; i++) {
						var x = [];
						x = bordertop.substr(i, 1);
						if (isNaN(x) == false) {
							btop = btop + '' + bordertop.substr(i, 1);
						} else {
							break;
						}
					}
				}
				if (borderleft) {
					for (i = 0; i < 3; i++) {
						if (!isNaN(borderleft.substr(i, 1))) {
							bleft = bleft + borderleft.substr(i, 1)
						} else {
							break;
						}
					}
				}
				$obj.btop = (btop.length > 0) ? eval(btop) : 0;
				$obj.bleft = (bleft.length > 0) ? eval(bleft) : 0;
			};
			this.fetchdata = function () {
				$obj.findborder();
				$obj.w = image.width();
				$obj.h = image.height();
				$obj.ow = image.outerWidth();
				$obj.oh = image.outerHeight();
				$obj.pos = image.offset();
				$obj.pos.l = image.offset().left + $obj.bleft;
				$obj.pos.t = image.offset().top + $obj.btop;
				$obj.pos.r = $obj.w + $obj.pos.l;
				$obj.pos.b = $obj.h + $obj.pos.t;
				$obj.rightlimit = image.offset().left + $obj.ow;
				$obj.bottomlimit = image.offset().top + $obj.oh;
				
			};
			this.node.onerror = function () {
				//alert('Problems while loading image.');
				//throw 'Problems while loading image.';
				console.error('jqZoom : Problems loading image');
				_gaq.push(['_trackEvent', 'product', 'zoom', 'loadSmallImageError']);
			};
			this.node.onload = function () {
				$obj.fetchdata();
				if ($(".zoomPad", el).length == 0) obj.create();
			};
			return $obj;
		};
/*========================================================,
|  Loader
|---------------------------------------------------------:
|  Show that the large image is loading
`========================================================*/

		function Loader() {
			var $obj = this;
			this.append = function () {
				this.node = $('<div/>').addClass('zoomPreload').css('visibility', 'hidden').html(settings.preloadText);
				$('.zoomPad', el).append(this.node);
			};
			this.show = function () {
				this.node.top = (smallimage.oh - this.node.height()) / 2;
				this.node.left = (smallimage.ow - this.node.width()) / 2;
				//setting position
				this.node.css({
					top: this.node.top,
					left: this.node.left,
					position: 'absolute',
					visibility: 'visible'
				});
			};
			this.hide = function () {
				this.node.css('visibility', 'hidden');
			};
			return this;
		}
/*========================================================,
|   Lens
|---------------------------------------------------------:
|   Lens over the image
`========================================================*/

		function Lens() {
			var $obj = this;
			this.node = $('<div/>').addClass('zoomPup');
			//this.nodeimgwrapper = $("<div/>").addClass('zoomPupImgWrapper');
			this.append = function () {
				$('.zoomPad', el).append($(this.node).hide());
				if (settings.zoomType == 'reverse') {
					this.image = new Image();
					this.image.src = smallimage.node.src; // fires off async
					$(this.node).empty().append(this.image);
				}
			};
			this.setdimensions = function () {
				this.node.w = (parseInt((settings.zoomWidth) / el.scale.x) > smallimage.w ) ? smallimage.w : (parseInt(settings.zoomWidth / el.scale.x)); 
				this.node.h = (parseInt((settings.zoomHeight) / el.scale.y) > smallimage.h ) ? smallimage.h : (parseInt(settings.zoomHeight / el.scale.y)); 
				this.node.top = (smallimage.oh - this.node.h - 2) / 2;
				this.node.left = (smallimage.ow - this.node.w - 2) / 2;
				//centering lens
				this.node.css({
					top: 0,
					left: 0,
					width: this.node.w + 'px',
					height: this.node.h + 'px',
					position: 'absolute',
					display: 'none',
					borderWidth: 1 + 'px'
				});



				if (settings.zoomType == 'reverse') {
					this.image.src = smallimage.node.src;
					$(this.node).css({
						'opacity': 1
					});

					$(this.image).css({
						position: 'absolute',
						display: 'block',
						left: -(this.node.left + 1 - smallimage.bleft) + 'px',
						top: -(this.node.top + 1 - smallimage.btop) + 'px'
					});

				}
			};
			this.setcenter = function () {
				//calculating center position
				this.node.top = (smallimage.oh - this.node.h - 2) / 2;
				this.node.left = (smallimage.ow - this.node.w - 2) / 2;
				//centering lens
				this.node.css({
					top: this.node.top,
					left: this.node.left
				});
				if (settings.zoomType == 'reverse') {
					$(this.image).css({
						position: 'absolute',
						display: 'block',
						left: -(this.node.left + 1 - smallimage.bleft) + 'px',
						top: -(this.node.top + 1 - smallimage.btop) + 'px'
					});

				}
				//centering large image
				largeimage.setposition();
			};
			this.setposition = function (e) {
				el.mousepos.x = e.pageX;
				el.mousepos.y = e.pageY;
				var lensleft = 0;
				var lenstop = 0;

				function overleft(lens) {
					return el.mousepos.x - (lens.w) / 2 < smallimage.pos.l; 
				}

				function overright(lens) {
					return el.mousepos.x + (lens.w) / 2 > smallimage.pos.r; 
				   
				}

				function overtop(lens) {
					return el.mousepos.y - (lens.h) / 2 < smallimage.pos.t; 
				}

				function overbottom(lens) {
					return el.mousepos.y + (lens.h) / 2 > smallimage.pos.b; 
				}
				
				lensleft = el.mousepos.x + smallimage.bleft - smallimage.pos.l - (this.node.w + 2) / 2;
				lenstop = el.mousepos.y + smallimage.btop - smallimage.pos.t - (this.node.h + 2) / 2;
				if (overleft(this.node)) {
					lensleft = smallimage.bleft - 1;
				} else if (overright(this.node)) {
					lensleft = smallimage.w + smallimage.bleft - this.node.w - 1;
				}
				if (overtop(this.node)) {
					lenstop = smallimage.btop - 1;
				} else if (overbottom(this.node)) {
					lenstop = smallimage.h + smallimage.btop - this.node.h - 1;
				}
				
				this.node.left = lensleft;
				this.node.top = lenstop;
				var $node = $(this.node);
				var style = $node.attr('style');
				$node.attr('style',
					style
						.replace(/top:[-0-9. ]{1,}px/i, 'top:'+lenstop+'px')
						.replace(/left:[-0-9. ]{1,}px/i, 'left:'+lensleft+'px')
				);

				if (settings.zoomType == 'reverse') {
					if ($.browser.msie && $.browser.version > 7) {
						$(this.node).empty().append(this.image);
					}

					$(this.image).css({
						position: 'absolute',
						display: 'block',
						left: -(this.node.left + 1 - smallimage.bleft) + 'px',
						top: -(this.node.top + 1 - smallimage.btop) + 'px'
					});
				}
			   
				largeimage.setposition();
			};
			this.hide = function () {
				img.css({
					'opacity': 1
				});
				this.node.hide();
			};
			this.show = function () {  
				
				if (settings.zoomType != 'innerzoom' && (settings.lens || settings.zoomType == 'drag')) {
					this.node.show();
				}       

				if (settings.zoomType == 'reverse') {
					img.css({
						'opacity': settings.imageOpacity
					});
				}
			};
			this.getoffset = function () {
				var o = {};
				o.left = $obj.node.left;
				o.top = $obj.node.top;
				return o;
			};
			return this;
		};
/*========================================================,
|   Stage
|---------------------------------------------------------:
|   Window area that contains the large image
`========================================================*/

		function Stage() {
			var $obj = this;
			this.node = $("<div class='zoomWindow'><div class='zoomWrapper'><div class='zoomWrapperTitle'></div><div class='zoomWrapperImage'></div></div></div>");
			this.ieframe = $('<iframe class="zoomIframe" src="javascript:\'\';" marginwidth="0" marginheight="0" align="bottom" scrolling="no" frameborder="0" ></iframe>');
			this.setposition = function () {
				this.node.leftpos = 0;
				this.node.toppos = 0;
				if (settings.zoomType != 'innerzoom') {
					//positioning
					switch (settings.position) {
					case "left":
						this.node.leftpos = (smallimage.pos.l - smallimage.bleft - Math.abs(settings.xOffset) - settings.zoomWidth > 0) ? (0 - settings.zoomWidth - Math.abs(settings.xOffset)) : (smallimage.ow + Math.abs(settings.xOffset));
						this.node.toppos = settings.yOffset; // LSP Removed abs
						break;
					case "top":
						this.node.leftpos = Math.abs(settings.xOffset);
						this.node.toppos = (smallimage.pos.t - smallimage.btop - Math.abs(settings.yOffset) - settings.zoomHeight > 0) ? (0 - settings.zoomHeight - Math.abs(settings.yOffset)) : (smallimage.oh + Math.abs(settings.yOffset));
						break;
					case "bottom":
						this.node.leftpos = Math.abs(settings.xOffset);
						this.node.toppos = (smallimage.pos.t - smallimage.btop + smallimage.oh + Math.abs(settings.yOffset) + settings.zoomHeight < screen.height) ? (smallimage.oh + Math.abs(settings.yOffset)) : (0 - settings.zoomHeight - Math.abs(settings.yOffset));
						break;
					default:
						this.node.leftpos = smallimage.ow + Math.abs(settings.xOffset);//(smallimage.rightlimit + Math.abs(settings.xOffset) + settings.zoomWidth < screen.width) ? (smallimage.ow + Math.abs(settings.xOffset)) : (0 - settings.zoomWidth - Math.abs(settings.xOffset));
						this.node.toppos = settings.yOffset; // LSP Removed abs
						break;
					}
				}
				this.node.css({
					'left': this.node.leftpos + 'px',
					'top': this.node.toppos + 'px'
				});
				return this;
			};
			this.append = function () {
				$('.zoomPad', el).append(this.node);
				this.node.css({
					position: 'absolute',
					display: 'none',
					zIndex: 5001
				});
				if (settings.zoomType == 'innerzoom') {
					this.node.css({
						cursor: 'default'
					});
					var thickness = (smallimage.bleft == 0) ? 1 : smallimage.bleft;
					$('.zoomWrapper', this.node).css({
						borderWidth: thickness + 'px'
					});    
				}
				
				  $('.zoomWrapper', this.node).css({
					  width: Math.round(settings.zoomWidth) + 'px' ,
					  borderWidth: thickness + 'px'
				  });
				  $('.zoomWrapperImage', this.node).css({
					  width: '100%',
					  height: Math.round(settings.zoomHeight) + 'px'
				  });
				  //zoom title
				 $('.zoomWrapperTitle', this.node).css({
						width: '100%',
						position: 'absolute'
				  });  
			  
				$('.zoomWrapperTitle', this.node).hide();
				if (settings.title && zoomtitle.length > 0) {
					$('.zoomWrapperTitle', this.node).html(zoomtitle).show();
				}
				$obj.setposition();
			};
			this.hide = function () {
				switch (settings.hideEffect) {
				case 'fadeout':
					this.node.fadeOut(settings.fadeoutSpeed, function () {});
					break;
				default:
					this.node.hide();
					break;
				}
				this.ieframe.hide();
			};
			this.show = function () {
				switch (settings.showEffect) {
				case 'fadein':
					this.node.fadeIn();
					this.node.fadeIn(settings.fadeinSpeed, function () {});
					break;
				default:
					this.node.show();
					break;
				}
				if (isIE6 && settings.zoomType != 'innerzoom') {
					this.ieframe.width = this.node.width();
					this.ieframe.height = this.node.height();
					this.ieframe.left = this.node.leftpos;
					this.ieframe.top = this.node.toppos;
					this.ieframe.css({
						display: 'block',
						position: "absolute",
						left: this.ieframe.left,
						top: this.ieframe.top,
						zIndex: 99,
						width: this.ieframe.width + 'px',
						height: this.ieframe.height + 'px'
					});
					$('.zoomPad', el).append(this.ieframe);
					this.ieframe.show();
				};
			};
		};
/*========================================================,
|   LargeImage
|---------------------------------------------------------:
|   The large detailed image
`========================================================*/

		function Largeimage() {
			var $obj = this;
			this.node = {};
			//this.node = new Image();
			//$('.zoomWrapperImage', el).empty().append(this.node);

			this.loadimage = function (url) {
				//showing preload
				loader.show();
				this.url = url;
				this.node = new Image();
				this.node.style.position = 'absolute';
				this.node.style.border = '0px';
				this.node.style.display = 'none';
				this.node.style.left = '-5000px';
				this.node.style.top = '0px';
				this.node.onload = this.afterLoad;
				this.node.onerror = function (e) {
					//alert('Problems while loading the big image.');
					//throw 'Problems while loading the big image.';
					console.error('jqZoom : problems loading large image', e);
					_gaq.push(['_trackEvent', 'product', 'zoom', 'loadLargeImageError']);
				};
				document.body.appendChild(this.node);
				this.node.src = url; // fires off async
				//this.afterLoad();
			};
			this.afterLoad = function(){
				//fetching data
				$obj.fetchdata();
				loader.hide();
				el.largeimageloading = false;
				el.largeimageloaded = true;
				if (settings.zoomType == 'drag' || settings.alwaysOn) {
					lens.show();
					stage.show();
					lens.setcenter();
				}
			};
			this.fetchdata = function () {
				var image = $(this.node);
				var scale = {};
				this.node.style.display = 'block';
				$obj.w = image.width();
				$obj.h = image.height();
				$obj.pos = image.offset();
				$obj.pos.l = image.offset().left;
				$obj.pos.t = image.offset().top;
				$obj.pos.r = $obj.w + $obj.pos.l;
				$obj.pos.b = $obj.h + $obj.pos.t;
				scale.x = ($obj.w / smallimage.w);
				scale.y = ($obj.h / smallimage.h);
				el.scale = scale;
				
				document.body.removeChild(this.node);
				$('.zoomWrapperImage', el).empty().append(this.node);
				
				//setting lens dimensions;
				lens.setdimensions();
			};
			
			//this.node.onload = this.afterLoad;
			this.setposition = function () {
				var left = -el.scale.x * (lens.getoffset().left - smallimage.bleft + 1);
				var top = -el.scale.y * (lens.getoffset().top - smallimage.btop + 1);
				$(this.node).css({
					'left': left + 'px',
					'top': top + 'px'
				});
			};
			return this;
		};
		$(el).data("jqzoom", obj);
	};
	//es. $.jqzoom.disable('#jqzoom1');
	$.jqzoom = {
		defaults: {
			zoomType: 'standard',
			//innerzoom/standard/reverse/drag
			zoomWidth: 300,
			//zoomWindow  default width
			zoomHeight: 300,
			//zoomWindow  default height
			xOffset: 10,
			//zoomWindow x offset, can be negative(more on the left) or positive(more on the right)
			yOffset: 0,
			//zoomWindow y offset, can be negative(more on the left) or positive(more on the right)
			position: "right",
			//zoomWindow default position
			preloadImages: true,
			//image preload
			preloadText: 'Loading zoom',
			title: true,
			lens: true,
			imageOpacity: 0.4,
			alwaysOn: false,
			showEffect: 'show',
			//show/fadein
			hideEffect: 'hide',
			//hide/fadeout
			fadeinSpeed: 'slow',
			// ms to wait before opening
			delay : 500,
			//fast/slow/number
			fadeoutSpeed: '2000' //fast/slow/number
		},
		disable: function (el) {
			var api = $(el).data('jqzoom');
			api.disable();
			return false;
		},
		enable: function (el) {
			var api = $(el).data('jqzoom');
			api.enable();
			return false;
		},
		disableAll: function (el) {
			jqzoompluging_disabled = true;
		},
		enableAll: function (el) {
			jqzoompluging_disabled = false;
		}
	};
})(jQuery);

});
(function(){

define('controllers/wishlist',['utilities/global', 'controllers/application'], function(){


// Begin Suite Commerce Stuff
window.parsePrice = function parsePrice(number,bool)	{
	number = (Math.round(number*100))/100;
	var aux1 = parseInt(number/1000), aux2 = Math.round((number%1000)*100)/100;
	if(aux2 < 100)	{
		if(aux2 < 10) aux2 = "00"+ aux2;
		else aux2 = "0"+ aux2;
	}
	if(aux1 > 0)	{
		aux1 = parsePrice(aux1,true);
		number = aux1 +","+ aux2;
	}
	if(!bool){
		number += "";
		if (number.indexOf(".") != -1) {
			var sigFig = number.substring(number.indexOf(".") + 1, number.length);
			if (sigFig.length == 1)	number += "0";
		}
		else number += ".00";
		return "$" + number;
	}
	return number;
};
window.getNumber = function getNumber(string){
	string += "";
	if(string.indexOf("$") != -1) string = string.substring(string.indexOf("$") + 1).replace(",","").replace(" ","");
	return parseFloat(string);
};
window.calcSaves = function calcSaves(list,sale)	{
	var list = getNumber(list), sale = getNumber(sale), dif = list - sale, perDif = Math.round(dif*10000/list)/100;
	if(dif > 0) return perDif + "%";
	else return false;
};
window.addToWishlist = function addToWishlist(config){
	config.messages.hide();
	if (config.customer != "")	{
		var options = "";
		if (config.options.length === 0 || (config.options.length > 0 && config.options.find("option:selected").length === config.options.length && (config.item.val() || '').length > 0)) {
			config.options.each(function(){
				var optionValue = this.id, optionName = $(this).attr('name'),
					selected = $(this).find("option:selected"), selectedValue = selected.val(), selectedLabel = selected.text();
				options += optionName + "=" + optionName + "==" + escape(selectedLabel) + "=" + escape(selectedLabel) + ";";
			});
			var wishUrl = "/app/site/hosting/scriptlet.nl?script=customscript_add_item_wishlist&deploy=customdeploy_add_item_wishlist&i=" + config.item.val() + "&j=" + config.customer + "&q=1&s=" + config.site + "&o=" + options;
			$.getScript(wishUrl, function(){
				$("#add-wishlist").hide();
				config.messages.eq(0).show();
				// setTimeout(function(){
				// 	config.messages.eq(0).fadeOut();
				// }, 8000);
			});
		}
		else {
			$("#add-wishlist").removeClass("loading");
			config.messages.eq(2).show();
		}
	}
	else config.messages.eq(1).show();
};

window.drawWishlist = function drawWishlist(itemId, itemUrl, itemThumb, itemName, itemPrice, itemQty, itemOptions, itemComments, baseprice, stock, mpn, behavior)	{

	var templateData = {
		id : itemId,
		url : itemUrl,
		thumbnailUrl : itemThumb,
		name : unescape(itemName),
		price : itemPrice,
		quantity : itemQty,
		options : unescape(itemOptions),
		comments : unescape(itemComments),
		msrp : baseprice,
		stockMessage : unescape(stock),
		mpn : unescape(mpn),
		behavior : unescape(behavior)
	};

	// var options = unescape(itemOptions).split(";"), optionLabels = "",
	// 	optionValues = "", template = $("#wish-item-template").html();
	// for(var i = 0; i < options.length - 1; i++){
	// 	var splitOptions = options[i].split("==");
	// 	optionLabels+= splitOptions[0].split("=")[1] + ": " + splitOptions[1].split("=")[1] + "<br/>";
	// 	optionValues+= "&" + splitOptions[0].split("=")[0] + "=" + splitOptions[1].split("=")[0];
	// }
	// template = template.replace(/_itemThumb/gi,itemThumb);
	// template = template.replace(/_itemName/gi,unescape(itemName));
	// template = template.replace(/_itemUrl/gi,itemUrl);
	// template = template.replace(/_itemId/gi,itemId);
	// template = template.replace(/_itemQty/gi,itemQty);
	// template = template.replace(/_stock/gi,unescape(stock));
	// template = template.replace(/_optionValues/gi,optionValues);
	// template = template.replace(/_optionLabels/gi,optionLabels);
	// template = template.replace(/_options/gi,itemOptions);
	// template = template.replace(/_itemComments/gi,unescape(itemComments));
	
	// var savings = calcSaves(baseprice, itemPrice);
	// if( savings )
	// 	template = template.replace(/_itemPrice/gi,"MSRP: " + parsePrice(baseprice) + "<br />" + "Price: <span>" + parsePrice(itemPrice) + "</span> <br />" + "<span>You Save: " + savings + "</span>");
	// else
	// 	template = template.replace(/_itemPrice/gi,"Price: <span>" + parsePrice(itemPrice) + "</span>");

	$("table.wishlist.table tbody")
		.append(LSP.utilities.parseMicroTemplate('templates-wishlistItem', templateData))
		.parent('table').show();
	$('table.wishlist .comments textarea').off('keyup.wishlist').on('keyup.wishlist', function(){
		if($(this).val().length > 0){
			$('.wish-update', this.parentNode).fadeIn();
			$('.wish-text-saved', this.parentNode).hide();
		}
	});
};
window.wishlistReady = function wishlistReady(bool)	{
	if(document.location.href.indexOf("austintest") != -1) alert(bool);
};
window.wishStatusText = function wishStatusText(public){
	if(public == "T")	{
		$('input[type="radio"][name="isPublic"][value="true"]').attr('checked',true);
		$('#wishlistStatus').removeClass('loading').html('public');
	}else{
		$('input[type="radio"][name="isPublic"][value="false"]').attr('checked',true);
		$('#wishlistStatus').removeClass('loading').html('private');	
	}
};
window.myWishlist = function myWishlist(config){
	if (config.customer != ""){
		config.messages.filter('.loggedIn').show();
		var today = new Date(),
			myWishUrl = "/app/site/hosting/scriptlet.nl?script=customscript_show_my_wishlist&deploy=customdeploy_show_my_wishlist&j=" + config.customer + "&s=lonestarpercussion&random=" + (Math.random() * today.getTime());
		$("table.wishlist.table tbody").addClass('loading small');
		$.getScript(myWishUrl,function(data){
			$("#wish-info").show();
			if (data == ""){ 
				config.messages.filter('.emptyWishlist').show();
				$('#wishlistStatus').html('empty');	
				$("table.wishlist.table tbody").removeClass('loading');
			}else{
				$("table.wishlist.table tbody").removeClass('loading');
				var wishlist = $("#wishlist-wrapper tbody"),
					wishMessages = $("#wishlist-messages > div"),
					publicWraper = $("#wish-pub"),
					wait = null, 
					public = data.substring(data.indexOf("Ready('") + 7);
				public = public.substring(0,public.indexOf("'"));
				wishStatusText(public);
				$('input[type="radio"][name="isPublic"]').click(function(){
					var status = $(this).val().substr(0, 1).toUpperCase();
					if(wait) clearTimeout(wait);
					var updateUrl = "/app/site/hosting/scriptlet.nl?script=customscript_update_wishlist_public&deploy=customdeploy_update_wishlist_public&j=" + config.customer + "&p=" + status + "&random=" + (Math.random() * today.getTime());
					$('#wishlistStatus').addClass('loading small');
					$.getScript(updateUrl,function(){
						wishStatusText(status);
					});
				});
				$(function(){
					wishlist.find(".wish-remove").click(function(){
						var $this = $(this);
						var id = $(this).data('id');
						var options = $(this).data('options');

						$.getScript("/app/site/hosting/scriptlet.nl?script=customscript_remove_item_wishlist&deploy=customdeploy_remove_item_wishlist&j=" + config.customer + "&i=" + id + "&o=" + options, function(){
							$this.closest("tr").fadeOut(function(){
								$(this).remove();
								if (wishlist.find(".wishlistItem").length == 0) {
									wishMessages.filter(".emptyWishlist").show();
									wishlist.closest("table.wishlist").hide();
									wishlist.closest("h2").hide();
								}
							});
						});
						return false;
					});
					wishlist.find(".wish-update").click(function(){
						var wishActions = $(this).parent(),
						    itemId = $(this).data('id'),
							comments = escape(wishActions.parent().find("textarea").val()),
							wishUrl = "/app/site/hosting/scriptlet.nl?script=customscript_update_wishlist_comments&deploy=customdeploy_update_wishlist_comments&i=" + itemId + "&j=" + config.customer + "&t=" + comments + "&o=" + $(this).data('options');
						$.getScript(wishUrl,function(){
							var saveText = wishActions.parent().find(".wish-text-saved");
							saveText.fadeIn();
							$('.wish-update', wishActions).hide();
						});
						return false;
					});
					
				});
			}
		});
	}else{
		config.messages.hide().filter(".notLoggedIn").show();
	} 
};
window.addCustomer = function addCustomer(customerId, customerName, customerLastName, customerEmail){
	var template = 	"<div class='wish-result'>";
	template +=			"<a href='#'>" + unescape(customerName) + " " + unescape(customerLastName) + " - " + customerEmail + "</a>";
	template +=			"<input type='hidden' value='" + customerId + "' />";
	template +=		"</div>";
	$("#wish-search-results").append(template);
};
window.searchWishlist = function searchWishlist(config){
	var today = new Date();
	$.getScript("/app/site/hosting/scriptlet.nl?script=customscript_search_wishlist&deploy=customdeploy_search_wishlist&st=" + config.searchText + "&random=" + (Math.random() * today.getTime()), function(){
		config.messages.hide();
		$(function(){
			var wishlist = $("#wishlist-wrapper"), wishResultsWrapper = $("#wish-search-results");
			if (wishResultsWrapper.find(".wish-result").length == 0)
				config.messages.eq(2).show();
			else {
				config.messages.eq(4).show();
				wishResultsWrapper.find("a").click(function(){
					
					config.messages.eq(7).hide();

					var resultNameAndTitle = $(this).text();
					var name = LSP.utilities.cleanTrailing(resultNameAndTitle.substr(0, resultNameAndTitle.indexOf(' - ')));

					if(name.length === 0){
						name = resultNameAndTitle.substr(resultNameAndTitle.indexOf(' - ') + 3, 300);
					}
					$(this).parent().siblings().remove();
					$('h2').html('Wishlist for ' + name).show();

					wishlist.hide().find("tbody tr:not(#wish-item-template)").remove();
					var customerId = $(this).next().val();

					//LSP.controllers.application.pushState({name : 'wishlist'}, {q : name});


					$.getScript("/app/site/hosting/scriptlet.nl?script=customscript_show_my_wishlist&deploy=customdeploy_show_my_wishlist&j=" + customerId + "&s=" + config.site, function(){
						if(wishlist.find("tbody tr:not(#wish-item-template)").length > 0)	{
							wishlist.show().find(".wish-add-cart").click(function(){
								var wishActions = $(this).parent(), itemId = wishActions.find(".wish-id").val(), itemQty = wishActions.find(".wish-qty").val(), itemOptions = wishActions.find(".wish-options-values").val(), addUrl = "/app/site/backend/additemtocart.nl?c=" + config.account + "&buyid=" + itemId + "&qty=" + itemQty + itemOptions + "&continue=/Search-Wishlist?searchtext="+config.searchText;
								document.location = addUrl;
								return false;
							});	
						}
						else config.messages.eq(7).show();
					});
					return false;
				});
				config.messages.eq(6).show();
			}
		});
	});
};

// END SuiteCommerce stuff

(function(){
	
	var _util = window.LSP.utilities;
	
	_util.register('controller', 'wishlist', (function(){
		var _this = {};
		var _lsp = window.LSP;
		
		_this =  {
			name : 'wishlist',
			events : {
				application : {
					onReady : function(e, data){

						if((LSP.config || {}).wishlist){
							myWishlist(LSP.config.wishlist.myWishlistSettings);
						}
						
						var searchButton = $("#search-wish"),
							searchText = $("#search-wish-text"),
							wishMessages = $(".wishlist-messages > div");
						searchText
							//.val("Enter name or e-mail")
							// .focus(function(){
							// 	var $this = $(this);
							// 	// if( $this.val() == "Enter name or e-mail" )
							// 	// 	$this.val("")
							// })
							// .blur(function(){
							// 	var $this = $(this);
							// 	// if( $this.val() == "" )
							// 	// 	$this.val("Enter name or e-mail")
							// })
							.keyup(function(e){
								if(e.keyCode == 13) searchButton.trigger("click");
							});
						searchButton.off('wishlist').on('click.wishlist', function(){
							wishMessages.hide();
							$('.resultsHeader').hide();
							$("#wish-search-results").html("");
							$("#wishlist-wrapper").hide().find("tbody tr:not(#wish-item-template)").remove();
							if(searchText.val() != "")	{
								if (searchText.val().length > 2) {
									wishMessages.eq(1).show();
									searchWishlist({
										account : "665798",
				            			messages: wishMessages,
										searchText : searchText.val(),
				            			site: 'lonestarpercussion'
									});
								}
								else wishMessages.eq(5).show();
							}
							else wishMessages.eq(0).show();
						});
						var url = window.location.href;
						if( url.indexOf("searchtext") != -1 ) {
							var searched = url.substring( url.indexOf("searchtext") + 11 );
							searched = searched.substring( 0, searched.indexOf("&") );
							searchText.val( searched );
							searchButton.click();
						}
					}
				}
			},
			assets : {},

		};

		return _this;

	}()));

})();


});

}())
;
(function(){

define('controllers/product',['utilities/global', 'controllers/application', 'models/easyask', 'vendors/jqzoom/jqzoom'], function(){
	
	var _util = window.LSP.utilities;
	
	var product = (function(){
		var _this = {};
		var _app = window.LSP;
		var _assets = _app.assets;
		var _api = _app.models.easyask;
		
		_this =  {
			events : {
				product : {
					onAddToCart : function(e, data){
						_this.updateProduct(data.selector); // Update the product, just to be safe.
						data.selector[0].submit();
						_gaq.push(['_trackEvent', 'product', _util.camelCase('addToCart-' + _this.getProductContext(data.selector)), $('.productName', data.selector.parents('.entry')).text()]);
					},
					onMatrixOptionSelect : function(e, data){
						$('option[value=""]', data.selector).remove();
						_this.updateMatrixLists(data.selector[0].form, data.selector);
						_gaq.push(['_trackEvent', 'product', _util.camelCase('selectMatrixOption-' + _this.getProductContext(data.selector)) , $('.productName', data.selector.parents('.entry')).text()]);
					},
					onAddToWishlist : function(e, data){
						var form = data.selector.parents('form');
						_this.updateProduct(form);
						
						require(['controllers/wishlist'], function(wishlist){
							addToWishlist({
								customer: $('input[name="customer"]', form).val(),
								item: $('input[name="buyid"]', form),
								site: 'lonestarpercussion',
								options : $('.shopping.section select', form),
								qty: $('.shopping.section input[name="qty"]', form),
								messages: $(".wishlist-messages > div", form)
							});
						
							_gaq.push(['_trackEvent', 'product', _util.camelCase('addToWishlist-' + _this.getProductContext(form)), $('.productName', form.parents('.entry')).text()]);
						})
						
					},
					onVerifyGiftCardAmount : function(e, data){
						
						var isValid = _app.controllers.validation.validateForm(data.selector[0].form);
						var inputSelector = $('input[name="amount"]');
						var amount = parseInt(inputSelector.val(), 10) || 0;
						if(amount <= 1000 && amount > 1){
							inputSelector.parent().addClass('validation-container').removeAttr('data-validation-invalidtypes');
							if(isValid){
								inputSelector[0].form.submit();
							}
						}else{
							inputSelector.parent().addClass('validation-container').attr('data-validation-invalidtypes', 'overGiftCardAmount');
							_util.scrollTo(inputSelector);
						}

					}
				},
				application : {
					onContextChange : function(e, data){
						// previousContext is null for the first firing... if it's not null it must be a 2+ event
						if(data.previousContext){
							_this.attachZoom(data.context);
						}
					},
					onReady : function(e, data){
						
						var productPageForm = $('.page-product form[action="/app/site/backend/additemtocart.nl"]')[0];
						if(productPageForm){
							_this.renderMatrixLists(productPageForm);
						}

						setTimeout(_this.removeEmptySpecificationsRows, 500);

						// if($('.page-productDetail .audio.section').is(':not(.show0Elements)')){
						// 	head.js('http://dev.lonestarpercussion.com/js/vendors/jqplayer/jquery.jplayer.min.js', function(){
						// 		$('.audio.section a').jPlayer({
						// 			ready : function(){
						// 				$(this).jPlayer('setMedia', { mp3: $(this).attr('href') });
						// 			},
						// 			swfPath : "http://dev.lonestarpercussion.com/js/vendors/jqplayer/",
						// 			supplied : "mp3"
						// 		});	
						// 	});
						// }

						_this.attachZoom(data.context);
						
					},
					onInit : function(e, data){}
				}
			},
			
			assets : {},

			getProductContext : function(element){

				var containerClasses = $(element).parents('[class*="page-"]').attr('class').split(' ');
				if(containerClasses[0].indexOf('page-') > -1){
					return containerClasses[0].replace('page-', '');
				}else{
					return 'unknown';
				}

			},

			attachZoom : function(context){
				// If jqzoom, it's the product page.
				if($.jqzoom){
					_this.detachZoom();
					var zoomAsset = $('a[data-asset="mouseoverZoom"]');
					if(zoomAsset.is(':not([href*="no-image"])') && context !== 'phone'){
						zoomAsset
							.jqzoom({
								zoomWidth: $('.addToCart').width(),
								zoomHeight: 480,
								position: 'right',
								preloadImages: (context !== 'phone' ? true : false),
								xOffset : (context === 'phone' ? 1000 : parseInt($('.information.span6').css('margin-left'), 10)),
								yOffset : -20,
								zoomType: 'standard',
								showEffect: 'fadein',
								fadeinSpeed: 'fast',
								delay : 100
							});

						// Reattach unveil handlers for thumbnails
						require(['vendors/unveil/unveil-min'], function(data){
							$('*[data-src]:not([data-lazy-handled])').attr('data-lazy-handled', true).unveil(200);
						});
					}else{
						//zoomAsset.removeAttr('href');
						// Get all image-links including thumbnails
						$('a[href*=no-image]').removeAttr('href');
					}
				}
			},
			detachZoom : function(){
				$('.zoomWindow').remove();
				$('.zoomPup').remove();
				$('.zoomPreload').remove();
				$('.zoomPad img').unwrap();
				
				var html = $('.section.images').html();
				$('.section.images').empty().html(html);
			},

			removeEmptySpecificationsRows : function(){
				$("tr[data-specifications-data]").filter(function() {
					var val = $(this).attr('data-specifications-data').toLowerCase();
					return val.replace(/[^A-Za-z0-9]/, '') === '' || val === '!empty!' || val === '!empty!' || val === '!none!' || val === 'none' || val === '!unknown!' || val === '!needspec!' || val === '!required!';
				}).remove();
			},

			renderMatrixLists : function(form){
				
			},




			updateMatrixLists : function(form, select){

				var entry = select.parents('.entry');
				var easyAskMatrixData = _api.parseMatrixChildren($('div[data-name="summaryString"]', entry).data('value'));
				var selectedOptions = {};

				// Create an object of currently selected options
				$('select', entry)
					.each(function(i, element){
						// If it's not the 'Select an Option' choice - which is identified by value=''
						if($(element).val().length){
							selectedOptions[$(element).attr('name')] = $(element).val();
						}
					});

				// Filter, and render newly updated options
				var filteredOptions = _api.filterMatrixChildren(easyAskMatrixData, selectedOptions);
				var unselectedOptionText = $('option[value=""]:first', entry).text();
				
				$.each(filteredOptions, function(label, options){
					
					var optionHTML = '<option value="">'+ unselectedOptionText +'</option>';

					$.each(options, function(value, noop){
						optionHTML += '<option value="' + value + '" '+ ((selectedOptions[label] === value) ? 'selected' : '') +'>'+value+'</option>';
					});

					// Update everything except the one you are currently on.					
					$('select[name="'+ label + '"]', form).html(optionHTML);
				});

				_this.updateProduct(entry);
			},
			
			updateProduct : function(entry){

				var easyAskMatrixData = _api.parseMatrixChildren($('div[data-name="summaryString"]', entry).data('value'));
				var selectedOptions = {};

				// Create an object of selected options to test against the formattedObject (the source)
				var selects = $('select', entry)
					.each(function(i, element){
						selectedOptions[$(element).attr('name')] = unescape($(element).val());
					});

				if(selects.length){
					$('button.b1', entry).attr('disabled', true);
					$('input[name="buyid"]', entry).val('');
					$('input[name="itemid"]', entry).val('');

					// Loop through the formattedMatrix (source of all attributes) and if we find an id that
					// matches the filter criteria, then set the id
					$.each(easyAskMatrixData.products, function(id, productData){
						
						var label;

						for(label in productData.options){
							// If it's not present, or if it exists, but is another value
							if(!selectedOptions[label] || selectedOptions[label] !== productData.options[label])
								return;
						}

						_this.detachZoom();

						// If we've made it here, it's because we've found an ID that matches the filters
						// Update all the changing nick nacks in the item listing
						$('input[name="buyid"]', entry).val(id); // Set the buyid
						$('input[name="itemid"]', entry).val(id);
						$('input[name*=".id"]', entry).val(id)
						$('button.b1', entry).removeAttr('disabled');

						// "You save $x" - we hide it if the save amount is < 0 (it would be an error, so this is just to be safe)
						if(productData.data.msrp - productData.data.onlinePrice <= 0){
							$('.price .details', entry).hide();
						}else{
							$('.price .details', entry).show();
						}

						$('.productMsrp', entry).html(_util.parseCurrency(productData.data.msrp));
						$('.productPrice', entry).html(_util.parseCurrency(productData.data.onlinePrice));
						$('.productMpn', entry).html(productData.data.mpn);
						$('.productDiscount', entry).html(_util.parseCurrency(productData.data.msrp - productData.data.onlinePrice));

						var optionArray = [];
						for(label in productData.options){
							if(productData.options.hasOwnProperty(label)){
								optionArray.push(productData.options[label]);
							}
						}

						$('.productName .options', entry).html(' : ' + optionArray.join(', '));

						// Update the active thumbnail
						var size = $('.thumbnail img, #zoom-mainImage img, img.thumbnail', entry).width();
						var img = $('.thumbnail img, #zoom-mainImage img, img.thumbnail', entry);
						var productImageLink = $('#zoom-mainImage').attr('href',  productData.data.imageUrl);
						img.attr('src',  productData.data.imageUrl + '.' + size + 'x' + size);

						$('.productAvailability', entry).html(productData.data.stockMessage);
						$(entry).attr('data-stockmessage', productData.data.stockMessage);
						
						_this.attachZoom(_app.controllers.application.getContext());

						// Update badges
						$('.productName *[data-badge], .details *[data-badge]', entry).removeClass('badges-hasBadge').attr('data-badge', productData.data.specialFeature);
						$('.thumbnail[data-badge], #zoom-mainImage[data-badge]', entry).removeClass('badges-hasBadge').attr('data-badge', productData.data.waysToSave);
						$('.productName *[data-badge] .badges-badge, .thumbnail[data-badge] .badges-badge, .details *[data-badge] .badges-badge', entry).remove();
						_app.controllers.application.attachEvents(entry);


					});
				}
			},
			
			// Returns product specs
			getSpecifications : function(id){
				return _api.request(_this, 'getSpecifications', 'getSpecifications', {id : id});
			},
			
			// Returns an object of options
			getMatrixOptions : function(matrixParentId){
				return _api.request(_this, 'get', 'getMatrixOptions', {parentId : matrixParentId});
			}
		};
		
		return _this;
	})();
	
	_util.register('controller', 'product', product);

});

})();
/**
 * Copyright (c) 2010 Maxim Vasiliev
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @author Maxim Vasiliev
 * Date: 09.09.2010
 * Time: 19:02:33
 */

var form2js = (function()
{
	

	/**
	 * Returns form values represented as Javascript object
	 * "name" attribute defines structure of resulting object
	 *
	 * @param rootNode {Element|String} root form element (or it's id) or array of root elements
	 * @param delimiter {String} structure parts delimiter defaults to '.'
	 * @param skipEmpty {Boolean} should skip empty text values, defaults to true
	 * @param emptyToNull {Boolean} should empty values be converted to null?
	 * @param nodeCallback {Function} custom function to get node value
	 * @param useIdIfEmptyName {Boolean} if true value of id attribute of field will be used if name of field is empty
	 */
	function form2js(rootNode, delimiter, skipEmpty, emptyToNull, nodeCallback, useIdIfEmptyName)
	{
		if (typeof skipEmpty == 'undefined' || skipEmpty == null) skipEmpty = true;
		if (typeof emptyToNull == 'undefined' || emptyToNull == null) emptyToNull = true;
		if (typeof delimiter == 'undefined' || delimiter == null) delimiter = '.';
		if (arguments.length < 6) useIdIfEmptyName = false;

		rootNode = typeof rootNode == 'string' ? document.getElementById(rootNode) : rootNode;

		var formValues = [],
			currNode,
			i = 0;

		/* If rootNode is array - combine values */
		if (rootNode.constructor == Array || (typeof NodeList != 'undefined' && rootNode.constructor == NodeList))
		{
			while(currNode = rootNode[i++])
			{
				formValues = formValues.concat(getFormValues(currNode, nodeCallback, useIdIfEmptyName));
			}
		}
		else
		{
			formValues = getFormValues(rootNode, nodeCallback, useIdIfEmptyName);
		}

		return processNameValues(formValues, skipEmpty, emptyToNull, delimiter);
	}

	/**
	 * Processes collection of { name: 'name', value: 'value' } objects.
	 * @param nameValues
	 * @param skipEmpty if true skips elements with value == '' or value == null
	 * @param delimiter
	 */
	function processNameValues(nameValues, skipEmpty, emptyToNull, delimiter)
	{
		var result = {},
			arrays = {},
			i, j, k, l,
			value,
			nameParts,
			currResult,
			arrNameFull,
			arrName,
			arrIdx,
			namePart,
			name,
			_nameParts;

		for (i = 0; i < nameValues.length; i++)
		{
			value = nameValues[i].value;

			if (emptyToNull && (value === '')) { value = null; }
			if (skipEmpty && (value === '' || value === null)) continue;

			name = nameValues[i].name;
			if (typeof name === 'undefined') continue;

			_nameParts = name.split(delimiter);
			nameParts = [];
			currResult = result;
			arrNameFull = '';

			for(j = 0; j < _nameParts.length; j++)
			{
				namePart = _nameParts[j].split('][');
				if (namePart.length > 1)
				{
					for(k = 0; k < namePart.length; k++)
					{
						if (k == 0)
						{
							namePart[k] = namePart[k] + ']';
						}
						else if (k == namePart.length - 1)
						{
							namePart[k] = '[' + namePart[k];
						}
						else
						{
							namePart[k] = '[' + namePart[k] + ']';
						}

						arrIdx = namePart[k].match(/([a-z_]+)?\[([a-z_][a-z0-9_]+?)\]/i);
						if (arrIdx)
						{
							for(l = 1; l < arrIdx.length; l++)
							{
								if (arrIdx[l]) nameParts.push(arrIdx[l]);
							}
						}
						else{
							nameParts.push(namePart[k]);
						}
					}
				}
				else
					nameParts = nameParts.concat(namePart);
			}

			for (j = 0; j < nameParts.length; j++)
			{
				namePart = nameParts[j];

				if (namePart.indexOf('[]') > -1 && j == nameParts.length - 1)
				{
					arrName = namePart.substr(0, namePart.indexOf('['));
					arrNameFull += arrName;

					if (!currResult[arrName]) currResult[arrName] = [];
					currResult[arrName].push(value);
				}
				else if (namePart.indexOf('[') > -1)
				{
					arrName = namePart.substr(0, namePart.indexOf('['));
					arrIdx = namePart.replace(/(^([a-z_]+)?\[)|(\]$)/gi, '');

					/* Unique array name */
					arrNameFull += '_' + arrName + '_' + arrIdx;

					/*
					 * Because arrIdx in field name can be not zero-based and step can be
					 * other than 1, we can't use them in target array directly.
					 * Instead we're making a hash where key is arrIdx and value is a reference to
					 * added array element
					 */

					if (!arrays[arrNameFull]) arrays[arrNameFull] = {};
					if (arrName != '' && !currResult[arrName]) currResult[arrName] = [];

					if (j == nameParts.length - 1)
					{
						if (arrName == '')
						{
							currResult.push(value);
							arrays[arrNameFull][arrIdx] = currResult[currResult.length - 1];
						}
						else
						{
							currResult[arrName].push(value);
							arrays[arrNameFull][arrIdx] = currResult[arrName][currResult[arrName].length - 1];
						}
					}
					else
					{
						if (!arrays[arrNameFull][arrIdx])
						{
							if ((/^[a-z_]+\[?/i).test(nameParts[j+1])) currResult[arrName].push({});
							else currResult[arrName].push([]);

							arrays[arrNameFull][arrIdx] = currResult[arrName][currResult[arrName].length - 1];
						}
					}

					currResult = arrays[arrNameFull][arrIdx];
				}
				else
				{
					arrNameFull += namePart;

					if (j < nameParts.length - 1) /* Not the last part of name - means object */
					{
						if (!currResult[namePart]) currResult[namePart] = {};
						currResult = currResult[namePart];
					}
					else
					{
						currResult[namePart] = value;
					}
				}
			}
		}

		return result;
	}

    function getFormValues(rootNode, nodeCallback, useIdIfEmptyName)
    {
        var result = extractNodeValues(rootNode, nodeCallback, useIdIfEmptyName);
        return result.length > 0 ? result : getSubFormValues(rootNode, nodeCallback, useIdIfEmptyName);
    }

    function getSubFormValues(rootNode, nodeCallback, useIdIfEmptyName)
	{
		var result = [],
			currentNode = rootNode.firstChild;
		
		while (currentNode)
		{
			result = result.concat(extractNodeValues(currentNode, nodeCallback, useIdIfEmptyName));
			currentNode = currentNode.nextSibling;
		}

		return result;
	}

    function extractNodeValues(node, nodeCallback, useIdIfEmptyName) {
        var callbackResult, fieldValue, result, fieldName = getFieldName(node, useIdIfEmptyName);

        callbackResult = nodeCallback && nodeCallback(node);

        if (callbackResult && callbackResult.name) {
            result = [callbackResult];
        }
        else if (fieldName != '' && node.nodeName.match(/INPUT|TEXTAREA/i)) {
            fieldValue = getFieldValue(node);   
	        if (fieldValue == null && node.type == 'radio')
                result = [];
            else
                result = [ { name: fieldName, value: fieldValue} ];
        }
        else if (fieldName != '' && node.nodeName.match(/SELECT/i)) {
	        fieldValue = getFieldValue(node);
	        result = [ { name: fieldName.replace(/\[\]$/, ''), value: fieldValue } ];
        }
        else {
            result = getSubFormValues(node, nodeCallback, useIdIfEmptyName);
        }

        return result;
    }

	function getFieldName(node, useIdIfEmptyName)
	{
		if (node.name && node.name != '') return node.name;
		else if (useIdIfEmptyName && node.id && node.id != '') return node.id;
		else return '';
	}


	function getFieldValue(fieldNode)
	{
		if (fieldNode.disabled) return null;
		
		switch (fieldNode.nodeName) {
			
			case 'TEXTAREA':
				return $('<div/>').text(fieldNode.value).html(); // Escapes the textarea
				break;
			case 'INPUT':
				switch (fieldNode.type.toLowerCase()) {
					case 'radio':
					case 'checkbox':
						if (fieldNode.checked) return fieldNode.value;
						break;

					case 'button':
					case 'reset':
					case 'submit':
					case 'image':
						return '';
						break;

					default:
						return fieldNode.value;
						break;
				}
				break;

			case 'SELECT':
				return getSelectedOptionValue(fieldNode);
				break;

			default:
				break;
		}

		return null;
	}

	function getSelectedOptionValue(selectNode)
	{
		var multiple = selectNode.multiple,
			result = [],
			options,
			i, l;

		if (!multiple) return selectNode.value;

		for (options = selectNode.getElementsByTagName('option'), i = 0, l = options.length; i < l; i++)
		{
			if (options[i].selected) result.push(options[i].value);
		}

		return result;
	}

	return form2js;

})();

LSP.utilities = LSP.utilities || {};
LSP.utilities.formToObject = form2js;
define("vendors/form2js/form2js", function(){});

(function(){


define('models/netsuite',['utilities/global', 'controllers/application', 'models/api'], function(){


	var _util = window.LSP.utilities;
	var _models = window.LSP.models;
	_util.register('model', 'netsuite', (function(){

		var _this = $.extend({}, _models.api);

	return $.extend(_this, {
			_url : function(controller, payload){
				var url = 'https://forms.netsuite.com/app/site/hosting/scriptlet.nl';
				url = (payload.method.match('getUPS') ? 'https://d2bghjaa5qmp6f.cloudfront.net/shipping/' + payload.method : url);
				
				return url;
			},
			_payload : function(controller, payload){
				return $.extend(payload.data, {
					method : payload.method,
					deploy : '1',
					script : '25',
					h : '55cda7fb2a0d8a937f00',
					compid : '665798'
				});
			},
			request : function(controller, eventName, method, data){
				return this._request('GET', 'jsonp', controller, eventName, {data : data, method : method});

			}
		});

	}()));
	
});

}());
(function(){

define('vendors/formatdate/formatdate',[], function(){
	
	return function(date, formatString){

		date = (typeof date === 'string' && date.indexOf(':') < 0 ? date.replace(/-/g, '/') : date);
		date = (typeof date === 'string' ? new Date(date) : date); // replace - with / for safari
		date = date || new Date();
		formatString = formatString || 'l, F jS Y g:ia';
		var returnStr = '';
		var replace = {
			shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
			longMonths: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
			shortDays: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
			longDays: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
		
			// Day
			d: function(c) { return (c.getDate() < 10 ? '0' : '') + c.getDate(); },
			D: function(c) { return this.shortDays[c.getDay()]; },
			j: function(c) { return c.getDate(); },
			l: function(c) { return this.longDays[c.getDay()]; },
			N: function(c) { return c.getDay() + 1; },
			S: function(c) { return (c.getDate() % 10 == 1 && c.getDate() != 11 ? 'st' : (c.getDate() % 10 == 2 && c.getDate() != 12 ? 'nd' : (c.getDate() % 10 == 3 && c.getDate() != 13 ? 'rd' : 'th'))); },
			w: function(c) { return c.getDay(); },
			z: function(c) { var d = new Date(c.getFullYear(),0,1); return Math.ceil((c - d) / 86400000); }, // Fixed now
			// Week
			W: function(c) { var d = new Date(c.getFullYear(), 0, 1); return Math.ceil((((c - d) / 86400000) + d.getDay() + 1) / 7); }, // Fixed now
			// Month
			F: function(c) { return this.longMonths[c.getMonth()]; },
			m: function(c) { return (c.getMonth() < 9 ? '0' : '') + (c.getMonth() + 1); },
			M: function(c) { return this.shortMonths[c.getMonth()]; },
			n: function(c) { return c.getMonth() + 1; },
			t: function(c) { var d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 0).getDate() }, // Fixed now, gets #days of date
			// Year
			L: function(c) { var year = c.getFullYear(); return (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)); },   // Fixed now
			o: function(c) { var d  = new Date(c.valueOf());  d.setDate(d.getDate() - ((c.getDay() + 6) % 7) + 3); return d.getFullYear();}, //Fixed now
			Y: function(c) { return c.getFullYear(); },
			y: function(c) { return ('' + c.getFullYear()).substr(2); },
			// Time
			a: function(c) { return c.getHours() < 12 ? 'am' : 'pm'; },
			A: function(c) { return c.getHours() < 12 ? 'AM' : 'PM'; },
			B: function(c) { return Math.floor((((c.getUTCHours() + 1) % 24) + c.getUTCMinutes() / 60 + c.getUTCSeconds() / 3600) * 1000 / 24); }, // Fixed now
			g: function(c) { return c.getHours() % 12 || 12; },
			G: function(c) { return c.getHours(); },
			h: function(c) { return ((c.getHours() % 12 || 12) < 10 ? '0' : '') + (c.getHours() % 12 || 12); },
			H: function(c) { return (c.getHours() < 10 ? '0' : '') + c.getHours(); },
			i: function(c) { return (c.getMinutes() < 10 ? '0' : '') + c.getMinutes(); },
			s: function(c) { return (c.getSeconds() < 10 ? '0' : '') + c.getSeconds(); },
			u: function(c) { var m = c.getMilliseconds(); return (m < 10 ? '00' : (m < 100 ? '0' : '')) + m; },
			// Timezone
			O: function(c) { return (-c.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(c.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(c.getTimezoneOffset() / 60)) + '00'; },
			P: function(c) { return (-c.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(c.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(c.getTimezoneOffset() / 60)) + ':00'; }, // Fixed now
			T: function(c) { var m = c.getMonth(); c.setMonth(0); var result = c.toTimeString().replace(/^.+ \(?([^\)]+)\)?$/, '$1'); c.setMonth(m); return result;},
			Z: function(c) { return -c.getTimezoneOffset() * 60; },
			// Full Date/Time
			c: function(c) { return c.format("Y-m-d\\TH:i:sP"); }, // Fixed now
			r: function(c) { return c.toString(); },
			U: function(c) { return c.getTime() / 1000; }
		};
		
		for (var i = 0; i < formatString.length; i++) {
			var curChar = formatString.charAt(i);
			if (i - 1 >= 0 && formatString.charAt(i - 1) == "\\") {
				returnStr += curChar;
			}else if (replace[curChar]) {
				returnStr += replace[curChar](date);
			}else if (curChar != "\\"){
				returnStr += curChar;
			}
		}
		return returnStr;
	};


});

}())	
	;
(function(){

define('plugins/reviews',['utilities/global', 'controllers/application', 'vendors/form2js/form2js', 'models/api', 'models/netsuite', 'vendors/formatdate/formatdate'], function(){

	var _util = window.LSP.utilities;
	_util.formatdate = defne(['vendors/formatdate/formatdate']);
	
	_util.register('controller', 'reviews', (function(){
		var _this = {};
		var _app = window.LSP;
		var _api = _app.models.netsuite;
		var _settings = {
			containerSelector : '#addReviewForm',
			formSelector : '#reviews-inputForm',
			prosInputSelector : '#reviews-inputForm .pros input',
			consInputSelector : '#reviews-inputForm .cons input',
			reviewTemplateId : 'templates-reviewEntry',
			previewSelector : '#previewReview'
		};
		
		_this =  {
			name : 'reviews',
			events : {
				reviews : {
					onAfterAPICallSuccess : function(e, data){
						$(_settings.formSelector).removeClass('loading');
						$('#reviewEntries').removeClass('loading secondary');

						// Close the add-review form
						$('button.b1.reveal-open[data-reveal-children*="addReviewForm"]').trigger('click');
						$(':input', _settings.formSelector).removeAttr('disabled');

					},
					onBeforeAPICall : function(e, data){
						$(_settings.formSelector).addClass('loading');
						$('#reviewEntries').addClass('loading secondary');
						$(':input', _settings.formSelector).attr('disabled');
					},
					onSave : function(e, data){
						var form = data.selector[0];
						if(_app.controllers.validation.validateForm(form)){
							_this.save(_this.parseForm(form));
						}
					},
					onProOrConInput : function(e){
						// If there is something in the input, show the second one
						if(e.currentTarget.value.length > 0){
							$(e.currentTarget).parent().next().show();

						// If the current one is empty, AND the next one is too, hide the second one
						}else if($(e.currentTarget).parent().next().length &&
								($(e.currentTarget).parent().next().children('input').val() || '').length < 1){ // the previous one is empty

							$(e.currentTarget).parent().next().hide();

						// If the current one is empty, and no longer has focus, and isn't the first one, hide it
						}else if(!$(e.currentTarget).is(':focus') &&
								!$(e.currentTarget).parent().is(':nth-of-type(1)') &&
								$(e.currentTarget).parent().prev().children().val().length < 1){
							$(e.currentTarget).parent().hide();
						}
					},
					// onAddedBodyContent : function(){
						
					//	var startHeight = $(this).height();
					//	return function(e){
					//		var textHeight = $(this).scrollTop();
					//		var newHeight = $(this).height() + textHeight;
					//		if(newHeight > startHeight){
					//			$(this).css('height',(newHeight + 'px'));
					//		}else{
					//			$(this).css('height', startHeight);
					//		}
						
					//	};
					// },
					onRenderPreview : function(e){
						$(_settings.previewSelector).html(_this.render(_this.parseForm(e.currentTarget.form)));
					}
				},
				application : {
					onAttachEvents : function(e, data){

						 $(_settings.formSelector+' :input', data.selector)
							.off('reviews')
							.on('keyup.lsp.reviews change.lsp.reviews', _this.events.reviews.onRenderPreview)
								.filter('input[type="checkbox"], input[type="radio"], select')
								.on('click.lsp.reviews change.lsp.reviews', _this.events.reviews.onRenderPreview);

						

						// $(_settings.formSelector+' textarea', data.selector)
						//	.on('keyup.lsp.reviews', _this.events.reviews.onAddedBodyContent()); // returns a function

						$(_settings.prosInputSelector+', '+_settings.consInputSelector, data.selector)
							.off('reviews')
							.on('keyup.lsp.reviews change.lsp.reviews', _this.events.reviews.onProOrConInput);
					}
				}
			},
			assets : {},
			
			// Send the form, and replace the form with the result from the 
			// server.
			// save : function(formElement){
			// 	var data = _this.parseForm(formElement); // We have to parse the form before we disable the elements
			// 	$(':input', formElement).attr('disabled', true);
				
			// 	var result = $.when(_api.request(_this, 'save', 'saveReview', data))
			// 	.done(function(data){
			// 		// don't forget to _util.attachEvents with the new HTML!
			// 		$(_settings.formSelector).replaceWith(JSON.stringify(data));
			// 	}).always(function(data){
			// 		$(':input', formElement).attr('disabled', false);
			// 	});
				
			// 	return result;
				
			// },

			save : function(reviewData){

				_gaq.push(['_trackEvent', 'reviews', 'saveReview']);

				return _api.request(_this, 'saveReview', {method : 'saveReview', data : JSON.stringify(reviewData)})
					.done(function(data){
						_this.renderSavedReview(reviewData);
					});
			},
			
			render : function(data){
				var html = _util.parseMicroTemplate(_settings.reviewTemplateId, data);
				return html;
			},

			renderSavedReview : function(review){
				
				_util.scrollTo($('.reviews.section'));

				$('ul.entries')
					.addClass('saved');

			},

			// Take the form, JSON encode the profile section, perform
			// other pre-save functions, and return the data
			parseForm : function(element){
				
				var returnData;
				var profile = [];
				
				returnData = _util.formToObject(element, null, true);

				// This is ancient code - the original plan was to store data in fields, and change
				// the review script as little as possible - but now we use a json object to handle it
				// so with some cleanup, this could be removed (move this logic to the template)
				for(var i = 0; i < ((returnData || {}).custrecordreviewprofile || {}).length; i++){
					
					if(returnData.custrecordreviewprofile[i].title){
						var years = '';
						if(returnData.custrecordreviewprofile[i].time > 0){
							var pluralString = (returnData.custrecordreviewprofile[i].time > 1 ? 's' : '');
							years = '&nbsp;('+ returnData.custrecordreviewprofile[i].time + '&nbsp;yr' + pluralString + ')';
						}
						profile.push(returnData.custrecordreviewprofile[i].title + years);
					}
				}
				returnData.profile = profile.join(', ');

				return returnData;
			}
		};

		return _this;
	})());

});
	
})();

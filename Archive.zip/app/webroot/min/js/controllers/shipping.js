(function(){

define('models/api',['utilities/global', 'controllers/application'], function(){
	
	var _app = window.LSP;
	var _util = _app.utilities;

	// This is a generic API model that can be extended to overwrite : 
	//      _url - returns the url for the service
	//      _payload - formats the payload as nessesary
	//      _isSuccess - often services will not use HTTP status codes to
	//                   return actual request success/failure - you can write custom
	//                   logic here that will 'fail' a successful query
	//
	// Use like : $.extend({ _url : function(payload){ console.log('custom code'); }, _app.models.api)

	_util.register('model', 'api', {
		
		_timeout : 15000,

		_url : function(controller, payload){
			return '';
		},
		_payload : function(controller, payload){
			return payload;
		},
		_isSuccess : function(responseData){
			return (responseData || {}).success === true;
		},
		_afterSuccess : function(responseData){
			return responseData;
		},
		_request : function(type, dataType, controller, eventName, payload, passthrough){
		
			var result = $.Deferred();
			var eventData = {};
			
			$.support.cors = true;

			eventData.xhrData = {
				type : type,
				url : this._url(controller, payload),
				data : this._payload(controller, payload),
				crossDomain : true,
				dataType : dataType,
				context : this,
				timeout : this._timeout,
				passthrough : $.extend({}, passthrough)
			};
			
			// TODO : use $.extend

			// for(var key in payload){
			// 	if(payload.hasOwnProperty(key)){ eventData.xhrData.data[key] = payload[key]; } 
			// } // Merge objects
			
			console.log('API Request Sent via ' + eventName, eventData.xhrData);
			
			$(_app.controllers.application).triggerHandler('onBeforeAPICall', eventData);
			$(controller).triggerHandler('onBeforeAPICall', eventData);
			$(controller).triggerHandler(_util.camelCase('on-Before-API-'+eventName+'-call'), eventData);
			
			$.ajax(eventData.xhrData).done(function(responseData){
				
				eventData.serverResponse = responseData; // raw response needs a differnt property name
				try{
					eventData.response = $.parseJSON(responseData);
				}catch(e){
					eventData.response = responseData;
				}   

				if(this._isSuccess(responseData)){
					eventData.response = this._afterSuccess(eventData.response);
					result.resolve(eventData);
				}else{
					eventData.error = 'invalidFormat';
					result.reject(eventData);
				}
				
			}).fail(function(responseData){

				// jQuery dosen't auto-parse JSON data for failures
				eventData.serverResponse = responseData; // raw response needs a differnt property name
				try{
					eventData.response = $.parseJSON(responseData.responseText);
				}catch(e){
					eventData.response = responseData;
				}
				
				result.reject(eventData);
				
			}).always(function(){
				console.log('API Response Recieved via ' + eventName, eventData);
			});


			// By seperating the logic like this -- it allows us to "fail" a success HTTP response (see the .done() method above)
			$.when(result).done(function(responseData){
				
				// Fire onAfterMethodSuccess event
				// Fire mb.controllers.application's onAfterAPICallSuccess
				$(_app.controllers.application).triggerHandler('onAfterAPICallSuccess', responseData);
				$(controller).triggerHandler('onAfterAPICallSuccess', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName+'-success'), responseData);
				// $('body').addClass(controller.name + '-downloadSuccess');
				
			}).fail(function(responseData){
				
				// Fire onAfterMethodFailure event
				// Fire mb.controllers.application's onAfterAPICallFailure
				$(_app.controllers.application).triggerHandler('onAfterAPICallFailure', responseData);
				$(controller).triggerHandler('onAfterAPICallFailure', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName+'-failure'), responseData);
				// $('body').addClass(controller.name + '-downloadFailure');
				
			}).always(function(responseData){
				
				$(_app.controllers.application).triggerHandler('onAfterAPICall', responseData);
				$(controller).triggerHandler('onAfterAPICall', responseData);
				$(controller).triggerHandler(_util.camelCase('on-after-API-'+eventName), responseData);
				// $('body').removeClass(controller.name + '-downloadWaiting');
				
			});

			return result.promise();
		},

		request : function(controller, eventName, method, data){
			return this._request('GET', 'jsonp', controller, eventName, method, data);
		}
	});

});
	
}());

(function(){


define('models/netsuite',['utilities/global', 'controllers/application', 'models/api'], function(){


	var _util = window.LSP.utilities;
	var _models = window.LSP.models;
	_util.register('model', 'netsuite', (function(){

		var _this = $.extend({}, _models.api);

	return $.extend(_this, {
			_url : function(controller, payload){
				var url = 'https://forms.netsuite.com/app/site/hosting/scriptlet.nl';
				url = (payload.method.match('getUPS') ? 'https://d2bghjaa5qmp6f.cloudfront.net/shipping/' + payload.method : url);
				
				return url;
			},
			_payload : function(controller, payload){
				return $.extend(payload.data, {
					method : payload.method,
					deploy : '1',
					script : '25',
					h : '55cda7fb2a0d8a937f00',
					compid : '665798'
				});
			},
			request : function(controller, eventName, method, data){
				return this._request('GET', 'jsonp', controller, eventName, {data : data, method : method});

			}
		});

	}()));
	
});

}());
(function(){

define('controllers/shipping',['utilities/global', 'models/netsuite', 'controllers/application'], function(){

	var _util = window.LSP.utilities;
	
	var shipping = (function(){
		var _this = {};
		var _app = window.LSP;
		var _api = _app.models.netsuite;
		var _settings = {
			bodyNoTrackingNumbersFoundClass : 'shipping-noTrackingNumbersFound',
			trackingNumberSelector : '.testOnly-trackingNumbers'
		};
		
		_this = {
			name : 'shipping',
			events : {
				application : {
					onAttachEvents : function(e, data){
						$('#search-orders-form', data.selector).bind('submit', function(e){
							_this.handleSubmit({
								search : $('.page-trackOrder input[name="search"]').val() || ''
							});
							e.preventDefault();
							return false;
						});
					}
				}
			},
			assets : {},
			handleSubmit : function(formObject){
				if(formObject.search.substr(0, 2).toUpperCase() === '1Z'){
					_this.redirectToUPS(formObject.search);
				}else{
					// Probably a Sales Order
					//_this.clearTrackingNumbers();
					$('#responseTable').addClass('loading');
					$('#responseTable table').hide();
					$.when(_this.requestTrackingNumber(formObject.search))
					.done(function(response){
						_this.renderTrackingData(_this.parseAPIResponse(response.response.data));
						//_this.getTrackingData(((response.response.data || {}).trackingnumbers || '').toUpperCase());
					}).fail(function(response){
						$('#responseTable').html($('#templates-trackOrder-error').html());
					}).always(function(){
						$('#responseTable').removeClass('loading');
					});
				}
			},

			renderTrackingData : function(renderObject){
				var html = _util.parseMicroTemplate('templates-trackingResponse', renderObject);
				$('#responseTable').html(html);
			},

			parseAPIResponse : function(rawResponse){

				var trackingNumbersArray = rawResponse.trackingnumbers.split('<BR>');
				var parsedResponse = [];

				for(var i = 0; i < trackingNumbersArray.length; i++){
					
					var carrier = _this.getCarrierFromTrackingNumber(trackingNumbersArray[i]);

					parsedResponse.push({
						orderId : rawResponse.internalid.value,
						orderDate : rawResponse.trandate,
						orderNumber : rawResponse.number,
						orderEmail : rawResponse.email,
						trackingNumber : trackingNumbersArray[i],
						trackingUrl : (carrier == 'ups' ? 
							'http://wwwapps.ups.com/ietracking/tracking.cgi?tracknum=' +  trackingNumbersArray[i] :
							'https://tools.usps.com/go/TrackConfirmAction.action?tLabels=' + trackingNumbersArray[i]), 
						carrier : carrier
					});
				}
				
				return parsedResponse;
			
			},

			getCarrierFromTrackingNumber : function(trackingNumber){

				if(trackingNumber.substr(0, 2).toUpperCase() == '1Z')
					return 'ups';
				else
					return 'usps';

			},
			
			// getTrackingData : function(trackingNumbers){
			// 	if(trackingNumbers.length !== 0){


			// 		var trackingNumbersArray = trackingNumbers.split(' ');
			// 		for(var i = 0; i < trackingNumbersArray.length; i++){


			// 			if(_this.isUPSTrackingNumber(trackingNumbersArray[i]))
			// 				// handle ups
			// 			if(_this.isUSPSTrackingNumber(trackingNumbersArray[i]))
			// 				// handle usps

			// 			$.when(_this.requestUPSTrackingData(trackingNumbersArray[i]))
			// 			.done(function(response){
			// 				_this.displayTrackingData(response.response.data);
			// 			}).fail(function(response){
			// 				$('body').addClass(_settings.bodyNoTrackingNumbersFoundClass);
			// 			});
			// 		}



			// 	}else{
			// 		$('body').addClass(_settings.bodyNoTrackingNumbersFoundClass);
			// 	}
			// },
			
			// clearTrackingNumbers : function(){
			// 	$(_settings.trackingNumberSelector).html('');
			// 	$('body').removeClass(_settings.bodyNoTrackingNumbersFoundClass);
			// },
			
			// displayTrackingData : function(trackingData){
			// 	console.log(trackingData);
			// 	$(_settings.trackingNumberSelector).append(JSON.stringify(trackingData));
			// },
			
			requestTrackingNumber : function(search){
				return _api.request(_this, 'getTrackingNumber', 'getTrackingNumber', {search : $.trim(search)});
			},
			
			// requestUPSTrackingData : function(trackingNumber){
			// 	return _api.request(_this, 'getUPSTrackingData', 'getUPSTrackingData', {trackingNumber : trackingNumber});
			// }
		};

		return _this;
	})();
	
	_util.register('controller', 'shipping', shipping);

});
	
})();
